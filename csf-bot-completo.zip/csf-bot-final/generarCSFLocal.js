// ── Generador local de Constancia de Situación Fiscal (CSF) ─────────────────
// Flujo: RFC + idCIF → Playwright scrape SAT validadorqr → llenar DOCX → OnlyOffice PDF
// Uso:   generarCSFLocal({ rfc, idCif, downloadDir })

const { execFile }  = require("child_process");
const path          = require("path");
const fs            = require("fs");
const https         = require("https");
const http          = require("http");
const { chromium }  = require("playwright");
const qrcode        = require("qrcode");
const AdmZip        = require("adm-zip");
// FIX Bug #55: cliente OnlyOffice unificado. Antes había una copia local de
// la lógica de conversión (convertirAPdf más abajo) que divergió de la copia
// en generarClonLocal.js. Ahora ambos usan el mismo módulo, así cualquier
// arreglo se aplica a CSF y CLON simultáneamente.
const { convertirDocxAPdf } = require("./onlyofficeClient");

// ── URL base del SAT ─────────────────────────────────────────────────────────
const SAT_URL = "https://siat.sat.gob.mx/app/qr/faces/pages/mobile/validadorqr.jsf?D1=10&D2=1&D3=";

// ── Meses en español ─────────────────────────────────────────────────────────
const MESES = ["ENERO","FEBRERO","MARZO","ABRIL","MAYO","JUNIO",
               "JULIO","AGOSTO","SEPTIEMBRE","OCTUBRE","NOVIEMBRE","DICIEMBRE"];

function fechaEspanol(d) {
  const [y, m, day] = d.split("-");
  return `${String(parseInt(day)).padStart(2,'0')} DE ${MESES[parseInt(m)-1]} DE ${y}`;
}

// ── Fecha/hora en zona horaria de Ciudad de México ───────────────────────────
// El SAT usa UTC-6 fijo (sin horario de verano)
// Calculamos desde UTC absoluto para que funcione independiente del TZ del servidor
function ahoraCDMX() {
  const now = new Date();
  // Tomar UTC absoluto y restar 6 horas para obtener CDMX (UTC-6)
  const cdmx = new Date(now.getTime() - (6 * 3600000));
  const pad = (n) => String(n).padStart(2, "0");
  return {
    year:   String(cdmx.getUTCFullYear()),
    month:  pad(cdmx.getUTCMonth() + 1),
    day:    pad(cdmx.getUTCDate()),
    hour:   pad(cdmx.getUTCHours()),
    minute: pad(cdmx.getUTCMinutes()),
    second: pad(cdmx.getUTCSeconds()),
  };
}

function fechaHoy() {
  const p = ahoraCDMX();
  return `${String(parseInt(p.day)).padStart(2,'0')} DE ${MESES[parseInt(p.month)-1]} DE ${p.year}`;
}

function timestampCDMX() {
  const p = ahoraCDMX();
  return `${p.year}/${p.month}/${p.day} ${p.hour}:${p.minute}:${p.second}`;
}

// ── Browser pool: reusar Chromium entre consultas ───────────────────────────
// El browser se mantiene abierto y solo se reinicia:
//   - Si crashea o se desconecta (auto-recuperación)
//   - Cada N consultas (para evitar leaks de memoria)
let browserShared = null;
let consultasRealizadas = 0;
const MAX_CONSULTAS_BROWSER = 50;
const BROWSER_ARGS = [
  "--no-sandbox",
  "--disable-setuid-sandbox",
  "--disable-dev-shm-usage",
  "--disable-gpu",
  "--disable-extensions",
  "--disable-background-networking",
  "--disable-default-apps",
  "--disable-sync",
  "--no-first-run",
  "--no-default-browser-check",
];

async function getSharedBrowser() {
  // Si está conectado y no hemos llegado al límite, reusar
  if (browserShared && browserShared.isConnected() && consultasRealizadas < MAX_CONSULTAS_BROWSER) {
    return browserShared;
  }

  // Cerrar el viejo (si existe) antes de lanzar uno nuevo
  if (browserShared) {
    try {
      console.log(`🔄 Reiniciando Chromium SAT (${consultasRealizadas} consultas hechas)`);
      await browserShared.close();
    } catch (e) { /* ignorar */ }
    browserShared = null;
  }

  // Lanzar nuevo
  browserShared = await chromium.launch({ headless: true, args: BROWSER_ARGS });
  consultasRealizadas = 0;

  // Auto-recuperación: si el browser se desconecta solo, dejarlo en null
  // para que la siguiente consulta lo relance automáticamente
  browserShared.on("disconnected", () => {
    console.warn("⚠️  Chromium SAT se desconectó");
    browserShared = null;
  });

  return browserShared;
}

// ── Versión HTTP nativa rápida (~500ms vs ~1500ms con Playwright) ────────────
function scrapearSATHttp(rfc, idCif) {
  return new Promise((resolve, reject) => {
    const url = `${SAT_URL}${idCif}_${rfc}`;
    const constants = require("constants");

    const req = https.get(url, {
      rejectUnauthorized: false,
      ciphers: "DEFAULT:@SECLEVEL=0",
      secureOptions: constants.SSL_OP_LEGACY_SERVER_CONNECT,
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
      },
      timeout: 15000,
    }, (res) => {
      if (res.statusCode !== 200) {
        return reject(new Error(`HTTP ${res.statusCode}`));
      }
      let html = "";
      res.on("data", (chunk) => (html += chunk));
      res.on("end", () => {
        try {
          // Convertir HTML a texto plano simulando el formato de Playwright innerText:
          // "Etiqueta:\tValor\nEtiqueta2:\tValor2\n..."
          // En el HTML del SAT cada campo está en <td>Etiqueta:</td><td>Valor</td>
          const fullText = html
            .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, "")
            .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, "")
            // </td> seguido de <td> → tab (separa etiqueta de valor)
            .replace(/<\/td>\s*<td[^>]*>/gi, "\t")
            // </tr>, </div>, </p>, </h*> → salto de línea
            .replace(/<\/(tr|div|p|h[1-6]|li)>/gi, "\n")
            .replace(/<br\s*\/?>/gi, "\n")
            // Cualquier otro tag → quitarlo
            .replace(/<[^>]+>/g, "")
            // Decodificar entidades HTML
            .replace(/&nbsp;/g, " ")
            .replace(/&amp;/g, "&")
            .replace(/&lt;/g, "<")
            .replace(/&gt;/g, ">")
            .replace(/&quot;/g, '"')
            .replace(/&#39;/g, "'")
            .replace(/&aacute;/gi, "á").replace(/&eacute;/gi, "é")
            .replace(/&iacute;/gi, "í").replace(/&oacute;/gi, "ó")
            .replace(/&uacute;/gi, "ú").replace(/&ntilde;/gi, "ñ")
            .replace(/&Aacute;/gi, "Á").replace(/&Eacute;/gi, "É")
            .replace(/&Iacute;/gi, "Í").replace(/&Oacute;/gi, "Ó")
            .replace(/&Uacute;/gi, "Ú").replace(/&Ntilde;/gi, "Ñ")
            // Limpiar espacios redundantes
            .replace(/[ ]+/g, " ")
            .replace(/\n\s*\n/g, "\n")
            .trim();

          // Validar que tenga datos esperados
          const lower = fullText.toLowerCase();
          const tieneCedula = lower.includes("rfc:") || lower.includes("datos de identificación") || lower.includes("datos de identificacion");
          const noEncontrado = lower.includes("no se le ha emitido") || lower.includes("no se encontr") || lower.includes("no existe");

          if (!tieneCedula && !noEncontrado) {
            return reject(new Error("HTML sin datos esperados"));
          }

          resolve(fullText);
        } catch (e) {
          reject(e);
        }
      });
    });
    req.on("error", reject);
    req.on("timeout", () => { req.destroy(); reject(new Error("timeout")); });
  });
}

// ── Scrape de la página del SAT ──────────────────────────────────────────────
async function scrapearSAT(rfc, idCif) {
  const url = `${SAT_URL}${idCif}_${rfc}`;
  console.log(`🌐 Scrapeando SAT: ${url}`);

  // ── Intentar HTTP nativo primero (~500ms) ──
  let fullText = null;
  const t0 = Date.now();
  try {
    fullText = await scrapearSATHttp(rfc, idCif);
    console.log(`✅ SAT extraído via HTTP en ${Date.now() - t0}ms`);
  } catch (httpErr) {
    console.warn(`⚠️  HTTP nativo falló (${httpErr.message}) — usando Playwright como fallback`);
  }

  // ── Si HTTP funcionó, parsear directo y devolver ──
  if (fullText) {
    return parsearTextoSAT(fullText, rfc, idCif);
  }

  // ── Fallback: Playwright (versión original) ──
  let context = null;
  try {
    const browser = await getSharedBrowser();
    consultasRealizadas++;

    context = await browser.newContext({
      userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      viewport: { width: 1280, height: 720 },
      javaScriptEnabled: true,
    });
    const page = await context.newPage();

    await page.route("**/*", (route) => {
      const type = route.request().resourceType();
      if (type === "image" || type === "media" || type === "font" || type === "stylesheet") {
        return route.abort();
      }
      return route.continue();
    });

    try {
      await page.goto(url, { waitUntil: "networkidle", timeout: 25000 });
    } catch (err) {
      throw new Error("timeout_descarga");
    }

    try {
      await page.waitForFunction(() => {
        const t = document.body.innerText.toLowerCase();
        return t.includes("rfc:") ||
               t.includes("datos de identificación") ||
               t.includes("datos de identificacion") ||
               t.includes("no se le ha emitido") ||
               t.includes("no se encontr") ||
               t.includes("no existe") ||
               t.includes("no se localiz");
      }, { timeout: 2000 });
    } catch (e) {}

    fullText = await page.evaluate(() => document.body.innerText);
    return parsearTextoSAT(fullText, rfc, idCif);

  } finally {
    if (context) {
      try { await context.close(); } catch (e) { console.warn(`⚠️  Error cerrando context SAT: ${e.message}`); }
    }
  }
}

// ── Parsear texto del SAT (común a HTTP y Playwright) ────────────────────────
function parsearTextoSAT(fullText, rfc, idCif) {
    console.log(`   [SAT raw primeros 200]: ${fullText.slice(0,200).replace(/\n/g,' ')}`);

    // ── Detectar RFC inválido / no encontrado ──────────────────────────────
    const lowerText = fullText.toLowerCase();
    const noEncontrado =
      lowerText.includes("no se le ha emitido") ||
      lowerText.includes("no se encontr") ||
      lowerText.includes("no existe") ||
      lowerText.includes("no se localiz");

    const tieneCedula = lowerText.includes("rfc:") || lowerText.includes("datos de identificación") || lowerText.includes("datos de identificacion");

    if (noEncontrado || !tieneCedula) {
      console.warn(`⚠️  SAT no devolvió constancia válida para RFC=${rfc} idCIF=${idCif}`);
      console.warn(`   Texto SAT (primeros 300): ${fullText.slice(0, 300).replace(/\n/g, ' ')}`);
      throw new Error("datos_invalidos");
    }

    // Escapar caracteres especiales de regex en la etiqueta
    const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

    // Extraer valor después de "Etiqueta:\tValor"
    const extraer = (etiqueta) => {
      const regex = new RegExp("^\\s*" + escapeRegex(etiqueta) + "\\s*:\\s*\\t?\\s*([^\\n\\t]+)", "im");
      const match = fullText.match(regex);
      return match ? match[1].trim() : "";
    };

    const ETIQUETAS = /^(Fecha [A-Za-z]|Datos|CP\s*:?\s*$|Correo|AL\s*:?\s*$|Nombre [a-z]|Apellido|Número [a-z]|Tipo de|Situación|Características|Municipio|Entidad|Colonia\s*:?\s*$|R[ée]gimen\s*(de\s+capital)?\s*:?\s*$|RFC\s*:?\s*$|CURP\s*:?\s*$|Denominaci[oó]n|Idiom|Estatus)/i;
    const limpiar = (v) => {
      if (!v) return "";
      if (v.endsWith(":")) return "";
      if (ETIQUETAS.test(v)) return "";
      return v;
    };

    const municipio = limpiar(extraer("Municipio o delegación"));
    const entidad   = limpiar(extraer("Entidad Federativa"));
    const regimen   = limpiar(extraer("Régimen"));
    const fechaAltaRawSucio = extraer("Fecha de alta");
    const fechaAltaRaw = limpiar(fechaAltaRawSucio);
    const fechaAlta = formatearFecha(fechaAltaRaw);

    // FIX Bug #37: extraer TODOS los regímenes (no solo el primero).
    // El SAT lista pares de filas: "Régimen: X" seguido de "Fecha de alta: Y".
    // Antes el código solo capturaba el primer match con extraer("Régimen").
    // Personas con múltiples regímenes (asalariados con arrendamiento, etc.)
    // perdían toda la info adicional en el PDF.
    function extraerTodosRegimenes(texto) {
      // Buscar pares: "Régimen: <valor>" + siguiente "Fecha de alta: <valor>"
      const regex = /Régimen\s*:\s*\t?\s*([^\n\t]+)(?:\s*\n\s*Fecha de alta\s*:\s*\t?\s*([^\n\t]+))?/gi;
      const matches = [];
      let m;
      while ((m = regex.exec(texto)) !== null) {
        const reg = (m[1] || "").trim();
        const fecha = (m[2] || "").trim();
        // Filtrar líneas tipo "Régimen de capital" (solo PM) y "Régimen:" sin valor
        if (!reg || reg.endsWith(":")) continue;
        if (/^de\s+capital/i.test(reg)) continue; // "Régimen de capital" no es un régimen fiscal
        // Filtrar valores que parecen otra etiqueta
        if (ETIQUETAS.test(reg)) continue;
        matches.push({
          regimen: reg,
          fechaInicio: fecha || fechaAltaRaw, // fallback a fechaAlta si no encuentra par
          fechaFin: ""
        });
      }
      return matches;
    }

    const todosLosRegimenes = extraerTodosRegimenes(fullText);

    if (!regimen) {
      console.warn(`⚠️  Régimen NO extraído. Raw extraer("Régimen") devolvió: "${extraer("Régimen")}"`);
      const idxReg = fullText.indexOf("Régimen");
      if (idxReg >= 0) {
        console.warn(`   Contexto SAT cerca de "Régimen": ${fullText.slice(idxReg, idxReg+200).replace(/\n/g,'⏎').replace(/\t/g,'→')}`);
      } else {
        console.warn(`   La palabra "Régimen" NO aparece en la respuesta del SAT — posible scrape vacío o RFC sin régimen`);
      }
    }

    const esPersonaMoral = rfc.length === 12;

    const datos = {
      rfc:          rfc.toUpperCase(),
      esPersonaMoral,
      curp:         limpiar(extraer("CURP")),
      nombres:      limpiar(extraer("Nombre")),
      apPaterno:    limpiar(extraer("Apellido Paterno")),
      apMaterno:    limpiar(extraer("Apellido Materno")),
      razonSocial:    limpiar(extraer("Denominación o Razón Social")) || limpiar(extraer("Denominacion o Razon Social")),
      regimenCapital: limpiar(extraer("Régimen de capital")) || limpiar(extraer("Regimen de capital")),
      fechaConstitucion: formatearFecha(limpiar(extraer("Fecha de constitución") || extraer("Fecha de constitucion"))),
      fechaInicio:  formatearFecha(limpiar(extraer("Fecha de Inicio de operaciones"))),
      estatus:      limpiar(extraer("Situación del contribuyente")),
      fechaCambio:  formatearFecha(limpiar(extraer("Fecha del último cambio de situación"))),
      entidad,
      municipio,
      colonia:      limpiar(extraer("Colonia")),
      tipoVialidad: limpiar(extraer("Tipo de vialidad")),
      vialidad:     limpiar(extraer("Nombre de la vialidad")),
      numExt:       limpiar(extraer("Número exterior")),
      numInt:       limpiar(extraer("Número interior")),
      cp:           limpiar(extraer("CP")),
      email:        limpiar(extraer("Correo electrónico")),
      localidad:    municipio,
      regimenes:    todosLosRegimenes.length > 0
                      ? todosLosRegimenes
                      : (regimen ? [{ regimen, fechaInicio: fechaAltaRaw, fechaFin: "" }] : []),
      actividades:  [],
      lugar:        `${municipio} , ${entidad}`,
      fechaEmision: `${municipio} , ${entidad} A ${fechaHoy()}`,
      cadenaOriginal: "",
      selloDigital:   "",
    };

    if (!esPersonaMoral && (regimen || "").toLowerCase().includes("sueldos y salarios")) {
      datos.actividades = [{ actividad: "Asalariado", porcentaje: "100", fechaInicio: fechaAltaRaw, fechaFin: "" }];
    }

    console.log(`✅ SAT scrapeado: ${datos.rfc} | ${esPersonaMoral ? datos.razonSocial : `${datos.nombres} ${datos.apPaterno} ${datos.apMaterno}`}`);
    console.log(`   CP: ${datos.cp} | Municipio: ${datos.municipio} | Entidad: ${datos.entidad}`);
    if (datos.regimenes.length > 1) {
      console.log(`   Regímenes (${datos.regimenes.length}):`);
      datos.regimenes.forEach((r, i) => console.log(`     ${i+1}. ${r.regimen} (${r.fechaInicio})`));
    } else {
      console.log(`   Régimen: ${datos.regimenes[0]?.regimen || "N/A"}${esPersonaMoral ? ` | Capital: ${datos.regimenCapital}` : ""}`);
    }
    return datos;
}

// ── Convertir fecha DD-MM-YYYY → DD DE MES DE YYYY ───────────────────────────
function formatearFecha(str) {
  if (!str) return "";
  const m = str.match(/^(\d{2})-(\d{2})-(\d{4})$/);
  if (m) return `${String(parseInt(m[1])).padStart(2,'0')} DE ${MESES[parseInt(m[2])-1]} DE ${m[3]}`;
  return str; // ya está en formato texto
}

// ── Generar QR PNG para la URL del SAT ───────────────────────────────────────
function generarQRPng(url, size = 300) {
  return new Promise((resolve, reject) => {
    try {
      qrcode.toBuffer(url, { width: size, margin: 1, errorCorrectionLevel: "M" }, (err, buf) => {
        if (err) reject(err);
        else resolve(buf);
      });
    } catch(e) {
      reject(e);
    }
  });
}

// ── Generar barcode PNG usando Python (mismo que generar_clon.py) ─────────────
function generarBarcodePng(rfc, sinTexto = false) {
  return new Promise((resolve, reject) => {
    const script = `
import sys, io, base64
from PIL import Image as PILImage, ImageDraw, ImageFont

CODE128B = {
  ' ':0,'!':1,'"':2,'#':3,'$':4,'%':5,'&':6,"'":7,'(':8,')':9,
  '*':10,'+':11,',':12,'-':13,'.':14,'/':15,'0':16,'1':17,'2':18,
  '3':19,'4':20,'5':21,'6':22,'7':23,'8':24,'9':25,':':26,';':27,
  '<':28,'=':29,'>':30,'?':31,'@':32,'A':33,'B':34,'C':35,'D':36,
  'E':37,'F':38,'G':39,'H':40,'I':41,'J':42,'K':43,'L':44,'M':45,
  'N':46,'O':47,'P':48,'Q':49,'R':50,'S':51,'T':52,'U':53,'V':54,
  'W':55,'X':56,'Y':57,'Z':58,
}
PATTERNS = [
  '11011001100','11001101100','11001100110','10010011000','10010001100',
  '10001001100','10011001000','10011000100','10001100100','11001001000',
  '11001000100','11000100100','10110011100','10011011100','10011001110',
  '10111001100','10011101100','10011100110','11001110010','11001011100',
  '11001001110','11011100100','11001110100','11101101110','11101001100',
  '11100101100','11100100110','11101100100','11100110100','11100110010',
  '11011011000','11011000110','11000110110','10100011000','10001011000',
  '10001000110','10110001000','10001101000','10001100010','11010001000',
  '11000101000','11000100010','10110111000','10110001110','10001101110',
  '10111011000','10111000110','10001110110','11101110110','11010001110',
  '11000101110','11011101000','11011100010','11011101110','11101011000',
  '11101000110','11100010110','11101101000','11101100010','11100011010',
  '11101111010','11001000010','11110001010','10100110000','10100001100',
  '10010110000','10010000110','10000101100','10000100110','10110010000',
  '10110000100','10011010000','10011000010','10000110100','10000110010',
  '11000010010','11001010000','11110111010','11000010100','10001111010',
  '10100111100','10010111100','10010011110','10111100100','10011110100',
  '10011110010','11110100100','11110010100','11110010010','11011011110',
  '11011110110','11110110110','10101111000','10100011110','10001011110',
  '10111101000','10111100010','11110101000','11110100010','10111011110',
  '10111101110','11101011110','11110101110','11010000100','11010010000',
  '11010011100',
]
STOP_PAT = '1100011101011'
START_B  = 104
rfc = '${rfc.toUpperCase()}'
SIN_TEXTO = ${sinTexto ? 'True' : 'False'}
vals = [START_B]
for c in rfc: vals.append(CODE128B.get(c, 0))
chk = START_B
for i,v in enumerate(vals[1:],1): chk += i*v
vals.append(chk % 103)
bars = ''.join(PATTERNS[v] if v < len(PATTERNS) else '11011001100' for v in vals)
bars += STOP_PAT + '11'
width = 580
height = 120 if SIN_TEXTO else 190
if SIN_TEXTO:
    margin_x,margin_top,text_pad = 8,4,0
    text_area_h = 0
    font = None
else:
    font_size,margin_x,margin_top,text_pad = 44,16,6,10
    font = None
    for fp in ['/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf',
               '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf']:
        try: font = ImageFont.truetype(fp, font_size); break
        except: pass
    if not font: font = ImageFont.load_default()
    dummy = PILImage.new('RGB',(1,1)); dd = ImageDraw.Draw(dummy)
    bbox = dd.textbbox((0,0), rfc, font=font)
    text_h = bbox[3]-bbox[1]; text_top = bbox[1]
    text_area_h = text_h + text_pad*2
bar_h = height - margin_top - text_area_h - (margin_top if SIN_TEXTO else 0)
bar_w = (width - 2*margin_x) / len(bars)
img = PILImage.new('RGB',(width,height),'white')
draw = ImageDraw.Draw(img)
x = float(margin_x)
for b in bars:
    nx = x + bar_w
    if b == '1': draw.rectangle([round(x),margin_top,round(nx)-1,margin_top+bar_h-1],fill='black')
    x = nx
if not SIN_TEXTO:
    bbox2 = draw.textbbox((0,0), rfc, font=font)
    text_w = bbox2[2]-bbox2[0]
    text_x = (width-text_w)//2
    text_y = margin_top + bar_h + text_pad - text_top
    draw.text((text_x,text_y), rfc, fill='black', font=font)
buf = io.BytesIO(); img.save(buf,'PNG'); buf.seek(0)
sys.stdout.buffer.write(buf.read())
`;
    execFile("python3", ["-c", script], { encoding: "buffer", timeout: 10000 }, (err, stdout, stderr) => {
      if (err) return reject(new Error(`barcode python: ${stderr?.toString().slice(0,200)}`));
      if (!stdout || stdout.length < 100) return reject(new Error("barcode vacío"));
      resolve(stdout);
    });
  });
}

// ── Reemplazar textos en el XML del DOCX ─────────────────────────────────────
function reemplazarEnXML(xml, de, a) {
  // Reemplazar texto que puede estar fragmentado en múltiples <w:t>
  // Primero intentar reemplazo directo
  const escaped = a.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
  return xml.split(de).join(escaped);
}

// ── Llenar la plantilla DOCX con los datos ────────────────────────────────────
async function llenarPlantilla(datos, rfc, idCif, downloadDir) {
  // Seleccionar plantilla según tipo de contribuyente:
  //  - Persona moral (RFC 12 chars) → plantilla 3
  //  - Persona física SUSPENDIDA (sin actividades ni regímenes) → plantilla suspendido
  //  - Persona física Sueldos y Salarios CON 1 SOLO RÉGIMEN → plantilla 1 (con tabla Actividades)
  //  - Persona física otro régimen O con múltiples regímenes → plantilla 2 (regímenes dinámicos)
  // FIX Bug #39: si la persona tiene múltiples regímenes, usar csf2 aunque el
  // primero sea "Sueldos y Salarios". La plantilla csf solo tiene {REGIMEN_1} y
  // perdería los demás. csf2 puede duplicar la fila para mostrarlos todos.
  const esPersonaMoral = datos.esPersonaMoral || datos.rfc?.length === 12;
  const reg1Plantilla  = datos.regimenes?.[0]?.regimen?.toLowerCase() || "";
  const tieneMultiplesRegimenes = (datos.regimenes?.length || 0) > 1;
  const usarPlantillaConActividades = !esPersonaMoral &&
                                       reg1Plantilla.includes("sueldos y salarios") &&
                                       !tieneMultiplesRegimenes;
  // Detección de suspendidos: estatus contiene "SUSPENDIDO" (puede venir con
  // variantes tipo "SUSPENDIDA", con acentos, espacios extra, etc.)
  const estatusUpper = (datos.estatus || "").toUpperCase();
  const esSuspendido = !esPersonaMoral && /SUSPEND/i.test(estatusUpper);

  const nombrePlantilla = esPersonaMoral
    ? "plantilla_csf3_template.docx"
    : esSuspendido
      ? "plantilla_csf_suspendido_template.docx"
      : usarPlantillaConActividades
        ? "plantilla_csf_template.docx"
        : "plantilla_csf2_template.docx";

  const plantillaPath = path.join(__dirname, nombrePlantilla);
  const tipoLog = esPersonaMoral
    ? "Persona Moral"
    : esSuspendido
      ? `Suspendido (${estatusUpper})`
      : tieneMultiplesRegimenes
        ? `${datos.regimenes.length} regímenes (multi)`
        : `régimen: ${reg1Plantilla || "N/A"}`;
  console.log(`📄 Plantilla seleccionada: ${nombrePlantilla} (${tipoLog})`);
  if (!fs.existsSync(plantillaPath)) {
    throw new Error(`Plantilla no encontrada: ${plantillaPath}`);
  }

  const zip    = new AdmZip(plantillaPath);
  let docXml   = zip.readAsText("word/document.xml");

  // ── Helpers ───────────────────────────────────────────────────────────────
  const esc = (s) => (s || "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
  const rep = (placeholder, valor) => {
    docXml = docXml.split(placeholder).join(esc(valor));
  };

  // ── Datos básicos ─────────────────────────────────────────────────────────
  const nombre = [datos.nombres, datos.apPaterno, datos.apMaterno]
    .filter(Boolean).join(" ").trim();

  rep("{RFC}",                rfc.toUpperCase());
  rep("{IDCIF_CADENA}",       idCif);  // ANTES que {IDCIF} para evitar colisión
  rep("{IDCIF}",              idCif);

  // ── Persona moral vs persona física ────────────────────────────────────────
  if (esPersonaMoral) {
    rep("{RAZON_SOCIAL}",     datos.razonSocial    || "");
    rep("{REGIMEN_CAPITAL}",  datos.regimenCapital || "");
    // En plantilla 3 no existen CURP/NOMBRES/AP_PATERNO/AP_MATERNO/NOMBRE_COMPLETO
    // pero por seguridad los limpiamos si aparecieran
    rep("{NOMBRE_COMPLETO}",  datos.razonSocial    || "");
    rep("{CURP}",             "");
    rep("{NOMBRES}",          "");
    rep("{AP_PATERNO}",       "");
    rep("{AP_MATERNO}",       "");
  } else {
    rep("{NOMBRE_COMPLETO}",  nombre);
    rep("{CURP}",             datos.curp       || "");
    rep("{NOMBRES}",          datos.nombres    || "");
    rep("{AP_PATERNO}",       datos.apPaterno  || "");
    rep("{AP_MATERNO}",       datos.apMaterno  || "");
  }

  rep("{FECHA_INICIO}",       datos.fechaInicio|| "");
  // FECHA_CAMBIO: fecha del último cambio de situación (cae a fechaInicio si está vacío)
  rep("{FECHA_CAMBIO}",       datos.fechaCambio || datos.fechaInicio || "");
  rep("{ESTATUS}",            datos.estatus    || "ACTIVO");

  // ── Lugar y fecha de emisión ──────────────────────────────────────────────
  // FIX visual: el cuadro de texto en las plantillas DOCX tiene altura fija
  // (~1.37cm) y por defecto el contenido se alinea arriba (atributo `anchor`
  // ausente en <wps:bodyPr> = top). Cuando la fecha es de 1 línea, el bloque
  // (título + fecha) queda pegado arriba y se ve raro.
  //
  // Solución: cuando el texto cabe en 1 línea, agregar `anchor="ctr"` al
  // <wps:bodyPr> del cuadro para centrar verticalmente. Si se parte en 2
  // líneas, dejamos el behavior por defecto (anchor=top).
  //
  // DETECCIÓN: cálculo preciso del ancho del texto en puntos tipográficos,
  // usando la tabla de anchos de Arial Bold (en em*1000). Comparamos contra
  // el ancho útil del cuadro (261.65 pt = 9.59 cm - padding 10.25 pt).
  // Esto es más preciso que contar caracteres porque considera que letras
  // anchas (M, N, W) ocupan más espacio que estrechas (I, L, J).
  //
  // Calibrado con 264 casos de prueba (11 lugares × 12 meses × 2 días).
  const ARIAL_BOLD_WIDTHS = {
    ' ':278,'!':333,'"':474,'#':556,'$':556,'%':889,'&':722,"'":238,'(':333,
    ')':333,'*':389,'+':584,',':278,'-':333,'.':278,'/':278,'0':556,'1':556,
    '2':556,'3':556,'4':556,'5':556,'6':556,'7':556,'8':556,'9':556,':':333,
    ';':333,'<':584,'=':584,'>':584,'?':611,'@':975,'A':722,'B':722,'C':722,
    'D':722,'E':667,'F':611,'G':778,'H':722,'I':278,'J':556,'K':722,'L':611,
    'M':833,'N':722,'O':778,'P':667,'Q':778,'R':722,'S':667,'T':611,'U':722,
    'V':667,'W':944,'X':667,'Y':667,'Z':611,'Ñ':722,'[':333,']':333,'_':556
  };
  const ANCHO_UTIL_PT = 261.65;  // 9.59 cm cuadro - 10.25 pt padding interno
  const calcularAnchoPt = (texto) => {
    let total = 0;
    for (const ch of texto) {
      total += ARIAL_BOLD_WIDTHS[ch] || 556;  // 556 = ancho medio (fallback)
    }
    return total * 0.01;  // (size 10pt / 1000 em-units) = 0.01
  };

  const lugarFecha = datos.fechaEmision ||
    `${datos.lugar || datos.municipio || ""} , ${datos.entidad || ""} A ${fechaHoy()}`;

  if (calcularAnchoPt(lugarFecha) <= ANCHO_UTIL_PT) {
    // Aplicar anchor="ctr" a los cuadros del placeholder LUGAR_FECHA_EMISION
    let posLF = 0;
    while ((posLF = docXml.indexOf("{LUGAR_FECHA_EMISION}", posLF)) !== -1) {
      const bodyPrStart = docXml.indexOf("<wps:bodyPr", posLF);
      if (bodyPrStart < 0) break;
      const bodyPrEnd = docXml.indexOf(">", bodyPrStart);
      const bodyPrTag = docXml.slice(bodyPrStart, bodyPrEnd + 1);
      if (!bodyPrTag.includes("anchor=")) {
        const bodyPrNuevo = bodyPrTag.slice(0, -1) + ' anchor="ctr">';
        docXml = docXml.slice(0, bodyPrStart) + bodyPrNuevo + docXml.slice(bodyPrEnd + 1);
        posLF = bodyPrStart + bodyPrNuevo.length;
      } else {
        posLF = bodyPrEnd + 1;
      }
    }

    // Espaciado +0.5pt antes del párrafo de la fecha (solo cuando es 1 línea).
    // En las plantillas el spacing por defecto es w:before="8" (0.4pt).
    // Subimos a w:before="18" (0.9pt) para igualar el look del CSF oficial.
    // Solo modificamos el spacing DENTRO del párrafo del placeholder, no en otros.
    let posSp = 0;
    while ((posSp = docXml.indexOf("{LUGAR_FECHA_EMISION}", posSp)) !== -1) {
      // Encontrar el <w:p ABRE más cercano (con o sin atributos)
      const pWithAttrs = docXml.lastIndexOf('<w:p ', posSp);
      const pNoAttrs   = docXml.lastIndexOf('<w:p>', posSp);
      const pStart = Math.max(pWithAttrs, pNoAttrs);
      if (pStart < 0) { posSp += 1; continue; }
      const pEnd = docXml.indexOf('</w:p>', posSp);
      if (pEnd < 0) break;
      const parrafo = docXml.slice(pStart, pEnd);
      // Reemplazar w:before="8" → w:before="18" SOLO dentro de <w:spacing>
      const parrafoNuevo = parrafo.replace(
        /(<w:spacing[^>]*\bw:before=)"8"/g,
        '$1"18"'
      );
      if (parrafoNuevo !== parrafo) {
        docXml = docXml.slice(0, pStart) + parrafoNuevo + docXml.slice(pEnd);
        posSp = pStart + parrafoNuevo.length + 6;  // 6 = "</w:p>"
      } else {
        posSp = pEnd + 6;
      }
    }
  }

  // Reemplazar el placeholder con el texto real.
  rep("{LUGAR_FECHA_EMISION}", lugarFecha);

  // ── Domicilio ─────────────────────────────────────────────────────────────
  rep("{CP}",           datos.cp            || "");
  rep("{TIPO_VIALIDAD}",datos.tipoVialidad  || "");
  rep("{VIALIDAD}",     datos.vialidad      || "");
  rep("{NUM_EXT}",      datos.numExt        || "");
  rep("{NUM_INT}",      datos.numInt        || "");
  rep("{COLONIA}",      datos.colonia       || "");
  rep("{MUNICIPIO}",    datos.municipio     || datos.localidad || "");
  rep("{ENTIDAD}",      datos.entidad       || "");
  // ── Actividades — solo aplica en plantilla 1 (Sueldos y Salarios → Asalariado) ──
  // FIX Bug #16: SIEMPRE reemplazar {ACTIVIDAD_1} aunque la plantilla no la use,
  // para evitar que el placeholder textual aparezca visible en el documento si
  // por alguna razón se cuela en una plantilla que no debería tenerlo.
  const reg1 = datos.regimenes?.[0];
  const esAsalariado = reg1?.regimen?.toLowerCase().includes("sueldos y salarios");
  if (usarPlantillaConActividades) {
    rep("{ACTIVIDAD_1}", esAsalariado ? "Asalariado" : (datos.actividades?.[0]?.actividad || ""));
  } else {
    rep("{ACTIVIDAD_1}", ""); // limpiar por si la plantilla seleccionada lo tuviera
  }

  // ── Regímenes ─────────────────────────────────────────────────────────────
  // FIX Bug #38: csf2 (otros regímenes) ahora soporta múltiples regímenes
  // dinámicamente. Si hay más de 1, se duplica la fila <w:tr> que contiene
  // {REGIMEN_1} y {FECHA_ACT}, una por cada régimen del contribuyente.
  // csf y csf3 mantienen el comportamiento original (1 régimen).
  const regimenes = datos.regimenes || [];
  const usarPlantilla2 = !esPersonaMoral && !usarPlantillaConActividades;

  if (usarPlantilla2 && regimenes.length > 1) {
    // Encontrar la fila <w:tr> que contiene {REGIMEN_1}
    const idxR1 = docXml.indexOf("{REGIMEN_1}");
    if (idxR1 >= 0) {
      const trInicio = docXml.lastIndexOf("<w:tr ", idxR1);
      const trFinIdx = docXml.indexOf("</w:tr>", idxR1);
      if (trInicio >= 0 && trFinIdx >= 0) {
        const trFin = trFinIdx + "</w:tr>".length;
        const filaTemplate = docXml.substring(trInicio, trFin);

        // Construir N filas, una por cada régimen
        const filas = regimenes.map((reg) => {
          const fechaActRaw = reg.fechaInicio || "";
          const fechaActFmt = fechaActRaw.replace(/^(\d{2})-(\d{2})-(\d{4})$/, "$1/$2/$3");
          return filaTemplate
            .split("{REGIMEN_1}").join(esc(reg.regimen || ""))
            .split("{FECHA_ACT}").join(esc(fechaActFmt));
        }).join("");

        // Reemplazar la fila original por las N filas
        docXml = docXml.substring(0, trInicio) + filas + docXml.substring(trFin);
        console.log(`📋 Plantilla csf2: ${regimenes.length} regímenes renderizados`);
      } else {
        // Fallback al comportamiento simple si no encuentra la <w:tr>
        rep("{REGIMEN_1}", regimenes[0]?.regimen || "");
        const fechaRaw = regimenes[0]?.fechaInicio || "";
        rep("{FECHA_ACT}", fechaRaw.replace(/^(\d{2})-(\d{2})-(\d{4})$/, "$1/$2/$3"));
      }
    }
  } else {
    // Caso simple: 1 régimen (csf, csf3, o csf2 con 1 solo)
    const reg1Plantilla2 = regimenes[0];
    rep("{REGIMEN_1}", reg1Plantilla2?.regimen || "");

    // ── Fecha actividad/régimen — formato DD/MM/YYYY ─────────────────────────
    const fechaActRaw = reg1Plantilla2?.fechaInicio || "";
    const fechaActFmt = fechaActRaw.replace(/^(\d{2})-(\d{2})-(\d{4})$/, "$1/$2/$3");
    rep("{FECHA_ACT}", fechaActFmt);
  }

  // ── Cadena original — solo rotar timestamp y RFC, sello queda igual ─────────
  const ts = timestampCDMX(); // YYYY/MM/DD HH:MM:SS en hora CDMX
  rep("{TIMESTAMP_CADENA}", ts);
  rep("{HASH_CADENA}",      "");

  // ── Sello digital — NO se modifica, queda como en la plantilla ───────────
  // Eliminar los placeholders sin reemplazar
  rep("{SELLO_PARTE1}", "");
  rep("{SELLO_PARTE2}", "");

  zip.updateFile("word/document.xml", Buffer.from(docXml, "utf-8"));

  // ── Reemplazar imágenes ────────────────────────────────────────────────────
  // Barcode (image6)
  try {
    // Plantillas csf y csf2 tienen placeholder {RFC} debajo del barcode
    // → barcode SIN texto. csf3 mantiene texto dibujado en el PNG.
    const sinTextoBarcode = nombrePlantilla !== "plantilla_csf3_template.docx";
    const barcodePng = await generarBarcodePng(rfc, sinTextoBarcode);
    zip.updateFile("word/media/image6.png", barcodePng);
    console.log(`✅ Barcode generado`);
  } catch(e) {
    console.warn(`⚠️  Barcode falló: ${e.message}`);
  }

  // ── QR 1: cédula frontal → SAT real (image2, image4) ─────────────────────
  // ── QR 2: segunda hoja  → réplica siat-sat.site (image11) ────────────────
  try {
    const qrKey    = `${idCif}_${rfc}`;
    const qrBase   = process.env.QR_BASE_URL || "https://siat-sat.site";

    // QR 1 → SAT real
    const qrUrlSAT    = `https://siat.sat.gob.mx/app/qr/faces/pages/mobile/validadorqr.jsf?D1=10&D2=1&D3=${qrKey}`;
    const qrPngSAT    = await generarQRPng(qrUrlSAT, 300);
    // zip.updateFile("word/media/image2.png", qrPngSAT);  // FIX: imagen no existe en nuevas plantillas
    zip.updateFile("word/media/image4.png", qrPngSAT);
    console.log(`✅ QR1 (SAT real) → ${qrUrlSAT}`);

    // QR 2 → réplica siat-sat.site
    const qrUrlReplica = `${qrBase}/qr?D1=10&D2=1&D3=${qrKey}`;
    const qrPngReplica = await generarQRPng(qrUrlReplica, 300);
    zip.updateFile("word/media/image7.png", qrPngReplica);
    console.log(`✅ QR2 (réplica)  → ${qrUrlReplica}`);

    // Guardar RFC + cadena original para que la página réplica los muestre
    // La cadena se construye igual que el placeholder {TIMESTAMP_CADENA} ya aplicado en el DOCX
    const cadenaOriginal = `||${ts}|${rfc}|CONSTANCIA DE SITUACIÓN FISCAL|200001088888800000041|U2FsdGVkX1/DroT2rJrgYGJjW6W9qAJnlEJWv/z818+sndE3ANPr3s7tw4Tkafz3||`;
    const qrDatos = {
      rfc,
      cadena_original: cadenaOriginal,
    };

    // POST a qr-server /qr/save
    const qrPort = process.env.QR_PORT || 3000;
    const payload = JSON.stringify({ key: qrKey, datos: qrDatos });
    await new Promise((resolve) => {
      const req = http.request({
        hostname: "localhost", port: qrPort,
        path: "/qr/save", method: "POST",
        headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(payload) },
        timeout: 5000,
      }, (res) => { res.resume(); res.on("end", resolve); });
      req.on("error", (e) => { console.warn(`⚠️  qr/save falló: ${e.message}`); resolve(); });
      req.on("timeout", () => { req.destroy(); console.warn("⚠️  qr/save timeout"); resolve(); });
      req.write(payload);
      req.end();
    });
    console.log(`✅ Datos QR guardados (key: ${qrKey})`);
  } catch(e) {
    console.warn(`⚠️  QR falló: ${e.message}`);
  }

  // ── Guardar DOCX ──────────────────────────────────────────────────────────
  const docxTs   = Date.now();
  const docxPath = path.join(downloadDir, `${rfc}_csf_${docxTs}.docx`);
  zip.writeZip(docxPath);
  return docxPath;
}

// ── Conversión DOCX → PDF: ahora delega a onlyofficeClient.js ────────────────
// (la función convertirAPdf original fue movida a onlyofficeClient.js
//  como convertirDocxAPdf, con mejoras de reintento y validación de PDF.
//  Ver FIX Bug #55 al inicio del archivo.)

// ── Función principal ────────────────────────────────────────────────────────
async function generarCSFLocal({ rfc, idCif, downloadDir, lugar = "", formato = "pdf", soloDocx = false }) {
  if (!rfc || !idCif || !downloadDir) {
    throw new Error("Se requieren: rfc, idCif, downloadDir");
  }
  rfc   = rfc.toUpperCase().trim();
  idCif = idCif.trim();

  // FIX: validar formato estricto de RFC e idCIF antes de usarlos en URLs/paths.
  // El RFC viene de QRs escaneados del cliente, podría contener caracteres
  // maliciosos que se inyecten en la URL del SAT o en el path del DOCX.
  if (!/^[A-ZÑ&]{3,4}\d{6}[A-Z0-9]{3}$/i.test(rfc)) {
    throw new Error("datos_invalidos"); // RFC con formato inválido
  }
  if (!/^\d{6,30}$/.test(idCif)) {
    throw new Error("datos_invalidos"); // idCIF debe ser solo dígitos
  }

  // 1. Scrape SAT
  const datos = await scrapearSAT(rfc, idCif);

  // Sobrescribir lugar/fechaEmision si el usuario los proporcionó
  if (lugar) {
    datos.lugar = lugar.toUpperCase().trim();
    datos.fechaEmision = `${lugar.toUpperCase().trim()} A ${fechaHoy()}`;
  }

  // 2. Llenar plantilla
  const docxPath = await llenarPlantilla(datos, rfc, idCif, downloadDir);
  console.log(`✅ DOCX generado: ${docxPath}`);

  // Si piden DOCX explícitamente (formato==='docx' o legacy soloDocx===true), regresarlo
  if (formato === "docx" || soloDocx) return docxPath;

  // 3. Convertir a PDF
  // FIX Bug #55: usa el cliente compartido. Si OnlyOffice falla con error
  // permanente, devuelve DOCX (fallback histórico). Si falla con error
  // transitorio, el cliente ya reintentó internamente.
  try {
    const pdfPath = await convertirDocxAPdf(docxPath);
    try { fs.unlinkSync(docxPath); } catch(e) {}
    console.log(`✅ PDF generado: ${pdfPath}`);
    return pdfPath;
  } catch(err) {
    console.warn(`⚠️  OnlyOffice falló, entregando DOCX: ${err.message}`);
    return docxPath;
  }
}

// ── Prueba desde línea de comandos ───────────────────────────────────────────
// Uso: node generarCSFLocal.js RFC idCIF /ruta/descargas
if (require.main === module) {
  const [rfc, idCif, downloadDir] = process.argv.slice(2);
  if (!rfc || !idCif || !downloadDir) {
    console.error("Uso: node generarCSFLocal.js RFC idCIF /ruta/descargas");
    process.exit(1);
  }
  generarCSFLocal({ rfc, idCif, downloadDir })
    .then(p => console.log("Archivo:", p))
    .catch(e => { console.error("Error:", e.message); process.exit(1); });
}

// Cerrar el browser pool (llamar desde apagadoLimpio del bot)
async function cerrarBrowserSAT() {
  if (browserShared) {
    try {
      await browserShared.close();
      console.log("✅ Browser SAT cerrado");
    } catch (e) { console.warn(`⚠️  Error cerrando browser SAT: ${e.message}`); }
    browserShared = null;
  }
}

module.exports = { generarCSFLocal, cerrarBrowserSAT };
