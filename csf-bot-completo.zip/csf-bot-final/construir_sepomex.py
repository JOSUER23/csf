#!/usr/bin/env python3
"""
─────────────────────────────────────────────────────────────────────────────
construir_sepomex.py
─────────────────────────────────────────────────────────────────────────────
Lee el archivo oficial de SEPOMEX (CPdescarga.txt, pipe-separated, ~150K líneas)
y construye un JSON optimizado e indexado para uso en runtime.

Estructura del JSON resultante:
{
  "version": "2026-05-19",
  "total_registros": 145908,
  "estados": {
    "CHIAPAS": {
      "TUXTLA GUTIÉRREZ": {
        "cps": ["29000", "29010", "29015", ...],
        "colonias": {
          "29000": ["CENTRO", "GUADALUPE", ...],
          "29010": ["LAS PALMAS", ...],
          ...
        }
      },
      "LA CONCORDIA": { ... },
      ...
    },
    "VERACRUZ": { ... },
    ...
  }
}

Uso:
    python3 construir_sepomex.py
    
Lee:   /tmp/sepomex_csv/CPdescarga.txt
Crea:  /root/csf-bot/sepomex_db.json
─────────────────────────────────────────────────────────────────────────────
"""
import os, sys, json, re
from collections import defaultdict
from datetime import date

INPUT_FILE  = "/tmp/sepomex_csv/CPdescarga.txt"
OUTPUT_FILE = "/root/csf-bot/sepomex_db.json"

# Mapeo de nombres de estado (algunos vienen con variantes)
NORMALIZACION_ESTADO = {
    "CIUDAD DE MEXICO": "CIUDAD DE MÉXICO",
    "DISTRITO FEDERAL": "CIUDAD DE MÉXICO",
    "MEXICO":           "MÉXICO",
    "MEXICO ESTADO":    "MÉXICO",
    "VERACRUZ DE IGNACIO DE LA LLAVE": "VERACRUZ",
    "MICHOACAN DE OCAMPO": "MICHOACÁN",
    "COAHUILA DE ZARAGOZA": "COAHUILA",
}


def quitar_acentos(s):
    """Normaliza string: mayúsculas + sin acentos. Para comparar."""
    if not s: return ""
    import unicodedata
    s = unicodedata.normalize('NFKD', s).encode('ascii', 'ignore').decode('ascii')
    return s.upper().strip()


def main():
    if not os.path.exists(INPUT_FILE):
        print(f"❌ No existe {INPUT_FILE}")
        print(f"   Ejecuta primero: bash descargar_sepomex.sh")
        sys.exit(1)

    print(f"Leyendo {INPUT_FILE}...")
    tamano = os.path.getsize(INPUT_FILE) / (1024 * 1024)
    print(f"  Tamaño: {tamano:.1f} MB")

    # Detectar encoding (SEPOMEX usa latin-1 / cp1252 históricamente)
    encodings = ['latin-1', 'cp1252', 'utf-8']
    contenido = None
    for enc in encodings:
        try:
            with open(INPUT_FILE, encoding=enc) as f:
                contenido = f.read()
            print(f"  Encoding: {enc}")
            break
        except UnicodeDecodeError:
            continue
    if contenido is None:
        print("❌ No se pudo detectar encoding del archivo")
        sys.exit(1)

    lineas = contenido.split('\n')
    print(f"  Líneas totales: {len(lineas)}")

    # Detectar el separador y las columnas
    # SEPOMEX usa '|' como separador
    # Primera línea: header con nombre de columnas
    # Pero el archivo a veces tiene una línea de "advertencia" antes del header
    
    header_idx = None
    for i, linea in enumerate(lineas[:5]):
        if 'd_codigo' in linea.lower() or 'd_asenta' in linea.lower():
            header_idx = i
            break
    
    if header_idx is None:
        # Buscar línea con muchos pipes
        for i, linea in enumerate(lineas[:5]):
            if linea.count('|') > 8:
                header_idx = i
                break
    
    if header_idx is None:
        print("❌ No pude encontrar el header del CSV")
        print("Primeras 5 líneas:")
        for i, l in enumerate(lineas[:5]):
            print(f"  {i}: {l[:200]}")
        sys.exit(1)
    
    header = lineas[header_idx].split('|')
    print(f"  Header detectado en línea {header_idx}")
    print(f"  Columnas: {header}")
    
    # Mapeo de índices según el header real
    def get_idx(*nombres):
        for nombre in nombres:
            for i, col in enumerate(header):
                if col.strip().lower() == nombre.lower():
                    return i
        return None
    
    idx_cp        = get_idx('d_codigo', 'cp')
    idx_colonia   = get_idx('d_asenta', 'asentamiento', 'colonia')
    idx_municipio = get_idx('D_mnpio', 'd_mnpio', 'municipio')
    idx_estado    = get_idx('d_estado', 'estado')
    
    if None in (idx_cp, idx_colonia, idx_municipio, idx_estado):
        print(f"❌ No pude mapear columnas. Encontrado:")
        print(f"   cp={idx_cp}, colonia={idx_colonia}, municipio={idx_municipio}, estado={idx_estado}")
        sys.exit(1)
    
    print(f"  Índices: cp={idx_cp} colonia={idx_colonia} mun={idx_municipio} est={idx_estado}")
    print()
    
    # ── Parsear líneas ────────────────────────────────────────────────────
    print("Procesando registros...")
    estados = defaultdict(lambda: defaultdict(lambda: {'cps': set(), 'colonias': defaultdict(set)}))
    procesados = 0
    saltados = 0
    
    for i, linea in enumerate(lineas[header_idx + 1:], start=header_idx + 1):
        if not linea.strip():
            continue
        
        campos = linea.split('|')
        if len(campos) < max(idx_cp, idx_colonia, idx_municipio, idx_estado) + 1:
            saltados += 1
            continue
        
        try:
            cp        = campos[idx_cp].strip().zfill(5)
            colonia   = campos[idx_colonia].strip().upper()
            municipio = campos[idx_municipio].strip().upper()
            estado    = campos[idx_estado].strip().upper()
            
            # Normalizar nombre de estado
            estado_norm = NORMALIZACION_ESTADO.get(quitar_acentos(estado), estado)
            
            if not cp or not municipio or not estado:
                saltados += 1
                continue
            
            # Limpiar CP: solo dígitos, 5 chars
            cp = re.sub(r'\D', '', cp).zfill(5)
            if len(cp) != 5 or cp == '00000':
                saltados += 1
                continue
            
            estados[estado_norm][municipio]['cps'].add(cp)
            estados[estado_norm][municipio]['colonias'][cp].add(colonia)
            procesados += 1
        except Exception as e:
            saltados += 1
            continue
        
        if (i + 1) % 25000 == 0:
            print(f"  Línea {i+1}/{len(lineas)}: {procesados} OK, {saltados} saltados")
    
    print(f"\nProcesado:")
    print(f"  Registros válidos: {procesados}")
    print(f"  Registros saltados: {saltados}")
    print(f"  Estados: {len(estados)}")
    
    # ── Convertir sets a listas (JSON no soporta sets) ───────────────────
    print("\nConvirtiendo a JSON serializable...")
    estados_final = {}
    for estado, municipios in estados.items():
        estados_final[estado] = {}
        for mun, data in municipios.items():
            estados_final[estado][mun] = {
                'cps':      sorted(data['cps']),
                'colonias': {cp: sorted(cols) for cp, cols in data['colonias'].items()}
            }
    
    # ── Estadísticas ──────────────────────────────────────────────────────
    total_municipios = sum(len(muns) for muns in estados_final.values())
    total_cps        = sum(len(d['cps']) for muns in estados_final.values() for d in muns.values())
    total_colonias   = sum(len(cols) for muns in estados_final.values() 
                           for d in muns.values() 
                           for cols in d['colonias'].values())
    
    print(f"  Estados:    {len(estados_final)}")
    print(f"  Municipios: {total_municipios}")
    print(f"  CPs:        {total_cps}")
    print(f"  Colonias:   {total_colonias}")
    
    # ── Guardar JSON ──────────────────────────────────────────────────────
    salida = {
        'version':         str(date.today()),
        'fuente':          'SEPOMEX vía datos.gob.mx',
        'total_registros': procesados,
        'estados':         estados_final,
    }
    
    print(f"\nGuardando en {OUTPUT_FILE}...")
    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
        json.dump(salida, f, ensure_ascii=False, separators=(',', ':'))
    
    tamano_salida = os.path.getsize(OUTPUT_FILE) / (1024 * 1024)
    print(f"  Tamaño: {tamano_salida:.1f} MB")
    print()
    print(f"✓ Listo. Siguiente paso: reiniciar el bot (pm2 restart csf-bot)")


if __name__ == '__main__':
    main()
