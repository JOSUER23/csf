# 🚀 INSTALACIÓN COMPLETA — SPARTAN CSF BOT en Debian 12 fresh

> Esta guía instala TODO desde cero en un servidor Debian 12 limpio.
> Tiempo estimado: 20-30 minutos.
>
> **Versión del bot:** 2.1.0 (post-auditoría 2026-05-27 con 27 fixes aplicados)
> **Probado en:** Hetzner CPX21 / Contabo VPS S equivalente.
> **Recursos mínimos:** 4GB RAM, 2 vCPU, 40GB disco.

---

## ⚠️ FIXES CRÍTICOS — Léelos ANTES de empezar

Estos 3 fixes son **OBLIGATORIOS**. Sin ellos, el bot tiene problemas conocidos. La guía ya los incluye en los bloques correspondientes, pero los resalto aquí porque son los causantes de fallo #1 en instalaciones nuevas:

### Fix #1 — UFW debe permitir el tráfico Docker → host:3000
Sin esta regla, OnlyOffice (en Docker) NO puede descargar los DOCX del qr-server (en el host). Resultado: `Connection timed out` desde el contenedor a `172.17.0.1:3000`.

```bash
ufw allow from 172.17.0.0/16 to any port 3000 proto tcp
```

→ Incluido en **Bloque 2** (Configuración inicial)

### Fix #2 — OnlyOffice 9.x bloquea IPs privadas por default
Cambio reciente en OnlyOffice 9.x: prohíbe descargas desde IPs privadas (172.17.0.1) por anti-SSRF. Resultado: `Error: DNS lookup 172.17.0.1 is not allowed. Because, It is private IP address`.

```bash
docker run -d --restart=always \
  --name onlyoffice \
  -p 8083:80 \
  -e JWT_ENABLED=false \
  -e ALLOW_PRIVATE_IP_ADDRESS=true \
  -e ALLOW_META_IP_ADDRESS=true \
  -e USE_UNAUTHORIZED_STORAGE=true \
  onlyoffice/documentserver
```

→ Incluido en **Bloque 5** (Docker + OnlyOffice)

### Fix #3 — `municipios_clave_cache.json` debe estar en /root/csf-bot/
Sin este archivo (71 KB), el bot NO resuelve claves INEGI a nombres de municipios y cae al fallback de "capital del estado" — produciendo errores como `CHILPANCINGO` cuando el municipio real era `COYUCA DE BENITEZ`.

```bash
ls -la /root/csf-bot/municipios_clave_cache.json   # debe existir
```

→ Incluido en el ZIP. Detalle en **Bloque 8** (SEPOMEX)

**Si después de instalar ves "DOCX generado" pero NO "PDF generado" en los logs → es uno de los fixes #1 o #2.**
**Si ves el municipio cambiado a la capital del estado → es el fix #3.**

Ve a la sección [Troubleshooting](#-troubleshooting) para diagnóstico paso a paso.

---

## 📋 ÍNDICE

1. [Pre-requisitos del servidor](#1-pre-requisitos)
2. [Configuración inicial del sistema](#2-configuración-inicial)
3. [Instalar Node.js 22 LTS](#3-nodejs)
4. [Instalar Python 3 + dependencias](#4-python)
5. [Instalar Docker y OnlyOffice](#5-docker--onlyoffice)
6. [Instalar Nginx + SSL (subdominios QR)](#6-nginx--ssl)
7. [Subir el bot y configurar](#7-subir-bot)
8. [Construir base de datos SEPOMEX](#8-sepomex)
9. [Instalar dependencias del bot](#9-deps-bot)
10. [PM2 y arranque](#10-pm2)
11. [Escanear QR de WhatsApp](#11-whatsapp)
12. [Verificación final](#12-verificación)
13. [Configurar backup automático](#13-backup)

---

## 1. PRE-REQUISITOS

### En tu DNS (GoDaddy)
- Apunta `siat-sat.site` (A record) → IP del nuevo servidor
- Apunta `validador.siat-sat.site` (A record) → IP del nuevo servidor
- Espera 5-15 min para propagación (verifica con `dig siat-sat.site`)

### En el servidor (acceso SSH como root)
```bash
ssh root@<IP-DEL-SERVIDOR>
```

---

## 2. CONFIGURACIÓN INICIAL

```bash
# Actualizar sistema
apt-get update && apt-get upgrade -y

# Zona horaria (importante para que el bot calcule bien las horas CDMX)
timedatectl set-timezone UTC
date  # debe mostrar UTC

# Hostname
hostnamectl set-hostname bot-csf

# Firewall básico
apt-get install -y ufw
ufw allow 22/tcp     # SSH
ufw allow 80/tcp     # HTTP (Nginx)
ufw allow 443/tcp    # HTTPS (Nginx)

# ⚠️ CRÍTICO: Permitir tráfico desde Docker bridge al qr-server (puerto 3000)
# Sin esta regla, OnlyOffice (que corre en Docker) NO puede descargar los
# DOCX del qr-server (que corre en el host). El error sería "Connection
# timed out" desde el contenedor hacia 172.17.0.1:3000.
ufw allow from 172.17.0.0/16 to any port 3000 proto tcp

ufw --force enable
ufw status

# Herramientas básicas
apt-get install -y curl wget git build-essential ca-certificates gnupg lsb-release \
                   software-properties-common htop nano vim unzip

# Crear carpeta de trabajo
mkdir -p /root/csf-bot
mkdir -p /root/csf-bot/logs
mkdir -p /root/csf-bot/descargas
mkdir -p /root/csf-bot/qr-data
mkdir -p /root/csf-bot/tmp-conv
mkdir -p /root/csf-bot/auth_wa_baileys
mkdir -p /root/backups
```

---

## 3. NODE.JS 22 LTS

```bash
# Instalar Node 22 LTS desde NodeSource
curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
apt-get install -y nodejs

# Verificar
node --version  # debe decir v22.x.x
npm --version

# Instalar PM2 globalmente
npm install -g pm2

# PM2 al arranque
pm2 startup systemd -u root --hp /root
```

---

## 4. PYTHON 3 + DEPENDENCIAS

```bash
# Python ya viene en Debian 12, instalamos las dependencias del bot
apt-get install -y python3 python3-pip python3-venv

# Librería Pillow (para generación de barcodes)
apt-get install -y python3-pil

# Fuentes para PIL (necesarias para texto en barcodes)
apt-get install -y fonts-liberation fonts-dejavu

# Verificar
python3 --version
python3 -c "from PIL import Image, ImageDraw, ImageFont; print('PIL OK')"
```

---

## 5. DOCKER + ONLYOFFICE

### Instalar Docker
```bash
# Repo oficial
install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/debian/gpg -o /etc/apt/keyrings/docker.asc
chmod a+r /etc/apt/keyrings/docker.asc
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/debian $(. /etc/os-release && echo "$VERSION_CODENAME") stable" \
  | tee /etc/apt/sources.list.d/docker.list > /dev/null

apt-get update
apt-get install -y docker-ce docker-ce-cli containerd.io

# Verificar
docker --version
docker run hello-world
```

### Levantar OnlyOffice Document Server

```bash
# Crear contenedor de OnlyOffice (puerto 8083 en el host)
#
# ⚠️ CRÍTICO: las variables ALLOW_PRIVATE_IP_ADDRESS y ALLOW_META_IP_ADDRESS
# son OBLIGATORIAS en OnlyOffice 9.x+. Sin ellas, OnlyOffice bloquea por
# seguridad cualquier descarga desde IPs privadas (como 172.17.0.1, el
# gateway de Docker bridge donde corre el qr-server) y la conversión falla
# con: "Error: DNS lookup 172.17.0.1 is not allowed. Because, It is private IP".
#
# USE_UNAUTHORIZED_STORAGE permite usar HTTP sin SSL para el storage interno
# (qr-server local), que es el caso correcto aquí porque solo se accede
# desde localhost/red Docker.
docker run -d --restart=always \
  --name onlyoffice \
  -p 8083:80 \
  -e JWT_ENABLED=false \
  -e ALLOW_PRIVATE_IP_ADDRESS=true \
  -e ALLOW_META_IP_ADDRESS=true \
  -e USE_UNAUTHORIZED_STORAGE=true \
  onlyoffice/documentserver

# Verificar (esperar ~45s a que arranque)
echo "Esperando 45 segundos a que OnlyOffice arranque..."
sleep 45
curl http://localhost:8083/welcome/ -I
# Debe responder HTTP/1.1 200 OK

# Verificar Gateway (debe ser 172.17.0.1)
docker inspect onlyoffice | grep '"Gateway"'
# Si NO es 172.17.0.1 → editarás ecosystem.config.js → SERVER_IP

# ── Verificación funcional: OnlyOffice puede llegar al qr-server ──
# Este test DEBE pasar antes de continuar. Si falla, revisa la regla
# UFW que permite 172.17.0.0/16 → puerto 3000 (ver Bloque 2).
# El qr-server aún no está corriendo aquí, pero el test correcto se
# hace en el Bloque 12 (verificación final).
```

### 🛠️ Si OnlyOffice ya estaba creado SIN estas variables

Si en algún momento creas el contenedor sin las variables (o lo hereda de otra instalación), debes recrearlo:

```bash
# Detener y eliminar contenedor actual
docker stop onlyoffice
docker rm onlyoffice

# Recrear con la configuración correcta (mismo comando de arriba)
docker run -d --restart=always \
  --name onlyoffice \
  -p 8083:80 \
  -e JWT_ENABLED=false \
  -e ALLOW_PRIVATE_IP_ADDRESS=true \
  -e ALLOW_META_IP_ADDRESS=true \
  -e USE_UNAUTHORIZED_STORAGE=true \
  onlyoffice/documentserver

sleep 45
```

---

## 6. NGINX + SSL

### Instalar Nginx + Certbot
```bash
apt-get install -y nginx certbot python3-certbot-nginx

# Verificar
systemctl status nginx
nginx -v
```

### Configurar siat-sat.site (réplica QR para CSF)
```bash
cat > /etc/nginx/sites-available/siat-sat.site <<'EOF'
server {
    listen 80;
    server_name siat-sat.site;

    # Proxy al qr-server (puerto 3000)
    location / {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # Timeouts razonables
        proxy_connect_timeout 5s;
        proxy_send_timeout    10s;
        proxy_read_timeout    10s;

        # Bloquear acceso a rutas internas /tmp/*
        # Nginx no debe pasar estas al qr-server desde internet
    }

    # Bloquear /tmp/* (uso interno OnlyOffice ↔ qr-server)
    location ~ ^/tmp/ {
        deny all;
        return 403;
    }
}
EOF
ln -sf /etc/nginx/sites-available/siat-sat.site /etc/nginx/sites-enabled/

# Configurar validador.siat-sat.site (réplica QR para clones)
cat > /etc/nginx/sites-available/validador.siat-sat.site <<'EOF'
server {
    listen 80;
    server_name validador.siat-sat.site;

    location / {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        proxy_connect_timeout 5s;
        proxy_send_timeout    10s;
        proxy_read_timeout    10s;
    }

    location ~ ^/tmp/ {
        deny all;
        return 403;
    }
}
EOF
ln -sf /etc/nginx/sites-available/validador.siat-sat.site /etc/nginx/sites-enabled/

# Quitar default si existe
rm -f /etc/nginx/sites-enabled/default

# Probar config y recargar
nginx -t
systemctl reload nginx
```

### Obtener SSL (Let's Encrypt)
```bash
# IMPORTANTE: el DNS ya debe estar propagado antes de este paso
certbot --nginx -d siat-sat.site -d validador.siat-sat.site \
  --non-interactive --agree-tos --email tu-correo@example.com

# Verificar renovación automática
systemctl status certbot.timer
certbot renew --dry-run
```

---

## 7. SUBIR EL BOT

### Opción A: Subir vía FileZilla (recomendado para Josue)
1. Conecta FileZilla a `<IP-DEL-SERVIDOR>` puerto 22, user `root`
2. Sube TODOS los archivos del ZIP a `/root/csf-bot/`:
   - `index.js`, `qr-server.js`, `generarCSFLocal.js`, `generarClonLocal.js`
   - `onlyofficeClient.js`, `generar_clon.py`, `construir_sepomex.py`
   - `ecosystem.config.js`, `package.json`, `.env.example`, `backup_bot.sh`
   - Los 6 archivos `plantilla_*.docx`
   - `CPdescarga.txt` (15 MB, puede tardar)
   - **`municipios_clave_cache.json`** (71 KB — mapeo INEGI clave→nombre)
   - `construir_municipios_cache.py` (regenerador opcional)

3. **CRÍTICO**: usa modo **BINARIO** para los `.docx` y `.txt`
   - En FileZilla: Transferencia → Tipo de transferencia → Binario

### Opción B: Subir vía SCP desde tu PC
```bash
# Desde tu PC local (no en el servidor)
scp -r ./bot-files/* root@<IP-SERVIDOR>:/root/csf-bot/
```

### Permisos
```bash
cd /root/csf-bot
chmod +x backup_bot.sh
chmod 644 *.js *.json *.docx *.txt *.py *.example
```

---

## 8. CONSTRUIR BASE DE DATOS SEPOMEX

```bash
cd /root/csf-bot

# Crear directorio temporal y copiar
mkdir -p /tmp/sepomex_csv
cp CPdescarga.txt /tmp/sepomex_csv/

# Ejecutar script de construcción
python3 construir_sepomex.py

# Verificar (debe crear sepomex_db.json de ~3.3 MB)
ls -la sepomex_db.json
# Debe decir: "Estados: 32 | Municipios: 2478 | CPs: 31876 | Colonias: 157360"

# Limpiar temporal (opcional, si quieres guardar el CSV original muevelo)
mv /tmp/sepomex_csv/CPdescarga.txt /root/csf-bot/CPdescarga.txt.original
rm -rf /tmp/sepomex_csv
```

### ⚠️ CRÍTICO: Verificar municipios_clave_cache.json

Este archivo mapea claves INEGI (ej: `021`) → nombres oficiales (ej: `COYUCA DE BENITEZ`).

**Sin este archivo, cuando la API CURP devuelve solo la clave numérica del municipio (sin el nombre), el bot cae a un fallback que usa la CAPITAL del estado, produciendo errores como mostrar "CHILPANCINGO" cuando el municipio real era "COYUCA DE BENITEZ".**

```bash
# Verificar que el archivo exista (debe haber venido en el ZIP)
ls -la /root/csf-bot/municipios_clave_cache.json
# Debe pesar ~71 KB

# Verificar contenido
python3 -c "
import json
cache = json.load(open('/root/csf-bot/municipios_clave_cache.json'))
print(f'Estados: {len(cache)}')
print(f'Municipios: {sum(len(v) for v in cache.values())}')
print(f'Guerrero 021: {cache[\"GUERRERO\"].get(\"021\")}')
print(f'Veracruz 155: {cache[\"VERACRUZ DE IGNACIO DE LA LLAVE\"].get(\"155\")}')
"
# Esperado:
# Estados: 32
# Municipios: 2478
# Guerrero 021: COYUCA DE BENITEZ
# Veracruz 155: TANTOYUCA
```

### Si el archivo NO existe o quieres regenerarlo

```bash
cd /root/csf-bot
python3 construir_municipios_cache.py CPdescarga.txt.original
ls -la municipios_clave_cache.json
```

El script lee el CSV original de SEPOMEX y construye el cache con las claves INEGI oficiales (`c_estado`, `c_mnpio`) que vienen en cada registro.

---

## 9. INSTALAR DEPENDENCIAS DEL BOT

```bash
cd /root/csf-bot

# Instalar dependencias npm (toma 5-10 min por Playwright)
npm install

# Instalar Chromium para Playwright (lo necesita el bot)
npx playwright install chromium
npx playwright install-deps chromium

# Verificar Baileys 6.7.23
npm list @whiskeysockets/baileys
# Debe decir: └── @whiskeysockets/baileys@6.7.23

# Verificar sintaxis de todos los archivos
node -c index.js && \
node -c qr-server.js && \
node -c generarCSFLocal.js && \
node -c generarClonLocal.js && \
node -c onlyofficeClient.js && \
node -c ecosystem.config.js && \
python3 -c "import ast; ast.parse(open('generar_clon.py').read())" && \
python3 -c "import ast; ast.parse(open('construir_sepomex.py').read())" && \
bash -n backup_bot.sh && \
echo "✅ Toda la sintaxis OK"
```

---

## 10. PM2 Y ARRANQUE

```bash
cd /root/csf-bot

# Antes de arrancar — verifica ecosystem.config.js
# Si el Gateway de Docker no es 172.17.0.1, edita el archivo
nano ecosystem.config.js
# Cambia SERVER_IP si es necesario

# Arrancar el bot
pm2 start ecosystem.config.js

# Verificar
pm2 status
# Debe mostrar csf-bot Y qr-server en "online"

# Ver logs en vivo (primer arranque mostrará QR)
pm2 logs csf-bot --lines 50
```

---

## 11. ESCANEAR QR DE WHATSAPP

En la primera ejecución verás en los logs un QR ASCII gigante. Tienes 2 opciones:

### Opción A: Escanear QR ASCII desde la terminal
1. Reduce el zoom de la terminal hasta ver el QR completo
2. Abre WhatsApp Business en tu teléfono
3. Configuración → Dispositivos vinculados → Vincular dispositivo
4. Escanea el QR ASCII

### Opción B: Forzar QR como imagen PNG (más fácil)
```bash
# En otra ventana del SSH, mientras el bot arranca:
ls /root/csf-bot/auth_wa_baileys/
# Si está vacío y necesitas re-escanear, puedes hacer:
# pm2 stop csf-bot
# rm -rf /root/csf-bot/auth_wa_baileys/*
# pm2 start csf-bot
# pm2 logs csf-bot
```

Después del escaneo verás:
```
✅ WhatsApp conectado
🐕 Watchdog cada 1 min
🌐 gob.mx/curp pre-cargado
```

---

## 12. VERIFICACIÓN FINAL

### Test 1: OnlyOffice respondiendo
```bash
curl http://localhost:8083/welcome/ -I
# HTTP/1.1 200 OK
```

### Test 2: qr-server respondiendo
```bash
curl http://localhost:3000/qr?D3=fake
# Debe responder HTML "RFC no encontrado"
```

### Test 3: SSL funcionando
```bash
curl -I https://siat-sat.site/qr?D3=fake
# HTTP/2 404 (esperado, key fake)

curl -I https://validador.siat-sat.site/qr?D3=fake
# HTTP/2 404 (esperado)
```

### Test 4: SEPOMEX cargado
```bash
python3 -c "
import json
db = json.load(open('/root/csf-bot/sepomex_db.json'))
print(f'Estados: {len(db[\"estados\"])}')
print(f'Tuxtla: {len(db[\"estados\"][\"CHIAPAS\"][\"TUXTLA GUTIÉRREZ\"][\"cps\"])} CPs')
"
# Estados: 32
# Tuxtla: 53 CPs
```

### Test 5: Comando =diagnostico desde WhatsApp
Manda `=diagnostico` desde un grupo donde seas admin y el bot debe responder con su estado.

---

## 13. BACKUP AUTOMÁTICO

```bash
cd /root/csf-bot
chmod +x backup_bot.sh

# Prueba manual primero
./backup_bot.sh
ls -la /root/backups/
# Debe haber bot-2026-XX-XX.tar.gz

# Instalar cron
(crontab -l 2>/dev/null | grep -v "backup_bot.sh"; \
 echo "0 3 * * * /root/csf-bot/backup_bot.sh >> /root/csf-bot/logs/backup.log 2>&1") | crontab -

# Verificar
crontab -l | grep backup_bot
```

---

## 🎯 CHECKLIST FINAL

- [ ] DNS apuntando correctamente (verificar con `dig siat-sat.site`)
- [ ] Node 22 instalado
- [ ] PM2 al arranque (`pm2 startup` ejecutado)
- [ ] Docker + OnlyOffice corriendo (`docker ps`)
- [ ] Nginx con SSL (verificar `https://siat-sat.site/qr?D3=fake`)
- [ ] Bot conectado a WhatsApp (`pm2 logs csf-bot` muestra "WhatsApp conectado")
- [ ] qr-server corriendo (`pm2 status`)
- [ ] SEPOMEX cargado (`ls -la sepomex_db.json`)
- [ ] Backup cron instalado (`crontab -l`)
- [ ] Test funcional con `=diagnostico` desde un grupo

---

## 🆘 TROUBLESHOOTING

### ⚠️ "El bot genera DOCX pero NO genera PDF" (problema más común en instalaciones nuevas)

**Síntoma:** En los logs ves `✅ DOCX generado` pero NO ves `✅ PDF generado`. El bot termina entregando el DOCX como fallback.

**Causa raíz:** Una de estas dos cosas (o ambas):
1. UFW bloquea el tráfico desde Docker (172.17.0.0/16) al puerto 3000 del host
2. OnlyOffice 9.x bloquea por seguridad las IPs privadas (172.17.0.1)

**Diagnóstico paso a paso:**

```bash
# Test 1: ¿OnlyOffice puede llegar al qr-server desde dentro del contenedor?
docker exec onlyoffice curl -v --max-time 10 http://172.17.0.1:3000/welcome 2>&1 | tail -5
```

Si dice `Connection timed out` → **PROBLEMA UFW**. Soluciona:
```bash
ufw allow from 172.17.0.0/16 to any port 3000 proto tcp
ufw reload
```

Si dice `Connection refused` → qr-server no está escuchando en `*:3000`. Verifica:
```bash
ss -tlnp | grep 3000
```
Debe decir `*:3000` o `0.0.0.0:3000`. Si dice `127.0.0.1:3000`, hay problema con el código.

**Test 2: ¿OnlyOffice acepta IPs privadas?**

```bash
# Registrar archivo de prueba
DOCX_TEST=$(ls /root/csf-bot/descargas/*.docx 2>/dev/null | head -1)
[ -z "$DOCX_TEST" ] && echo "No hay DOCX para probar — manda un CSF primero"

curl -s -X POST http://localhost:3000/tmp/register \
  -H "Content-Type: application/json" \
  -d "{\"key\":\"dbg999\",\"filePath\":\"$DOCX_TEST\"}"

# Pedir conversión
curl -s -X POST http://localhost:8083/ConvertService.ashx \
  -H "Content-Type: application/json" \
  -H "Accept: application/json" \
  -d '{"async":false,"filetype":"docx","key":"dbg999","outputtype":"pdf","title":"test.docx","url":"http://172.17.0.1:3000/tmp/dbg999"}'
echo ""

# Ver logs de OnlyOffice
docker logs onlyoffice --tail 20
```

Si los logs muestran:
```
Error: DNS lookup 172.17.0.1 is not allowed. Because, It is private IP address.
```

→ **PROBLEMA: OnlyOffice bloquea IPs privadas.** Solución (recrear contenedor):

```bash
docker stop onlyoffice
docker rm onlyoffice

docker run -d --restart=always \
  --name onlyoffice \
  -p 8083:80 \
  -e JWT_ENABLED=false \
  -e ALLOW_PRIVATE_IP_ADDRESS=true \
  -e ALLOW_META_IP_ADDRESS=true \
  -e USE_UNAUTHORIZED_STORAGE=true \
  onlyoffice/documentserver

sleep 45
```

**Verificación final:**

```bash
# Esto debe convertir DOCX a PDF en ~1 segundo
node /root/csf-bot/onlyofficeClient.js /root/csf-bot/descargas/*.docx
```

Esperado:
```
[OnlyOffice] ✅ XXXX.docx → PDF 232KB en 1030ms (intento 1)
✅ Listo: /root/csf-bot/descargas/XXXX.pdf
```

---

### ⚠️ "El municipio sale mal en los clones (CHILPANCINGO en vez de COYUCA DE BENITEZ, etc.)"

**Síntoma:** En los logs ves:
```
Municipio: CHILPANCINGO   ← capital del estado (mal)
```
en lugar de:
```
📍 Municipio resuelto via cache local: clave 21 → COYUCA DE BENITEZ
Municipio: COYUCA DE BENITEZ   ← correcto
```

**Causa:** Falta el archivo `municipios_clave_cache.json` en `/root/csf-bot/`.

**Solución:**
```bash
# Verificar si existe
ls -la /root/csf-bot/municipios_clave_cache.json
```

Si NO existe, regenéralo desde el CSV de SEPOMEX:
```bash
cd /root/csf-bot
python3 construir_municipios_cache.py CPdescarga.txt.original
ls -la municipios_clave_cache.json  # debe pesar ~71 KB

# Reiniciar el bot
pm2 restart csf-bot
```

**Verificación funcional:**
```bash
python3 -c "
import json
cache = json.load(open('/root/csf-bot/municipios_clave_cache.json'))
print(f'Estados: {len(cache)}')      # debe ser 32
print(f'Guerrero 021: {cache[\"GUERRERO\"].get(\"021\")}')  # COYUCA DE BENITEZ
"
```

---

### "Cannot connect to WhatsApp"
- Borra `/root/csf-bot/auth_wa_baileys/*` y vuelve a escanear QR
- Verifica que no haya 2 instancias corriendo: `pm2 list`

### "OnlyOffice no responde"
- `docker ps` → ver si onlyoffice está running
- `docker logs onlyoffice` → ver errores
- Reiniciar: `docker restart onlyoffice`

### "EADDRINUSE puerto 3000"
- Ya hay otra instancia: `pm2 kill && pm2 start ecosystem.config.js`

### "Playwright Chromium error"
- Re-instalar: `cd /root/csf-bot && npx playwright install chromium --with-deps`

### "Permission denied en backup"
- `chmod +x /root/csf-bot/backup_bot.sh`

### "Régimen NO extraído"
- Es informativo, no error. El SAT no devuelve régimen para RFCs suspendidos.

---

## 📞 ARCHIVOS IMPORTANTES

```
/root/csf-bot/
├── index.js                              # Bot principal
├── qr-server.js                          # Servidor de réplica QR
├── generarCSFLocal.js                    # Generador CSF (scrape SAT)
├── generarClonLocal.js                   # Generador clon (API CURP)
├── onlyofficeClient.js                   # Cliente OnlyOffice
├── generar_clon.py                       # Renderer Python de clones
├── construir_sepomex.py                  # Builder de SEPOMEX DB
├── ecosystem.config.js                   # Config PM2
├── package.json                          # Deps npm
├── .env.example                          # Doc de variables
├── backup_bot.sh                         # Script de backup diario
│
├── plantilla_csf_template.docx           # Plantilla 1: Sueldos y Salarios
├── plantilla_csf2_template.docx          # Plantilla 2: Otros regímenes
├── plantilla_csf3_template.docx          # Plantilla 3: Persona Moral
├── plantilla_csf_suspendido_template.docx # Plantilla 4: Suspendidos
├── plantilla_clon_template.docx          # Plantilla clon (con obligaciones)
├── plantilla_clonsinobli_template.docx   # Plantilla clon (sin obligaciones)
│
├── sepomex_db.json                       # DB de SEPOMEX (~3.3 MB, generado)
├── CPdescarga.txt.original               # Original SEPOMEX (~15 MB)
│
├── auth_wa_baileys/                      # Credenciales WhatsApp (no borrar)
├── descargas/                            # PDFs generados (limpia cada 30 min)
├── qr-data/                              # Datos de QR para réplica
├── tmp-conv/                             # Refs temporales OnlyOffice
├── logs/                                 # Logs PM2
│
├── grupos_autorizados.json               # (se genera al activar grupos)
├── creditos.json                         # (se genera al asignar créditos)
├── stats_grupos.json                     # (se genera con uso)
└── stats_grupos_semanal.json             # (se genera con uso)
```

---

**Tiempo total estimado: 25-30 minutos.**

Si algo falla, revisa los logs con:
```bash
pm2 logs csf-bot --lines 100
pm2 logs qr-server --lines 50
docker logs onlyoffice --tail 50
journalctl -u nginx -n 50
```
