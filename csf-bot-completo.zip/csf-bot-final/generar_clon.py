#!/usr/bin/env python3
# Generador de constancia clon — llamado desde Node.js via child_process
# Uso: python3 generar_clon.py <json_datos>

import sys, json, zipfile, os, random, io, re, calendar
from datetime import datetime, timezone, timedelta

MESES = ["ENERO","FEBRERO","MARZO","ABRIL","MAYO","JUNIO",
         "JULIO","AGOSTO","SEPTIEMBRE","OCTUBRE","NOVIEMBRE","DICIEMBRE"]

CALLES = [
  "ACAMBAY","ATEMPAN","GUADALUPE","LANCEROS","SANTA LUCIA","5 DE MAYO",
  "CONDESA","SANTA MARIA","MIRAMAR","SANTA CRUZ","EMILIANO ZAPATA",
  "LOS ANGELES","SAN AGUSTIN","CENTRO","BUENOS AIRES","DOCTORES","GUERRERO",
  "ESPERANZA","PROGRESO","NIÑOS HEROES","AURORA","INDEPENDENCIA","REFORMA",
  "HIDALGO","MORELOS","JUAREZ","REVOLUCION","CONSTITUCION","LIBERTAD",
  "BENITO JUAREZ","MIGUEL HIDALGO","FRANCISCO MADERO","VENUSTIANO CARRANZA",
  "LAZARO CARDENAS","IGNACIO ZARAGOZA","FRANCISCO VILLA","PLUTARCO ELIAS",
  "ADOLFO LOPEZ MATEOS","MANUEL AVILA CAMACHO","JOSE MARIA MORELOS",
  "16 DE SEPTIEMBRE","20 DE NOVIEMBRE","5 DE FEBRERO","1 DE MAYO",
  "PROLONGACION REFORMA","PERIFERICO","INSURGENTES","CALZADA DE LOS MISTERIOS",
  "SAN JUAN DE DIOS","SAN PEDRO","SAN PABLO","SAN FRANCISCO","SAN JOSE",
  "SAN MIGUEL","SAN ANTONIO","SAN LUIS","SAN MARCOS","SAN NICOLAS",
  "REAL DEL MONTE","PINO SUAREZ","ALLENDE","ALDAMA","ABASOLO",
  "DEGOLLADO","MOCTEZUMA","CUAUHTEMOC","NETZAHUALCOYOTL","TEXCOCO",
  "XOCHIMILCO","TLAHUAC","IZTAPALAPA","COYOACAN","TLALPAN",
  "SATELITE","ECHEGARAY","PEDREGAL","DEL VALLE","NARVARTE",
  "POLANCO","LOMAS","ROMA","CONDESA","NAPOLES","FLORIDA",
]


# ── SEPOMEX local — domicilio real desde catálogo oficial del SAT/Correos ────
# Catálogo descargado de datos.gob.mx/correosdemexico.gob.mx y procesado a JSON
# por construir_sepomex.py. Se carga en RAM al iniciar el proceso (~30-80 MB).
# Estructura: SEPOMEX_DB['estados'][ESTADO][MUNICIPIO] = {'cps': [...], 'colonias': {cp: [...]}}
SEPOMEX_DB_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sepomex_db.json")
_SEPOMEX_DB = None  # se carga lazy en la primera llamada

# Mapeo de nombres de estado: algunos vienen con variantes según fuente (SAT vs SEPOMEX)
_ESTADO_ALIAS = {
    "CIUDAD DE MEXICO":               "CIUDAD DE MÉXICO",
    "DISTRITO FEDERAL":               "CIUDAD DE MÉXICO",
    "MEXICO":                         "MÉXICO",
    "ESTADO DE MEXICO":               "MÉXICO",
    "VERACRUZ DE IGNACIO DE LA LLAVE": "VERACRUZ",
    "MICHOACAN DE OCAMPO":            "MICHOACÁN",
    "COAHUILA DE ZARAGOZA":           "COAHUILA",
    "QUERETARO":                      "QUERÉTARO",
    "SAN LUIS POTOSI":                "SAN LUIS POTOSÍ",
    "NUEVO LEON":                     "NUEVO LEÓN",
    "YUCATAN":                        "YUCATÁN",
}

def _quitar_acentos(s):
    """Normaliza string: mayúsculas + sin acentos. Para comparar."""
    if not s: return ""
    import unicodedata
    return unicodedata.normalize('NFKD', s).encode('ascii', 'ignore').decode('ascii').upper().strip()

def _cargar_sepomex_db():
    """Carga el JSON de SEPOMEX en RAM. Se llama una sola vez (lazy)."""
    global _SEPOMEX_DB
    if _SEPOMEX_DB is not None:
        return _SEPOMEX_DB
    try:
        if not os.path.exists(SEPOMEX_DB_FILE):
            sys.stderr.write(f"[SEPOMEX] ⚠ DB no existe: {SEPOMEX_DB_FILE}\n")
            sys.stderr.write(f"[SEPOMEX]   Ejecuta: bash descargar_sepomex.sh && python3 construir_sepomex.py\n")
            _SEPOMEX_DB = {"estados": {}}
            return _SEPOMEX_DB
        with open(SEPOMEX_DB_FILE, "r", encoding="utf-8") as f:
            _SEPOMEX_DB = json.load(f)
        # Pre-indexar los estados normalizados para búsqueda rápida
        _SEPOMEX_DB['_estados_norm'] = {
            _quitar_acentos(k): k for k in _SEPOMEX_DB.get('estados', {}).keys()
        }
        # Pre-indexar municipios normalizados por estado
        _SEPOMEX_DB['_municipios_norm'] = {}
        for est, muns in _SEPOMEX_DB.get('estados', {}).items():
            _SEPOMEX_DB['_municipios_norm'][est] = {
                _quitar_acentos(k): k for k in muns.keys()
            }
        nest = len(_SEPOMEX_DB.get('estados', {}))
        nreg = _SEPOMEX_DB.get('total_registros', 0)
        sys.stderr.write(f"[SEPOMEX] DB cargada: {nest} estados, {nreg} registros\n")
        return _SEPOMEX_DB
    except Exception as e:
        sys.stderr.write(f"[SEPOMEX] ❌ Error cargando DB: {e}\n")
        _SEPOMEX_DB = {"estados": {}, "_estados_norm": {}, "_municipios_norm": {}}
        return _SEPOMEX_DB

def _buscar_municipio(municipio, estado_nombre):
    """
    Busca el registro de un municipio en SEPOMEX_DB, tolerando variaciones de
    acentos y mayúsculas.
    Retorna dict con {'cps': [...], 'colonias': {cp: [...]}} o None.
    """
    db = _cargar_sepomex_db()
    estados = db.get('estados', {})
    if not estados:
        return None

    # Normalizar estado y aplicar alias
    est_norm = _quitar_acentos(estado_nombre)
    est_norm = _ESTADO_ALIAS.get(est_norm, est_norm)
    est_norm = _quitar_acentos(est_norm)

    # Buscar key real del estado
    est_real = db.get('_estados_norm', {}).get(est_norm)
    if not est_real:
        sys.stderr.write(f"[SEPOMEX] Estado no encontrado: {estado_nombre!r} (norm={est_norm!r})\n")
        return None

    # Buscar municipio
    mun_norm = _quitar_acentos(municipio)
    municipios_idx = db.get('_municipios_norm', {}).get(est_real, {})
    mun_real = municipios_idx.get(mun_norm)
    if not mun_real:
        # Búsqueda flexible: contains
        for k_norm, k_real in municipios_idx.items():
            if mun_norm in k_norm or k_norm in mun_norm:
                mun_real = k_real
                break
    if not mun_real:
        sys.stderr.write(f"[SEPOMEX] Municipio no encontrado: {municipio!r} en {est_real}\n")
        return None

    data = estados[est_real][mun_real]
    return {
        'cps':       data['cps'],
        'colonias':  data['colonias'],
        'municipio': mun_real,
        'estado':    est_real,
    }

def get_colonia_cp_real(municipio, estado_nombre):
    """
    Obtiene CP y colonia reales usando SEPOMEX local.
    Retorna: (colonia, cp_str, municipio_oficial, estado_oficial, vialidad)
    """
    sepomex = _buscar_municipio(municipio, estado_nombre)

    if sepomex and sepomex['cps']:
        # Elegir CP aleatorio de los disponibles en ese municipio
        cp = random.choice(sepomex['cps'])
        # Elegir colonia aleatoria del CP elegido
        colonias = sepomex['colonias'].get(cp, [])
        colonia  = random.choice(colonias) if colonias else "CENTRO"
        vialidad = random.choice(CALLES)
        return (colonia, cp, sepomex['municipio'], sepomex['estado'], vialidad)

    # Fallback: SEPOMEX no encontró el municipio — usar datos genéricos
    sys.stderr.write(f"[SEPOMEX] Fallback genérico para {municipio!r}/{estado_nombre!r}\n")
    return ("CENTRO", "00000", municipio.upper(), estado_nombre.upper(), random.choice(CALLES))

# Renombrar la función original como fallback
ENTIDAD_NOMBRE = {
  "AS":"AGUASCALIENTES",      "BC":"BAJA CALIFORNIA",       "BS":"BAJA CALIFORNIA SUR",
  "CC":"CAMPECHE",            "CL":"COAHUILA",              "CM":"COLIMA",
  "CS":"CHIAPAS",             "CH":"CHIHUAHUA",             "DF":"CIUDAD DE MEXICO",
  "DG":"DURANGO",             "GT":"GUANAJUATO",            "GR":"GUERRERO",
  "HG":"HIDALGO",             "JC":"JALISCO",               "MC":"ESTADO DE MEXICO",
  "MN":"MICHOACAN DE OCAMPO", "MS":"MORELOS",               "NT":"NAYARIT",
  "NL":"NUEVO LEON",          "OC":"OAXACA",                "PL":"PUEBLA",
  "QT":"QUERETARO",           "QR":"QUINTANA ROO",          "SP":"SAN LUIS POTOSI",
  "SL":"SINALOA",             "SR":"SONORA",                "TC":"TABASCO",
  "TS":"TAMAULIPAS",          "TL":"TLAXCALA",              "VZ":"VERACRUZ DE IGNACIO DE LA LLAVE",
  "YN":"YUCATAN",             "ZS":"ZACATECAS",             "NE":"JALISCO",
}


# ── Helpers ───────────────────────────────────────────────────────────────────

def xml_escape(s):
    return str(s).replace('&','&amp;').replace('<','&lt;').replace('>','&gt;').replace('"','&quot;').replace("'",'&apos;')

def fecha_espanol(dt):
    return f"{dt.day:02d} DE {MESES[dt.month-1]} DE {dt.year}"


# ── Filas de tabla Actividades Económicas ─────────────────────────────────────
# Columnas: Orden(900) | Actividad(6040) | Porcentaje(1260) | FechaInicio(1400) | FechaFin(1400)

def _tc(w, texto, jc=None, spacing=None):
    jc_tag = f'<w:jc w:val="{jc}"/>' if jc else ''
    sp_tag = f'<w:spacing w:val="{spacing}"/>' if spacing else ''
    return (
        f'<w:tc><w:tcPr><w:tcW w:w="{w}" w:type="dxa"/>'
        f'<w:tcBorders>'
        f'<w:top w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
        f'<w:left w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
        f'<w:bottom w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
        f'<w:right w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
        f'</w:tcBorders></w:tcPr>'
        f'<w:p><w:pPr><w:pStyle w:val="TableParagraph"/>'
        f'<w:spacing w:before="7"/><w:ind w:left="7"/>{jc_tag}'
        f'<w:rPr><w:rFonts w:ascii="Arial MT" w:hAnsi="Arial MT"/>'
        f'<w:sz w:val="16"/></w:rPr></w:pPr>'
        f'<w:r><w:rPr><w:rFonts w:ascii="Arial MT" w:hAnsi="Arial MT"/>'
        f'{sp_tag}<w:sz w:val="16"/></w:rPr>'
        f'<w:t>{xml_escape(texto)}</w:t></w:r></w:p></w:tc>'
    )

def _tc_vacia(w):
    return (
        f'<w:tc><w:tcPr><w:tcW w:w="{w}" w:type="dxa"/>'
        f'<w:tcBorders>'
        f'<w:top w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
        f'<w:left w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
        f'<w:bottom w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
        f'<w:right w:val="single" w:sz="4" w:space="0" w:color="auto"/>'
        f'</w:tcBorders></w:tcPr>'
        f'<w:p><w:pPr><w:pStyle w:val="TableParagraph"/>'
        f'<w:spacing w:before="0"/><w:ind w:left="0"/>'
        f'<w:rPr><w:rFonts w:ascii="Times New Roman"/><w:sz w:val="16"/>'
        f'</w:rPr></w:pPr></w:p></w:tc>'
    )

def build_actividad_rows(actividades):
    rows = ""
    for item in actividades:
        rows += (
            '<w:tr><w:trPr><w:trHeight w:val="432"/></w:trPr>'
            + _tc(900,  str(item.get('orden','1')),      spacing='-10')
            + _tc(6040, str(item.get('actividad','')),   spacing='-2')
            + _tc(1260, str(item.get('porcentaje','100')), spacing='-5')
            + (_tc(1400, str(item.get('fecha_inicio','')), jc='center', spacing='-2')
               if item.get('fecha_inicio') else _tc_vacia(1400))
            + (_tc(1400, str(item.get('fecha_fin','')), jc='center', spacing='-2')
               if item.get('fecha_fin') else _tc_vacia(1400))
            + '</w:tr>'
        )
    return rows

def build_regimen_rows(regimenes):
    rows = ""
    for item in regimenes:
        rows += (
            '<w:tr><w:trPr><w:trHeight w:val="432"/></w:trPr>'
            + _tc(8200, str(item.get('regimen','')))
            + (_tc(1400, str(item.get('fecha_inicio','')), jc='center', spacing='-2')
               if item.get('fecha_inicio') else _tc_vacia(1400))
            + (_tc(1400, str(item.get('fecha_fin','')), jc='center', spacing='-2')
               if item.get('fecha_fin') else _tc_vacia(1400))
            + '</w:tr>'
        )
    return rows


def generar_qr_png(url, size=360):
    """Genera QR PNG que apunta a la URL dada."""
    try:
        import qrcode
        from qrcode.image.pure import PymagingImage
        qr = qrcode.QRCode(
            version=None,
            error_correction=qrcode.constants.ERROR_CORRECT_M,
            box_size=10,
            border=2,
        )
        qr.add_data(url)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        # Redimensionar al tamaño exacto
        from PIL import Image as PILImage
        img_pil = img.get_image() if hasattr(img,'get_image') else img
        if hasattr(img_pil, 'convert'):
            img_pil = img_pil.convert('1')
        img_pil = img_pil.resize((size, size), PILImage.NEAREST)
        buf = io.BytesIO()
        img_pil.save(buf, format='PNG')
        return buf.getvalue()
    except ImportError:
        # qrcode no instalado — intentar instalarlo
        import subprocess
        subprocess.run([sys.executable, '-m', 'pip', 'install', 'qrcode[pil]',
                       '--break-system-packages', '-q'], capture_output=True)
        try:
            import qrcode
            return generar_qr_png(url, size)
        except:
            return None
    except Exception as e:
        sys.stderr.write(f"[qr] Error: {e}\n")
        return None




def generar_barcode_png(rfc, width=580, height=120):
    """
    Genera barcode CODE128 PNG SIN texto RFC dibujado.
    Solo las barras. El placeholder {RFC} en la plantilla se encarga
    de mostrar el texto del RFC debajo del barcode.
    """
    try:
        from PIL import Image as PILImage, ImageDraw

        CODE128B = {
            ' ':0,'!':1,'"':2,'#':3,'$':4,'%':5,'&':6,"'":7,'(':8,')':9,
            '*':10,'+':11,',':12,'-':13,'.':14,'/':15,'0':16,'1':17,'2':18,
            '3':19,'4':20,'5':21,'6':22,'7':23,'8':24,'9':25,':':26,';':27,
            '<':28,'=':29,'>':30,'?':31,'@':32,'A':33,'B':34,'C':35,'D':36,
            'E':37,'F':38,'G':39,'H':40,'I':41,'J':42,'K':43,'L':44,'M':45,
            'N':46,'O':47,'P':48,'Q':49,'R':50,'S':51,'T':52,'U':53,'V':54,
            'W':55,'X':56,'Y':57,'Z':58,
        }
        # Tabla completa Code128 — 106 entradas (valores 0-105)
        # Necesaria completa porque el checksum puede ser cualquier valor 0-102
        PATTERNS = [
            '11011001100','11001101100','11001100110','10010011000','10010001100',  # 0-4
            '10001001100','10011001000','10011000100','10001100100','11001001000',  # 5-9
            '11001000100','11000100100','10110011100','10011011100','10011001110',  # 10-14
            '10111001100','10011101100','10011100110','11001110010','11001011100',  # 15-19
            '11001001110','11011100100','11001110100','11101101110','11101001100',  # 20-24
            '11100101100','11100100110','11101100100','11100110100','11100110010',  # 25-29
            '11011011000','11011000110','11000110110','10100011000','10001011000',  # 30-34
            '10001000110','10110001000','10001101000','10001100010','11010001000',  # 35-39
            '11000101000','11000100010','10110111000','10110001110','10001101110',  # 40-44
            '10111011000','10111000110','10001110110','11101110110','11010001110',  # 45-49
            '11000101110','11011101000','11011100010','11011101110','11101011000',  # 50-54
            '11101000110','11100010110','11101101000','11101100010','11100011010',  # 55-59
            '11101111010','11001000010','11110001010','10100110000','10100001100',  # 60-64
            '10010110000','10010000110','10000101100','10000100110','10110010000',  # 65-69
            '10110000100','10011010000','10011000010','10000110100','10000110010',  # 70-74
            '11000010010','11001010000','11110111010','11000010100','10001111010',  # 75-79
            '10100111100','10010111100','10010011110','10111100100','10011110100',  # 80-84
            '10011110010','11110100100','11110010100','11110010010','11011011110',  # 85-89
            '11011110110','11110110110','10101111000','10100011110','10001011110',  # 90-94
            '10111101000','10111100010','11110101000','11110100010','10111011110',  # 95-99
            '10111101110','11101011110','11110101110','11010000100','11010010000',  # 100-104
            '11010011100',                                                          # 105
        ]
        STOP_PAT = '1100011101011'
        START_B  = 104

        vals = [START_B]
        for c in rfc.upper():
            vals.append(CODE128B.get(c, 0))
        chk = START_B
        for i, v in enumerate(vals[1:], 1):
            chk += i * v
        vals.append(chk % 103)

        bars = ""
        for v in vals:
            bars += PATTERNS[v] if v < len(PATTERNS) else "11011001100"
        bars += STOP_PAT + "11"

        # Solo barras — sin texto. El placeholder {RFC} en la plantilla
        # se encarga del texto debajo del barcode.
        margin_x = 8
        margin_y = 4
        bar_h    = height - 2 * margin_y
        bar_w    = (width - 2 * margin_x) / len(bars)

        img  = PILImage.new('RGB', (width, height), 'white')
        draw = ImageDraw.Draw(img)

        x = float(margin_x)
        for b in bars:
            nx = x + bar_w
            if b == '1':
                draw.rectangle(
                    [round(x), margin_y, round(nx) - 1, margin_y + bar_h - 1],
                    fill='black'
                )
            x = nx

        buf = io.BytesIO()
        img.save(buf, format='PNG')
        return buf.getvalue()
    except Exception as e:
        sys.stderr.write(f"[barcode] Error: {e}\n")
        return None


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    # FIX: validar entrada antes de parsear. Si se invoca sin argv o con JSON
    # malformado, salir con mensaje claro a stderr en vez de stack trace
    # crudo. Node.js capta stderr y lo muestra en logs.
    if len(sys.argv) < 2:
        sys.stderr.write("[generar_clon] ❌ Falta argumento JSON con datos\n")
        sys.exit(2)
    try:
        datos = json.loads(sys.argv[1])
    except (json.JSONDecodeError, ValueError) as e:
        sys.stderr.write(f"[generar_clon] ❌ JSON inválido en argv: {e}\n")
        sys.exit(2)

    # Validar campos obligatorios
    for campo in ('rfc', 'curp', 'downloadDir', 'plantilla'):
        if not datos.get(campo):
            sys.stderr.write(f"[generar_clon] ❌ Campo requerido faltante: {campo}\n")
            sys.exit(2)

    rfc          = datos['rfc']
    curp         = datos['curp']
    nombre       = datos.get('nombre', '').upper()
    ap1          = datos.get('ap1', '').upper()
    ap2          = datos.get('ap2', '').upper()
    estado_code  = datos.get('entidadCode', 'DF')
    emision      = datos.get('emision', 'CUAUHTEMOC , CIUDAD DE MEXICO')
    municipio    = datos.get('municipio', '').upper().strip()
    download_dir = datos['downloadDir']
    plantilla    = datos['plantilla']

    # El SAT usa UTC-6 fijo (sin horario de verano)
    cdmx_tz = timezone(timedelta(hours=-6))
    hoy     = datetime.now(cdmx_tz)
    hoy_str = fecha_espanol(hoy)
    # Timestamp para cadena original: YYYY/MM/DD HH:MM:SS
    timestamp_cadena = hoy.strftime("%Y/%m/%d %H:%M:%S")

    # CP, colonia y calle reales via SEPOMEX local (catálogo oficial Correos de México)
    entidad_nombre_para_api = ENTIDAD_NOMBRE.get(estado_code, "CIUDAD DE MEXICO")
    municipio_para_api      = municipio if municipio else entidad_nombre_para_api

    colonia, cp, municipio_oficial, estado_oficial, vialidad_real = get_colonia_cp_real(
        municipio_para_api, entidad_nombre_para_api
    )
    cp = str(cp).zfill(5)
    sys.stderr.write(f"[SEPOMEX] municipio={municipio_para_api} → cp={cp} colonia={colonia} municipio_oficial={municipio_oficial}\n")
    sys.stderr.flush()

    # Domicilio
    vialidad = vialidad_real
    num_ext  = str(random.randint(1, 999))
    num_int  = "S/N"
    entidad  = estado_oficial if estado_oficial else ENTIDAD_NOMBRE.get(estado_code, "CIUDAD DE MEXICO")
    # Localidad y municipio: usar el municipio oficial de SEPOMEX
    localidad = municipio_oficial if municipio_oficial else entidad

    # Fecha de nacimiento desde CURP (posiciones 4-9: AAMMDD)
    anio2    = int(curp[4:6])
    mes_nac  = int(curp[6:8])
    dia_nac  = int(curp[8:10])
    anio_nac = 2000 + anio2 if anio2 <= (hoy.year % 100) else 1900 + anio2

    # Fecha inicio = nacimiento + 18 años + 1 mes (maneja días 29/30/31)
    mes_inicio  = mes_nac + 1 if mes_nac < 12 else 1
    anio_inicio = anio_nac + 18 if mes_nac < 12 else anio_nac + 19
    max_dia = calendar.monthrange(anio_inicio, mes_inicio)[1]
    fecha_inicio = datetime(anio_inicio, mes_inicio, min(dia_nac, max_dia))
    fecha_operaciones = fecha_espanol(fecha_inicio)
    fecha_inicio_act  = fecha_inicio.strftime("%d/%m/%Y")

    nombre_completo = f"{nombre} {ap1} {ap2}".strip()
    id_cif = "21" + str(random.randint(100000000, 999999999))

    # FIX Bug #11: leer sinObligaciones del JSON que manda Node.
    # Antes el campo se ignoraba: la plantilla seleccionada (clonsinobli) era
    # correcta pero el JSON del QR validador SIEMPRE mostraba "Sueldos y Salarios",
    # creando incoherencia entre el PDF y la página web cuando se escaneaba el QR.
    sin_obligaciones = bool(datos.get('sinObligaciones', False))

    if sin_obligaciones:
        # Sin obligaciones: actividades vacías. Régimen con texto "Sin obligaciones fiscales".
        # Si la plantilla clonsinobli tiene {REGIMEN} placeholder → se renderiza la fila.
        # Si no lo tiene (texto hardcodeado) → el find() devuelve -1 y no se modifica nada.
        actividades_list = []
        regimenes_list = [
            {'regimen': 'Sin obligaciones fiscales',
             'fecha_inicio': fecha_inicio_act, 'fecha_fin': ''}
        ]
    else:
        actividades_list = datos.get('actividades', [
            {'orden': '1', 'actividad': 'Asalariado',
             'porcentaje': '100', 'fecha_inicio': fecha_inicio_act, 'fecha_fin': ''}
        ])
        regimenes_list = datos.get('regimenes', [
            {'regimen': 'Régimen de Sueldos y Salarios e Ingresos Asimilados a Salarios',
             'fecha_inicio': fecha_inicio_act, 'fecha_fin': ''}
        ])

    # Leer plantilla
    with zipfile.ZipFile(plantilla, 'r') as zin:
        xml = zin.read('word/document.xml').decode('utf-8')

    # Construir el string del lugar/fecha (lo necesitamos para el cálculo de ancho
    # ANTES de hacer el reemplazo en el XML).
    lugar_fecha_str = f"{emision} A {hoy_str}"

    # Reemplazos de texto
    for ph, val in {
        '{RFC}':                 xml_escape(rfc),
        '{CURP}':                xml_escape(curp),
        '{NOMBRE}':              xml_escape(nombre),
        '{AP1}':                 xml_escape(ap1),
        '{AP2}':                 xml_escape(ap2),
        '{NOMBRE_COMPLETO}':     xml_escape(nombre_completo),
        '{IDCIF}':               xml_escape(id_cif),
        '{LUGAR_FECHA_EMISION}': xml_escape(lugar_fecha_str),
        '{FECHA_OPERACIONES}':   xml_escape(fecha_operaciones),
        '{FECHA_CAMBIO}':        xml_escape(fecha_operaciones),
        '{CP}':                  xml_escape(cp),
        '{VIALIDAD}':            xml_escape(vialidad),
        '{NUM_EXT}':             xml_escape(num_ext),
        '{NUM_INT}':             xml_escape(num_int),
        '{COLONIA}':             xml_escape(colonia),
        '{LOCALIDAD_MUNICIPIO}': xml_escape(localidad),
        '{ENTIDAD}':             xml_escape(entidad),
        '{FECHA_INICIO_ACT}':    xml_escape(fecha_inicio_act),
    }.items():
        xml = xml.replace(ph, val)

    # ── Centrado visual del bloque "Lugar y Fecha de Emisión" ──────────────
    # Mismo fix que en generarCSFLocal.js. El cuadro tiene altura fija ~1.37cm
    # y el contenido se alinea arriba por defecto (anchor ausente = top).
    # Cuando la fecha cabe en 1 línea, queda pegado arriba y se ve raro.
    #
    # Solución: si el texto cabe en 1 línea, agregar anchor="ctr" al
    # <wps:bodyPr> y aumentar el spacing del párrafo (w:before="8" → "18").
    # Si se parte en 2 líneas, comportamiento default.
    #
    # Detección: cálculo preciso del ancho usando tabla Arial Bold (em*1000).
    # Ancho útil del cuadro = 261.65 pt (9.59cm - padding interno 10.25pt).
    ARIAL_BOLD_WIDTHS = {
        ' ':278,'!':333,'"':474,'#':556,'$':556,'%':889,'&':722,"'":238,'(':333,
        ')':333,'*':389,'+':584,',':278,'-':333,'.':278,'/':278,'0':556,'1':556,
        '2':556,'3':556,'4':556,'5':556,'6':556,'7':556,'8':556,'9':556,':':333,
        ';':333,'<':584,'=':584,'>':584,'?':611,'@':975,'A':722,'B':722,'C':722,
        'D':722,'E':667,'F':611,'G':778,'H':722,'I':278,'J':556,'K':722,'L':611,
        'M':833,'N':722,'O':778,'P':667,'Q':778,'R':722,'S':667,'T':611,'U':722,
        'V':667,'W':944,'X':667,'Y':667,'Z':611,'Ñ':722,'[':333,']':333,'_':556
    }
    ANCHO_UTIL_PT = 261.65
    ancho_pt = sum(ARIAL_BOLD_WIDTHS.get(ch, 556) for ch in lugar_fecha_str) * 0.01

    if ancho_pt <= ANCHO_UTIL_PT:
        # Aplicar anchor="ctr" a los cuadros del bloque (usamos el texto ya
        # reemplazado como marca para encontrar los bodyPr correctos).
        marker = xml_escape(lugar_fecha_str)
        pos = 0
        while True:
            idx_marker = xml.find(marker, pos)
            if idx_marker < 0:
                break
            # Buscar el <wps:bodyPr> ANTES del marker (el bodyPr está antes del
            # contenido del cuadro, no después).
            body_pr_start = xml.rfind('<wps:bodyPr', 0, idx_marker)
            if body_pr_start < 0:
                pos = idx_marker + 1
                continue
            body_pr_end = xml.find('>', body_pr_start)
            body_pr_tag = xml[body_pr_start:body_pr_end + 1]
            if 'anchor=' not in body_pr_tag:
                body_pr_nuevo = body_pr_tag[:-1] + ' anchor="ctr">'
                xml = xml[:body_pr_start] + body_pr_nuevo + xml[body_pr_end + 1:]
                pos = idx_marker + (len(body_pr_nuevo) - len(body_pr_tag)) + 1
            else:
                pos = idx_marker + 1

        # Espaciado +0.5pt antes del párrafo de la fecha (solo cuando es 1 línea).
        # Spacing default w:before="8" (0.4pt) → w:before="18" (0.9pt).
        # Modifica SOLO dentro del párrafo que contiene la fecha.
        pos_sp = 0
        while True:
            idx_lf = xml.find(marker, pos_sp)
            if idx_lf < 0:
                break
            p_with_attrs = xml.rfind('<w:p ', 0, idx_lf)
            p_no_attrs = xml.rfind('<w:p>', 0, idx_lf)
            p_start = max(p_with_attrs, p_no_attrs)
            if p_start < 0:
                pos_sp = idx_lf + 1
                continue
            p_end = xml.find('</w:p>', idx_lf)
            if p_end < 0:
                break
            parrafo = xml[p_start:p_end]
            parrafo_nuevo = re.sub(
                r'(<w:spacing[^>]*\bw:before=)"8"',
                r'\1"18"',
                parrafo
            )
            if parrafo_nuevo != parrafo:
                xml = xml[:p_start] + parrafo_nuevo + xml[p_end:]
                pos_sp = p_start + len(parrafo_nuevo) + 6  # 6 = "</w:p>"
            else:
                pos_sp = p_end + 6

    # Tamaño de fuente del lugar/fecha de emisión — 20 (10pt)
    xml = xml.replace(
        '<w:b/><w:color w:val="000000"/><w:spacing w:val="-4"/><w:sz w:val="20"/></w:rPr><w:t>' + xml_escape(f"{emision} A {hoy_str}"),
        '<w:b/><w:color w:val="000000"/><w:spacing w:val="-4"/><w:sz w:val="20"/></w:rPr><w:t>' + xml_escape(f"{emision} A {hoy_str}")
    )

    # Reemplazar timestamp de Cadena Original (formato YYYY/MM/DD HH:MM:SS)
    xml = re.sub(r'202\d/\d{2}/\d{2} \d{2}:\d{2}:\d{2}', timestamp_cadena, xml)

    # Reemplazar fila de Actividades
    # FIX: buscar tanto '<w:tr ' (con atributos) como '<w:tr>' (sin atributos)
    # y tomar el MÁS cercano al placeholder (mayor posición).
    idx = xml.find('{ACTIVIDAD}')
    if idx >= 0:
        tr_s_with = xml.rfind('<w:tr ', 0, idx)
        tr_s_no   = xml.rfind('<w:tr>', 0, idx)
        tr_s = max(tr_s_with, tr_s_no)
        tr_e = xml.find('</w:tr>', idx) + len('</w:tr>')
        if tr_s >= 0 and tr_e > tr_s:
            xml = xml[:tr_s] + build_actividad_rows(actividades_list) + xml[tr_e:]

    # Reemplazar fila de Regimenes (mismo fix)
    idx = xml.find('{REGIMEN}')
    if idx >= 0:
        tr_s_with = xml.rfind('<w:tr ', 0, idx)
        tr_s_no   = xml.rfind('<w:tr>', 0, idx)
        tr_s = max(tr_s_with, tr_s_no)
        tr_e = xml.find('</w:tr>', idx) + len('</w:tr>')
        if tr_s >= 0 and tr_e > tr_s:
            xml = xml[:tr_s] + build_regimen_rows(regimenes_list) + xml[tr_e:]

    # Nombre Comercial — dejar vacío (no se muestra)
    # FIX BUG CALLE: el código original buscaba un string XML literal con atributos
    # específicos (w:rsidR="005F5DA8") que no coincidía con las plantillas reales.
    # Ahora usamos regex flexible que matchea el patrón "Tipo de Vialidad: " seguido
    # del </w:t></w:r>, luego un <w:r> con cualquier atributo, y un <w:t/> vacío
    # (sea self-closing o como <w:t></w:t>). Insertamos "CALLE" dentro del <w:t>.
    xml = re.sub(
        r'(Tipo de Vialidad: </w:t></w:r><w:r[^>]*><w:rPr><w:rFonts w:ascii="Arial MT"/><w:spacing w:val="-2"/><w:sz w:val="16"/></w:rPr>)<w:t(?:/>|></w:t>)',
        r'\1<w:t>CALLE</w:t>',
        xml
    )

    # Insertar el nombre completo en el campo "Nombre Comercial:" (que en ambas
    # plantillas está vacío). El campo está en la celda <w:tc> que viene
    # INMEDIATAMENTE DESPUÉS del <w:tc> que contiene "Comercial:".
    #
    # FORMATO: "NOMBRE APELLIDO_PATERNO APELLIDO_MATERNO" (orden natural).
    nombre_comercial = f"{nombre} {ap1} {ap2}".strip()
    idx_comercial = xml.find('<w:t>Comercial:</w:t>')
    if idx_comercial >= 0:
        # Cerrar la celda de "Comercial:"
        idx_close_tc = xml.find('</w:tc>', idx_comercial)
        if idx_close_tc >= 0:
            # Apertura de la siguiente celda (la del valor)
            idx_open_tc = xml.find('<w:tc>', idx_close_tc)
            if idx_open_tc >= 0:
                # Cierre de la celda del valor
                idx_close_tc_valor = xml.find('</w:tc>', idx_open_tc)
                if idx_close_tc_valor >= 0:
                    # Tenemos la celda completa entre idx_open_tc y idx_close_tc_valor
                    celda_valor = xml[idx_open_tc:idx_close_tc_valor]
                    # Construir el run con el nombre comercial
                    run_nombre = (
                        '<w:r>'
                        '<w:rPr>'
                        '<w:rFonts w:ascii="Arial MT" w:hAnsi="Arial MT"/>'
                        '<w:spacing w:val="-2"/>'
                        '<w:sz w:val="16"/>'
                        '</w:rPr>'
                        '<w:t>' + xml_escape(nombre_comercial) + '</w:t>'
                        '</w:r>'
                    )
                    # Caso A: la celda tiene <w:t/> vacío → reemplazarlo
                    if '<w:t/>' in celda_valor:
                        celda_nueva = celda_valor.replace(
                            '<w:t/>',
                            '<w:t>' + xml_escape(nombre_comercial) + '</w:t>',
                            1
                        )
                    elif '<w:t></w:t>' in celda_valor:
                        celda_nueva = celda_valor.replace(
                            '<w:t></w:t>',
                            '<w:t>' + xml_escape(nombre_comercial) + '</w:t>',
                            1
                        )
                    else:
                        # Caso B: la celda no tiene <w:t> — inyectar run justo antes del </w:p>.
                        # Adicionalmente, ajustar el <w:pPr> para que tenga el mismo
                        # formato que las otras celdas con valor (w:before="123" en lugar
                        # de "0", y quitar w:ind w:left="0" para usar el indent default).
                        idx_close_p = celda_valor.rfind('</w:p>')
                        if idx_close_p >= 0:
                            celda_nueva = (
                                celda_valor[:idx_close_p]
                                + run_nombre
                                + celda_valor[idx_close_p:]
                            )
                            # Ajustar formato del párrafo para que coincida con otras celdas
                            celda_nueva = celda_nueva.replace(
                                '<w:spacing w:before="0"/>',
                                '<w:spacing w:before="123"/>',
                                1
                            )
                            # Quitar el <w:ind w:left="0"/> para que use el indent default
                            celda_nueva = re.sub(
                                r'<w:ind w:left="0"/>\s*',
                                '',
                                celda_nueva,
                                count=1
                            )
                        else:
                            celda_nueva = celda_valor  # no se pudo, dejar igual
                    xml = xml[:idx_open_tc] + celda_nueva + xml[idx_close_tc_valor:]

    # URL base del servidor QR
    QR_BASE_URL      = os.environ.get('QR_BASE_URL',      'https://siat-sat.site')
    QR_VALIDADOR_URL = os.environ.get('QR_VALIDADOR_URL', 'https://validador.siat-sat.site')

    # QR 1 → validador.siat-sat.site (cédula frontal image2 — datos del contribuyente)
    qr_url_clon = f"{QR_VALIDADOR_URL}/qr?D1=10&D2=1&D3={rfc}"
    # QR 2 → siat-sat.site (segunda hoja image11 — RFC + cadena "emitido por Hacienda")
    qr_key_csf  = f"{id_cif}_{rfc}"
    qr_url_csf  = f"{QR_BASE_URL}/qr?D1=10&D2=1&D3={qr_key_csf}"

    # Barcode
    barcode_png = generar_barcode_png(rfc)
    qr_png_360  = generar_qr_png(qr_url_clon, size=360)   # image2.png  — cédula frontal
    qr_png_392  = generar_qr_png(qr_url_csf,  size=392)   # image11.png — segunda hoja

    # Guardar datos para página QR
    qr_data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'qr-data')
    os.makedirs(qr_data_dir, exist_ok=True)

    # Datos del contribuyente → key=RFC (para validador.siat-sat.site)
    # FIX Bug #12: el régimen mostrado en la página web del validador debe coincidir
    # con el del PDF. Si es clonsinobli, mostrar "Sin obligaciones fiscales".
    regimen_para_qr = (
        'Sin obligaciones fiscales'
        if sin_obligaciones
        else 'Régimen de Sueldos y Salarios e Ingresos Asimilados a Salarios'
    )
    qr_datos_clon = {
        'rfc':          rfc,
        'curp':         curp,
        'nombre':       nombre,
        'ap1':          ap1,
        'ap2':          ap2,
        'entidad':      entidad,
        'municipio':    localidad,
        'colonia':      colonia,
        'vialidad':     vialidad,
        'num_ext':      num_ext,
        'num_int':      num_int,
        'cp':           cp,
        'regimen':      regimen_para_qr,
        'fecha_nac':    f"{dia_nac:02d}-{mes_nac:02d}-{anio_nac}",
        'fecha_inicio': fecha_inicio.strftime("%d-%m-%Y"),
        'fecha_cambio': fecha_inicio.strftime("%d-%m-%Y"),
        'email':        '',
    }
    with open(os.path.join(qr_data_dir, f'{rfc}.json'), 'w') as f:
        json.dump(qr_datos_clon, f, ensure_ascii=False, indent=2)

    # RFC + cadena original → key=idCIF_RFC (para siat-sat.site)
    cadena_original = f"||{timestamp_cadena}|{rfc}|CONSTANCIA DE SITUACIÓN FISCAL|200001088888800000041|U2FsdGVkX1/DroT2rJrgYGJjW6W9qAJnlEJWv/z818+sndE3ANPr3s7tw4Tkafz3||"
    qr_datos_csf = {
        'rfc':             rfc,
        'cadena_original': cadena_original,
    }
    with open(os.path.join(qr_data_dir, f'{qr_key_csf}.json'), 'w') as f:
        json.dump(qr_datos_csf, f, ensure_ascii=False, indent=2)

    # Escribir DOCX
    out_path = os.path.join(download_dir, f"{rfc}_clon_{int(datetime.now().timestamp()*1000)}.docx")

    with zipfile.ZipFile(plantilla, 'r') as zin:
        with zipfile.ZipFile(out_path, 'w') as zout:
            for item in zin.infolist():
                if item.filename == 'word/document.xml':
                    zout.writestr(item, xml.encode('utf-8'), compress_type=zipfile.ZIP_DEFLATED)
                elif item.filename == 'word/media/image6.png' and barcode_png:
                    zout.writestr(item, barcode_png, compress_type=zipfile.ZIP_DEFLATED)
                elif item.filename == 'word/media/image4.png' and qr_png_360:
                    zout.writestr(item, qr_png_360, compress_type=zipfile.ZIP_DEFLATED)
                elif item.filename == 'word/media/image7.png' and qr_png_392:
                    zout.writestr(item, qr_png_392, compress_type=zipfile.ZIP_DEFLATED)
                else:
                    zout.writestr(item, zin.read(item.filename))

    print(out_path)

if __name__ == '__main__':
    main()
