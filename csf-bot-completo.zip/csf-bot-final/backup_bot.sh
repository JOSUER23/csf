#!/bin/bash
# ════════════════════════════════════════════════════════════════════════════
# backup_bot.sh — Respaldo diario de estado del SPARTAN CSF BOT
#
# Qué respalda:
#   - auth_wa_baileys/         → credenciales WhatsApp (si esto se pierde, hay
#                                que re-escanear el QR desde el teléfono)
#   - grupos_autorizados.json  → grupos activos
#   - creditos.json            → créditos de cada grupo
#   - stats_grupos.json        → stats diarias
#   - stats_grupos_semanal.json → stats semanales
#   - municipios_clave_cache.json → cache de municipios (regenerable, opcional)
#
# Política de retención: conserva los últimos 14 días.
#
# Instalación (cron diario a las 3 AM):
#   chmod +x /root/csf-bot/backup_bot.sh
#   crontab -e
#   Agregar línea:
#     0 3 * * * /root/csf-bot/backup_bot.sh >> /root/csf-bot/logs/backup.log 2>&1
#
# Restaurar desde un backup:
#   cd /root/csf-bot
#   pm2 stop csf-bot
#   tar xzf /root/backups/bot-2026-05-27.tar.gz -C /
#   pm2 restart csf-bot
# ════════════════════════════════════════════════════════════════════════════

set -e

BOT_DIR="/root/csf-bot"
BACKUP_DIR="/root/backups"
FECHA=$(date +%Y-%m-%d)
RETAIN_DAYS=14

# Crear directorio de backups si no existe
mkdir -p "$BACKUP_DIR"

# Archivos a respaldar (rutas absolutas)
ARCHIVOS=(
  "$BOT_DIR/auth_wa_baileys"
  "$BOT_DIR/grupos_autorizados.json"
  "$BOT_DIR/creditos.json"
  "$BOT_DIR/stats_grupos.json"
  "$BOT_DIR/stats_grupos_semanal.json"
  "$BOT_DIR/municipios_clave_cache.json"
)

# Filtrar solo los que existen
EXISTENTES=()
for f in "${ARCHIVOS[@]}"; do
  if [ -e "$f" ]; then
    EXISTENTES+=("$f")
  fi
done

if [ ${#EXISTENTES[@]} -eq 0 ]; then
  echo "[$(date +%H:%M:%S)] ⚠ Nada para respaldar."
  exit 0
fi

# Crear tarball
ARCHIVO="$BACKUP_DIR/bot-$FECHA.tar.gz"
tar czf "$ARCHIVO" "${EXISTENTES[@]}" 2>/dev/null

SIZE=$(du -h "$ARCHIVO" | cut -f1)
echo "[$(date +%H:%M:%S)] ✅ Backup creado: $ARCHIVO ($SIZE)"

# Limpiar backups viejos (>14 días)
ELIMINADOS=$(find "$BACKUP_DIR" -name "bot-*.tar.gz" -mtime +$RETAIN_DAYS -delete -print | wc -l)
if [ "$ELIMINADOS" -gt 0 ]; then
  echo "[$(date +%H:%M:%S)] 🧹 $ELIMINADOS backup(s) viejo(s) eliminados (>$RETAIN_DAYS días)."
fi

# Mostrar resumen
TOTAL=$(find "$BACKUP_DIR" -name "bot-*.tar.gz" | wc -l)
TOTAL_SIZE=$(du -sh "$BACKUP_DIR" | cut -f1)
echo "[$(date +%H:%M:%S)] 📊 $TOTAL backup(s) en $BACKUP_DIR ($TOTAL_SIZE)"
