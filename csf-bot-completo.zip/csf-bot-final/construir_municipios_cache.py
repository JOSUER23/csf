#!/usr/bin/env python3
"""
Construye municipios_clave_cache.json desde el CSV CPdescarga.txt de SEPOMEX.

Este archivo mapea: { ESTADO: { CLAVE_MUNICIPIO_INEGI: NOMBRE_MUNICIPIO } }

Es necesario porque cuando la API valida-curp.com.mx devuelve solo la
clave numérica (ej: ClaveMunicipioRegistro = 21 para Guerrero), el bot
necesita resolver esa clave al nombre real (COYUCA DE BENITEZ).

Sin este cache, el bot cae al fallback de "capital del estado", lo que
produce errores como mostrar CHILPANCINGO cuando debería ser COYUCA DE BENITEZ.

Uso:
    python3 construir_municipios_cache.py [ruta_csv_sepomex]

Si no se da ruta, busca: ./CPdescarga.txt, ./CPdescarga.txt.original
"""

import sys
import os
import json
import unicodedata


def quitar_acentos(s):
    """Normaliza string: mayúsculas, sin acentos, sin caracteres especiales."""
    if not s:
        return ""
    s = unicodedata.normalize('NFD', s)
    s = ''.join(c for c in s if unicodedata.category(c) != 'Mn')
    return s.upper().strip()


# Mapeo de claves INEGI de estado → nombre oficial usado en SEPOMEX
ESTADO_NOMBRES = {
    "01": "AGUASCALIENTES",
    "02": "BAJA CALIFORNIA",
    "03": "BAJA CALIFORNIA SUR",
    "04": "CAMPECHE",
    "05": "COAHUILA DE ZARAGOZA",
    "06": "COLIMA",
    "07": "CHIAPAS",
    "08": "CHIHUAHUA",
    "09": "CIUDAD DE MÉXICO",
    "10": "DURANGO",
    "11": "GUANAJUATO",
    "12": "GUERRERO",
    "13": "HIDALGO",
    "14": "JALISCO",
    "15": "MÉXICO",
    "16": "MICHOACÁN DE OCAMPO",
    "17": "MORELOS",
    "18": "NAYARIT",
    "19": "NUEVO LEÓN",
    "20": "OAXACA",
    "21": "PUEBLA",
    "22": "QUERÉTARO",
    "23": "QUINTANA ROO",
    "24": "SAN LUIS POTOSÍ",
    "25": "SINALOA",
    "26": "SONORA",
    "27": "TABASCO",
    "28": "TAMAULIPAS",
    "29": "TLAXCALA",
    "30": "VERACRUZ DE IGNACIO DE LA LLAVE",
    "31": "YUCATÁN",
    "32": "ZACATECAS",
}


def main():
    # Localizar el CSV
    if len(sys.argv) > 1:
        csv_path = sys.argv[1]
    else:
        candidatos = ["CPdescarga.txt", "CPdescarga.txt.original",
                     "/root/csf-bot/CPdescarga.txt",
                     "/root/csf-bot/CPdescarga.txt.original"]
        csv_path = None
        for c in candidatos:
            if os.path.exists(c):
                csv_path = c
                break

    if not csv_path or not os.path.exists(csv_path):
        sys.stderr.write(f"❌ No se encontró el CSV SEPOMEX.\n")
        sys.stderr.write(f"   Usa: python3 {sys.argv[0]} /ruta/CPdescarga.txt\n")
        sys.exit(1)

    print(f"📂 Leyendo: {csv_path}")

    # Estructura: { ESTADO_NOMBRE: { "001": "NOMBRE_MUNICIPIO", ... } }
    cache = {}

    # SEPOMEX viene en latin-1 (ISO-8859-1)
    with open(csv_path, encoding='latin-1') as f:
        # Saltar línea de copyright
        primera = f.readline()
        # Leer encabezado para identificar columnas
        header = f.readline().strip().split('|')

        try:
            idx_c_estado = header.index('c_estado')
            idx_c_mnpio  = header.index('c_mnpio')
            idx_D_mnpio  = header.index('D_mnpio')
            idx_d_estado = header.index('d_estado')
        except ValueError as e:
            sys.stderr.write(f"❌ Columnas requeridas no encontradas: {e}\n")
            sys.stderr.write(f"   Header: {header}\n")
            sys.exit(2)

        # Procesar todas las filas
        registros = 0
        for line in f:
            partes = line.rstrip('\n\r').split('|')
            if len(partes) < max(idx_c_estado, idx_c_mnpio, idx_D_mnpio, idx_d_estado) + 1:
                continue

            c_estado = partes[idx_c_estado].strip()
            c_mnpio  = partes[idx_c_mnpio].strip()
            d_mnpio  = partes[idx_D_mnpio].strip()
            d_estado = partes[idx_d_estado].strip()

            if not c_estado or not c_mnpio or not d_mnpio:
                continue

            # Usar el nombre oficial INEGI del estado (o el de SEPOMEX como fallback)
            estado_nombre = ESTADO_NOMBRES.get(c_estado.zfill(2))
            if not estado_nombre:
                estado_nombre = quitar_acentos(d_estado)

            # Clave de municipio normalizada a 3 dígitos
            clave_mun = c_mnpio.zfill(3)

            # Inicializar diccionario del estado si no existe
            if estado_nombre not in cache:
                cache[estado_nombre] = {}

            # Guardar el nombre del municipio (sin acentos, mayúsculas)
            municipio_norm = quitar_acentos(d_mnpio)
            cache[estado_nombre][clave_mun] = municipio_norm

            registros += 1

    # Resumen
    total_municipios = sum(len(v) for v in cache.values())
    print(f"✅ Procesados {registros} registros")
    print(f"✅ Estados: {len(cache)}")
    print(f"✅ Municipios únicos: {total_municipios}")

    # Verificación: Guerrero clave 21 debe ser COYUCA DE BENITEZ
    gro = cache.get('GUERRERO', {})
    print(f"\n📍 Verificación:")
    print(f"   Guerrero clave 021: {gro.get('021', '?')}")
    print(f"   Guerrero clave 029: {gro.get('029', '?')}")
    ver = cache.get('VERACRUZ DE IGNACIO DE LA LLAVE', {})
    print(f"   Veracruz clave 155: {ver.get('155', '?')}")
    cps = cache.get('CHIAPAS', {})
    print(f"   Chiapas  clave 101: {cps.get('101', '?')}")

    # Guardar
    output = "municipios_clave_cache.json"
    with open(output, 'w', encoding='utf-8') as f:
        json.dump(cache, f, ensure_ascii=False, indent=2)
    print(f"\n💾 Guardado: {output} ({os.path.getsize(output):,} bytes)")


if __name__ == '__main__':
    main()
