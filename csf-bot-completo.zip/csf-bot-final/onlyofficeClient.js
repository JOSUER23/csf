// ════════════════════════════════════════════════════════════════════════════
//  onlyofficeClient.js — Cliente único para conversión DOCX → PDF
//
//  Reemplaza a las funciones convertirAPdf() de generarCSFLocal.js y
//  convertirDocxAPdfOnlyOffice() de generarClonLocal.js. Antes había dos
//  implementaciones con divergencias sutiles:
//    - generarCSFLocal aceptaba XML y JSON, exigía solo fileUrl   ✅ tolerante
//    - generarClonLocal solo JSON, exigía endConvert === true     ❌ fallaba
//      cuando OnlyOffice cacheaba la conversión previa (mismo key reusado)
//      y devolvía fileUrl sin endConvert.
//
//  Ahora ambos llaman a este módulo. Cambios futuros en el protocolo de
//  OnlyOffice se hacen aquí UNA vez.
//
//  Mejoras adicionales respecto a las versiones originales:
//    - Reintento automático con backoff si OnlyOffice devuelve error -3/-4
//      (timeout interno o falta de recursos, transitorios).
//    - Validación del PDF resultante con magic bytes "%PDF" (no solo tamaño).
//    - Logs uniformes con prefijo [OnlyOffice] para facilitar grep en pm2 logs.
//    - Timeout por etapa (registro qr-server, conversión, descarga PDF)
//      en lugar de un único timeout global.
//    - Limpieza inmediata del .ref en qr-server tras descarga exitosa.
// ════════════════════════════════════════════════════════════════════════════

const fs    = require("fs");
const path  = require("path");
const http  = require("http");
const https = require("https");

// ── Configuración (override via env) ──────────────────────────────────────
const CONFIG = {
  ONLYOFFICE_URL:  process.env.ONLYOFFICE_URL  || "http://localhost:8083",
  HOST_IP:         process.env.SERVER_IP       || "172.17.0.1",
  QR_PORT:         process.env.QR_PORT         || 3000,

  TIMEOUT_REGISTRO:  5000,    // qr-server /tmp/register
  TIMEOUT_CONVERSION: 60000,  // OnlyOffice ConvertService.ashx
  TIMEOUT_DESCARGA:  30000,   // descarga del PDF resultante
  MAX_REINTENTOS:    2,       // reintentos en errores transitorios (-3, -4, ETIMEDOUT)
  RETRY_DELAY_MS:    1500,    // espera entre reintentos
};

// ── Errores transitorios de OnlyOffice que ameritan reintento ─────────────
// Códigos oficiales: https://api.onlyoffice.com/docs/docs-api/additional-api/conversion-api/error-codes/
//   -1: error desconocido del converter
//   -2: timeout (raro en sync)
//   -3: error de carga del documento (a veces es race con qr-server)
//   -4: error de descarga del documento (transitorio si la red parpadea)
//   -5: contraseña incorrecta (NO reintentar)
//   -6: error en la base de datos (transitorio)
//   -7: error de input (NO reintentar)
//   -8: token inválido (NO reintentar)
//    0: en progreso (con async:true)
const ERRORES_TRANSITORIOS = new Set([-1, -2, -3, -4, -6]);

// ── Logger uniforme ───────────────────────────────────────────────────────
function log(msg)  { console.log(`[OnlyOffice] ${msg}`); }
function warn(msg) { console.warn(`[OnlyOffice] ⚠️  ${msg}`); }

// ── Helper: petición HTTP/S con timeout ───────────────────────────────────
function httpRequest({ url, method, headers, body, timeout }) {
  return new Promise((resolve, reject) => {
    const urlObj = new URL(url);
    const isHttps = urlObj.protocol === "https:";
    const transport = isHttps ? https : http;

    const opts = {
      hostname: urlObj.hostname,
      port:     urlObj.port || (isHttps ? 443 : 80),
      path:     urlObj.pathname + urlObj.search,
      method:   method || "GET",
      headers:  headers || {},
      timeout,
    };

    let resuelto = false;
    const req = transport.request(opts, (res) => {
      let data = "";
      res.on("data", chunk => data += chunk);
      res.on("end", () => {
        if (!resuelto) { resuelto = true; resolve({ statusCode: res.statusCode, body: data }); }
      });
      res.on("error", (err) => {
        if (!resuelto) { resuelto = true; reject(err); }
      });
    });
    req.on("error", (err) => {
      if (!resuelto) { resuelto = true; reject(err); }
    });
    req.on("timeout", () => {
      req.destroy();
      if (!resuelto) { resuelto = true; reject(new Error(`HTTP timeout ${timeout}ms`)); }
    });
    if (body) req.write(body);
    req.end();
  });
}

// ── Helper: descargar archivo a disco con timeout ─────────────────────────
function descargarArchivo(fileUrl, destPath, timeoutMs) {
  return new Promise((resolve, reject) => {
    const urlObj = new URL(fileUrl);
    const isHttps = urlObj.protocol === "https:";
    const transport = isHttps ? https : http;

    let out = null;
    let req = null;
    let resuelto = false;

    // Helper: limpia recursos abiertos antes de rechazar. Sin esto, un timeout
    // o error de red dejaba el WriteStream y un PDF parcial en disco.
    const limpiarYRechazar = (err) => {
      if (resuelto) return;
      resuelto = true;
      try { if (out && !out.destroyed) out.destroy(); } catch (e) {}
      try { fs.unlinkSync(destPath); } catch (e) {}
      reject(err);
    };
    const resolverOk = () => {
      if (resuelto) return;
      resuelto = true;
      resolve();
    };

    req = transport.get(fileUrl, (res) => {
      if (res.statusCode !== 200) {
        res.resume(); // descartar body para liberar el socket
        return limpiarYRechazar(new Error(`Descarga PDF HTTP ${res.statusCode}`));
      }
      out = fs.createWriteStream(destPath);
      res.pipe(out);
      out.on("finish", resolverOk);
      out.on("error", limpiarYRechazar);
      res.on("error", limpiarYRechazar);
    });
    req.setTimeout(timeoutMs, () => {
      req.destroy();
      limpiarYRechazar(new Error(`Descarga PDF timeout ${timeoutMs}ms`));
    });
    req.on("error", limpiarYRechazar);
  });
}

// ── Registrar el DOCX en qr-server para que OnlyOffice lo pueda descargar ─
async function registrarEnQrServer(docxPath, fileKey) {
  if (!fs.existsSync(docxPath)) {
    throw new Error(`DOCX no existe: ${docxPath}`);
  }

  const payload = JSON.stringify({ key: fileKey, filePath: docxPath });
  const res = await httpRequest({
    url:     `http://localhost:${CONFIG.QR_PORT}/tmp/register`,
    method:  "POST",
    headers: {
      "Content-Type":   "application/json",
      "Content-Length": Buffer.byteLength(payload),
    },
    body:    payload,
    timeout: CONFIG.TIMEOUT_REGISTRO,
  });

  if (res.statusCode !== 200) {
    throw new Error(`qr-server HTTP ${res.statusCode}: ${res.body.slice(0, 200)}`);
  }

  let json;
  try { json = JSON.parse(res.body); }
  catch (e) { throw new Error(`qr-server parse: ${res.body.slice(0, 200)}`); }

  if (!json.ok) throw new Error(`qr-server registro falló: ${res.body.slice(0, 200)}`);

  return `http://${CONFIG.HOST_IP}:${CONFIG.QR_PORT}/tmp/${fileKey}`;
}

// ── Parser tolerante de respuesta OnlyOffice ──────────────────────────────
// Acepta JSON Y XML (versiones distintas + cuando falla el header Accept).
// Devuelve { fileUrl, errorCode } — el caller decide qué hacer con cada caso.
//
// IMPORTANTE: NO exigimos `endConvert === true`. Las versiones recientes de
// OnlyOffice a veces devuelven solo `fileUrl` (cuando reciclaron una
// conversión cacheada con el mismo `key`) y `endConvert` es undefined.
// Mientras `fileUrl` esté presente, la conversión está lista.
function parsearRespuesta(body) {
  const trimmed = (body || "").trim();
  if (!trimmed) return { fileUrl: null, errorCode: null, raw: body };

  // ── JSON ──
  if (trimmed.startsWith("{")) {
    try {
      const json = JSON.parse(trimmed);
      return {
        fileUrl:   json.fileUrl || null,
        errorCode: (typeof json.error === "number") ? json.error : null,
        raw:       trimmed,
      };
    } catch (e) {
      return { fileUrl: null, errorCode: null, raw: trimmed, parseError: e.message };
    }
  }

  // ── XML ──
  // <FileResult>
  //   <EndConvert>True</EndConvert>
  //   <FileType>pdf</FileType>
  //   <FileUrl>...</FileUrl>
  //   <Percent>100</Percent>
  // </FileResult>
  // O en caso de error:
  // <FileResult><Error>-4</Error></FileResult>
  const fileUrlMatch = trimmed.match(/<FileUrl>([^<]+)<\/FileUrl>/i);
  const errorMatch   = trimmed.match(/<Error>(-?\d+)<\/Error>/i);

  return {
    fileUrl:   fileUrlMatch ? fileUrlMatch[1].replace(/&amp;/g, "&") : null,
    errorCode: errorMatch   ? parseInt(errorMatch[1], 10)            : null,
    raw:       trimmed,
  };
}

// ── Llamar a ConvertService.ashx ──────────────────────────────────────────
async function llamarConvertService(fileKey, fileName, sourceUrl) {
  const payload = JSON.stringify({
    async:      false,
    filetype:   "docx",
    key:        fileKey,
    outputtype: "pdf",
    title:      fileName,
    url:        sourceUrl,
  });

  const res = await httpRequest({
    url:     `${CONFIG.ONLYOFFICE_URL}/ConvertService.ashx`,
    method:  "POST",
    headers: {
      "Content-Type":   "application/json",
      "Content-Length": Buffer.byteLength(payload),
      "Accept":         "application/json",
    },
    body:    payload,
    timeout: CONFIG.TIMEOUT_CONVERSION,
  });

  if (res.statusCode !== 200) {
    throw new Error(`OnlyOffice HTTP ${res.statusCode}: ${res.body.slice(0, 200)}`);
  }

  return parsearRespuesta(res.body);
}

// ── Validar que el archivo descargado es un PDF real ──────────────────────
// Verifica magic bytes "%PDF" (0x25 0x50 0x44 0x46) en los primeros 4 bytes.
// Antes solo se validaba que el tamaño fuera > 100 bytes, pero un HTML de
// error de 5KB también pasa esa validación y luego el cliente recibe basura.
function validarPdf(pdfPath) {
  const fd = fs.openSync(pdfPath, "r");
  try {
    const buf = Buffer.alloc(4);
    fs.readSync(fd, buf, 0, 4, 0);
    if (buf.toString("ascii") !== "%PDF") {
      const head = buf.toString("hex");
      throw new Error(`No es un PDF válido (magic bytes: 0x${head})`);
    }
  } finally {
    fs.closeSync(fd);
  }
  const size = fs.statSync(pdfPath).size;
  if (size < 1000) {
    throw new Error(`PDF sospechosamente pequeño (${size} bytes)`);
  }
  return size;
}

// ── Conversión completa con reintentos ────────────────────────────────────
// Esta es la función pública. Entrada: ruta al DOCX. Salida: ruta al PDF.
// Lanza Error solo si TODOS los reintentos fallan o el error es permanente.
async function convertirDocxAPdf(docxPath) {
  if (!docxPath) throw new Error("docxPath requerido");
  if (!fs.existsSync(docxPath)) throw new Error(`DOCX no existe: ${docxPath}`);

  const fileName = path.basename(docxPath);
  const pdfPath  = docxPath.replace(/\.docx$/i, ".pdf");

  let ultimoError = null;

  for (let intento = 1; intento <= CONFIG.MAX_REINTENTOS + 1; intento++) {
    // Nuevo key por intento para que OnlyOffice no devuelva caché del intento anterior
    const fileKey = `conv_${Date.now()}_${intento}`;
    const t0 = Date.now();

    try {
      // 1. Registrar DOCX en qr-server
      const sourceUrl = await registrarEnQrServer(docxPath, fileKey);

      // 2. Llamar a OnlyOffice
      const { fileUrl, errorCode, raw } = await llamarConvertService(fileKey, fileName, sourceUrl);

      // 2a. Error explícito de OnlyOffice
      if (errorCode !== null) {
        const esTransitorio = ERRORES_TRANSITORIOS.has(errorCode);
        const err = new Error(`OnlyOffice error ${errorCode}${esTransitorio ? " (transitorio)" : ""}`);
        err.errorCode = errorCode;
        err.transitorio = esTransitorio;
        throw err;
      }

      // 2b. Sin error pero sin fileUrl → respuesta corrupta
      if (!fileUrl) {
        throw new Error(`Respuesta sin fileUrl: ${raw.slice(0, 200)}`);
      }

      // 3. Descargar PDF
      // NOTA: si la URL devuelta apunta a localhost/127.0.0.1 (es el caso típico
      // cuando OnlyOffice corre en Docker bridge), funciona porque Node corre
      // en el host. Si en algún momento fuera distinto, OnlyOffice usa el mismo
      // hostname al que se hizo la request.
      await descargarArchivo(fileUrl, pdfPath, CONFIG.TIMEOUT_DESCARGA);

      // 4. Validar PDF
      const size = validarPdf(pdfPath);

      const ms = Date.now() - t0;
      log(`✅ ${fileName} → PDF ${(size/1024).toFixed(0)}KB en ${ms}ms (intento ${intento})`);
      return pdfPath;

    } catch (err) {
      ultimoError = err;
      const ms = Date.now() - t0;

      // Limpiar PDF parcial si quedó algo
      try { if (fs.existsSync(pdfPath)) fs.unlinkSync(pdfPath); } catch(e) {}

      // ¿Vale la pena reintentar?
      const esTransitorio =
        err.transitorio === true ||
        /timeout|ECONNRESET|ETIMEDOUT|ENETUNREACH|socket hang up/i.test(err.message);

      if (intento <= CONFIG.MAX_REINTENTOS && esTransitorio) {
        warn(`Intento ${intento} falló en ${ms}ms: ${err.message} — reintentando en ${CONFIG.RETRY_DELAY_MS}ms`);
        await new Promise(r => setTimeout(r, CONFIG.RETRY_DELAY_MS));
        continue;
      }

      // Error permanente o último intento
      warn(`Falló definitivamente tras ${intento} intento(s) en ${ms}ms: ${err.message}`);
      throw err;
    }
  }

  // Inalcanzable, pero por seguridad
  throw ultimoError || new Error("OnlyOffice: error desconocido");
}

// ── Exports ───────────────────────────────────────────────────────────────
module.exports = {
  convertirDocxAPdf,
  // Exportados para testing / diagnóstico independiente
  CONFIG,
  parsearRespuesta,
  validarPdf,
};

// ── CLI para diagnóstico independiente ────────────────────────────────────
// Uso: node onlyofficeClient.js /ruta/al/archivo.docx
if (require.main === module) {
  const docxArg = process.argv[2];
  if (!docxArg) {
    console.error("Uso: node onlyofficeClient.js <ruta-al-docx>");
    process.exit(1);
  }
  console.log(`[OnlyOffice] Config:`, CONFIG);
  convertirDocxAPdf(docxArg)
    .then(pdfPath => {
      console.log(`✅ Listo: ${pdfPath}`);
      process.exit(0);
    })
    .catch(err => {
      console.error(`❌ Error: ${err.message}`);
      if (err.stack) console.error(err.stack);
      process.exit(1);
    });
}
