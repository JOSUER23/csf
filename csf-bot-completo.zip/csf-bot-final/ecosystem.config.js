// ════════════════════════════════════════════════════════════════════════════
// ecosystem.config.js — Configuración PM2 para producción
//
// SETUP ACTUAL (verificado 21/05/2026):
//   - Servidor:    Hetzner CPX21 (Debian 12)
//   - OnlyOffice:  Docker container "onlyoffice/documentserver"
//                  red bridge default, gateway 172.17.0.1, puerto 8083
//   - qr-server:   Express en mismo host, puerto 3000 (proceso PM2 hermano)
//   - Bot:         Node.js + Baileys 6.7.20 + Playwright (solo en generarCSFLocal)
//
// MIGRACIÓN A OTRO SERVIDOR:
//   1. Verificar con `docker network ls` que solo haya redes "bridge/host/none"
//   2. Verificar con `docker inspect onlyoffice | grep Gateway` la IP del host
//   3. Si la IP es distinta a 172.17.0.1, actualizar SERVER_IP abajo
//   4. Si OnlyOffice está en otro puerto, actualizar ONLYOFFICE_URL
//   5. Subdominios DNS (siat-sat.site, validador.siat-sat.site) deben apuntar
//      al servidor y tener SSL configurado en Nginx
//
// Regla de memoria:
//   --max-old-space-size (Node heap) debe ser MENOR que max_memory_restart
//   para que Node haga GC agresivo antes de que PM2 mate el proceso.
//   Valores actuales: heap=1536MB < restart=2048MB ✓
//
// Rotación de logs (configurar una sola vez):
//   pm2 install pm2-logrotate
//   pm2 set pm2-logrotate:max_size 10M
//   pm2 set pm2-logrotate:retain 7
//   pm2 set pm2-logrotate:compress true
// ════════════════════════════════════════════════════════════════════════════

module.exports = {
  apps: [
    // ════════════════════════════════════════════════════════════════════════
    //  BOT PRINCIPAL — WhatsApp + Baileys + generación CSF/Clon
    // ════════════════════════════════════════════════════════════════════════
    {
      name:   "csf-bot",
      script: "index.js",

      env: {
        NODE_ENV: "production",

        // ──────────────────────────────────────────────────────────────────
        // URLs PÚBLICAS (visibles desde internet — usadas en los QR de las
        // constancias clonadas para que cualquiera pueda validar el QR
        // escaneándolo desde su teléfono).
        // Deben tener DNS apuntando al servidor + SSL en Nginx.
        // ──────────────────────────────────────────────────────────────────
        QR_BASE_URL:      "https://siat-sat.site",
        QR_VALIDADOR_URL: "https://validador.siat-sat.site",

        // ──────────────────────────────────────────────────────────────────
        // SERVICIOS INTERNOS (solo accesibles desde el mismo host).
        // El bot los usa para convertir DOCX → PDF con OnlyOffice.
        // ──────────────────────────────────────────────────────────────────

        // Puerto del qr-server (Express, otro proceso PM2 abajo).
        // El bot lo usa para registrar DOCX temporales que OnlyOffice descarga.
        QR_PORT: "3000",

        // URL del OnlyOffice Document Server.
        // Como el contenedor mapea su puerto 80 → host:8083, accedemos por
        // localhost desde el host (Node corre en el host, no en contenedor).
        ONLYOFFICE_URL: "http://localhost:8083",

        // IP del HOST visible DESDE DENTRO del contenedor de OnlyOffice.
        // OnlyOffice necesita esta IP para descargar el DOCX del qr-server.
        // - Si docker network ls solo muestra "bridge/host/none" (default),
        //   esto es siempre 172.17.0.1 (gateway de la red bridge).
        // - Si usas docker-compose con red custom, podría ser diferente.
        //   Verificar con: docker inspect onlyoffice | grep Gateway
        SERVER_IP: "172.17.0.1",

        // ──────────────────────────────────────────────────────────────────
        // TOKEN API CURP — valida-curp.com.mx
        // Movido aquí desde el código fuente para no exponerlo si el código
        // se sube a GitHub o se comparte. Si se cae este servicio (créditos
        // agotados, etc.) el bot hace fallback automático a gob.mx.
        // ──────────────────────────────────────────────────────────────────
        CURP_API_TOKEN: "b075a154-c369-4799-8f93-51d9d98260e5",
      },

      // ── Reinicio automático ──
      autorestart:    true,
      max_restarts:   15,
      min_uptime:     "60s",
      restart_delay:  5000,

      // ── Apagado limpio ──
      kill_timeout:    8000,
      listen_timeout: 10000,

      // ── Memoria ──
      max_memory_restart: "2048M",

      // ── Logs ──
      error_file:      "./logs/error.log",
      out_file:        "./logs/out.log",
      log_date_format: "YYYY-MM-DD HH:mm:ss",
      merge_logs:      true,

      // ── Watch ──
      watch: false,

      // ── Node args ──
      node_args: "--max-old-space-size=1536",
    },

    // ════════════════════════════════════════════════════════════════════════
    //  QR-SERVER — Express que sirve réplicas QR + archivos temp para OnlyOffice
    // ════════════════════════════════════════════════════════════════════════
    {
      name:   "qr-server",
      script: "qr-server.js",

      env: {
        NODE_ENV: "production",

        // Puerto local del Express. DEBE coincidir con QR_PORT del bot arriba.
        // Si cambias este, cambia el de arriba también.
        QR_PORT: "3000",
      },

      autorestart:        true,
      max_restarts:       10,
      min_uptime:         "30s",
      restart_delay:      3000,
      max_memory_restart: "256M",

      error_file:      "./logs/qr-error.log",
      out_file:        "./logs/qr-out.log",
      log_date_format: "YYYY-MM-DD HH:mm:ss",
      merge_logs:      true,
      watch:           false,
    },
  ],
};
