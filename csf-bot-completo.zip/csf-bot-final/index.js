/**
 * BOT WhatsApp → CSF + RFC Generator — SPARTAN PRO
 * v5.0 — Vercel removido, scrape directo SAT
 *
 * ══════════════════════════════════════════════════════════════════════════════
 *  CAMBIOS v5.0 — Eliminación de dependencia Vercel
 *  1. CSF generada localmente con generarCSFLocal.js (Playwright → SAT directo)
 *  2. Eliminadas ~770 líneas de manejo de sesión Vercel (login, keepalive, etc.)
 *  3. Browser compartido (csfBrowser) ahora solo para CURP gob.mx y SAT lookup
 *  4. Detección de RFC inválido en scrapeador → Error("datos_invalidos")
 *  5. Timeout SAT → Error("timeout_descarga"), TIMEOUT_GENERAR aumentado a 90s
 *  6. Comando =estado muestra "🌐 SAT" en lugar de "🌐 CSF"
 * ──────────────────────────────────────────────────────────────────────────────
 *  CAMBIOS v4.1 — Pulido final
 *  1. WhatsApp: reconexión agresiva (2s,3s,5s,8s,12s) + watchdog cada 30s
 *  2. WhatsApp: destroy() previo, auth_failure reconecta, change_state log
 *  3. CURP gob.mx: reload() en cada consulta (no reutilizar página vieja)
 *  4. YODA: espacio en apellidos vacíos + quitar espacios del RFC generado
 *  5. Mensajes SPARTAN PRO unificados en todos los flujos
 *  6. parsearMultiples: emparejamiento por proximidad, ignora "No id"
 *  7. convertir: solo gob.mx, respuesta solo RFC
 * ══════════════════════════════════════════════════════════════════════════════
 */

const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  downloadMediaMessage,
  fetchLatestBaileysVersion,
  isJidGroup,
} = require("@whiskeysockets/baileys");
const { Boom } = require("@hapi/boom");
const { chromium } = require("playwright");
const { generarCSFLocal, cerrarBrowserSAT } = require("./generarCSFLocal");
const { generarConstanciaLocal, generarRFC, cachearRespuestaCURP } = require("./generarClonLocal");
const fs = require("fs");
const path = require("path");
const https = require("https");
const qrcode = require("qrcode-terminal");
const sharp = require("sharp");
const { readBarcodesFromImageData } = require("zxing-wasm/reader");
const zbarWasm = require("@undecaf/zbar-wasm");

const CONFIG = {
  KEEPALIVE_MINUTOS: 2,
  WATCHDOG_MINUTOS: 1,
  DOWNLOAD_DIR: path.join(__dirname, "descargas"),
  PAUSA_ENTRE_TAREAS: 100,
  MAX_COLA: 25,
  TIMEOUT_GENERAR: 90000,  // scrape SAT + plantilla + Adobe puede tardar hasta 90s
  DOWNLOAD_TIMEOUT: 40000,
  CONCURRENCY_QR: 6,
  // ── Autorización de grupos ──
  ADMINS: [
    // LIDs de los 5 números admin
    "90113044414476@lid",
    "38457875402982@lid",
    "146780608020517@lid",
    "105110885687341@lid",
    "85848477442107@lid",
    // Números por si WhatsApp cambia el formato
    "5219612539685@c.us",
    "529612539685@c.us",
    "5219612769708@c.us",
    "529612769708@c.us",
    "5219613354115@c.us",
    "529613354115@c.us",
    "5219616528893@c.us",
    "529616528893@c.us",
    "5217719545102@c.us",
    "527719545102@c.us",
  ],
  // Nombres de admins para =grupos
  ADMIN_NOMBRES: {
    "146780608020517@lid": "Jose Angel",
    "5219612769708@c.us": "Jose Angel",
    "529612769708@c.us": "Jose Angel",
    "38457875402982@lid": "Distribuidora Documental MX",
    "5219613354115@c.us": "Distribuidora Documental MX",
    "529613354115@c.us": "Distribuidora Documental MX",
    "90113044414476@lid": "Josue R",
    "5219612539685@c.us": "Josue R",
    "529612539685@c.us": "Josue R",
    "105110885687341@lid": "Daniel R",
    "5219616528893@c.us": "Daniel R",
    "529616528893@c.us": "Daniel R",
    "85848477442107@lid": "DAVID R",
    "5217719545102@c.us": "DAVID R",
    "527719545102@c.us": "DAVID R",
  },
  GRUPOS_FILE:   path.join(__dirname, "grupos_autorizados.json"),
  CREDITOS_FILE: path.join(__dirname, "creditos.json"),
  STATS_FILE:    path.join(__dirname, "stats_grupos.json"),
  STATS_SEM_FILE: path.join(__dirname, "stats_grupos_semanal.json"),
};

if (!fs.existsSync(CONFIG.DOWNLOAD_DIR)) {
  fs.mkdirSync(CONFIG.DOWNLOAD_DIR, { recursive: true });
}

// ══════════════════════════════════════════════════════════════════════════════
//  OFICINAS DE EMISIÓN — catálogo completo del dropdown YODA
// ══════════════════════════════════════════════════════════════════════════════

const OFICINAS_EMISION = [
  "CUAUHTEMOC , CIUDAD DE MEXICO",
  "AGUASCALIENTES , AGUASCALIENTES",
  "LOS CABOS , BAJA CALIFORNIA SUR",
  "LA PAZ , BAJA CALIFORNIA SUR",
  "ENSENADA , BAJA CALIFORNIA",
  "MEXICALI , BAJA CALIFORNIA",
  "TECATE , BAJA CALIFORNIA",
  "TIJUANA , BAJA CALIFORNIA",
  "CAMPECHE , CAMPECHE",
  "CIUDAD DEL CARMEN , CAMPECHE",
  "TAPACHULA , CHIAPAS",
  "TUXTLA GUTIERREZ , CHIAPAS",
  "SAN CRISTOBAL DE LAS CASAS , CHIAPAS",
  "COMITAN DE DOMINGUEZ , CHIAPAS",
  "CHIHUAHUA , CHIHUAHUA",
  "JUAREZ , CHIHUAHUA",
  "MANZANILLO , COLIMA",
  "XOCHIMILCO , CIUDAD DE MEXICO",
  "MIGUEL HIDALGO , CIUDAD DE MEXICO",
  "ECATEPEC DE MORELOS , ESTADO DE MEXICO",
  "NAUCALPAN DE JUAREZ , ESTADO DE MEXICO",
  "TEXCOCO , ESTADO DE MEXICO",
  "VALLE DE BRAVO , ESTADO DE MEXICO",
  "CELAYA , GUANAJUATO",
  "GUANAJUATO , GUANAJUATO",
  "IRAPUATO , GUANAJUATO",
  "LEON , GUANAJUATO",
  "SALAMANCA , GUANAJUATO",
  "SAN MIGUEL DE ALLENDE , GUANAJUATO",
  "ACAPULCO DE JUAREZ , GUERRERO",
  "CHILPANCINGO DE LOS BRAVOS , GUERRERO",
  "IGUALA DE LA INDEPENDENCIA , GUERRERO",
  "ZIHUATANEJO DE AZUETA , GUERRERO",
  "GUADALAJARA , JALISCO",
  "LAGOS DE MORENO , JALISCO",
  "ZAPOPAN , JALISCO",
  "MONTERREY , NUEVO LEON",
  "GALEANA , NUEVO LEON",
  "OAXACA DE JUAREZ , OAXACA",
  "PUERTO ESCONDIDO , OAXACA",
  "SALINA CRUZ , OAXACA",
  "JUCHITAN DE ZARAGOZA , OAXACA",
  "SAN JUAN BAUTISTA TUXTEPEC , OAXACA",
  "PUEBLA , PUEBLA",
  "JUAN DEL RIO , QUERETARO",
  "QUERETARO , QUERETARO",
  "CANCUN , QUINTANA ROO",
  "COZUMEL , QUINTANA ROO",
  "PLAYA DEL CARMEN , QUINTANA ROO",
  "CULIACAN , SINALOA",
  "GUASAVE , SINALOA",
  "NOVOLATO , SINALOA",
  "SALVADOR ALVARADO , SINALOA",
  "LOS MOCHIS , SINALOA",
  "HERMOSILLO , SONORA",
  "GUAYMAS , SONORA",
  "NOGALES , SONORA",
  "NAVOJOA , SONORA",
  "CARDENAS , TABASCO",
  "CENTRO , TABASCO",
  "VILLAHERMOSA , TABASCO",
  "APIZACO , TLAXCALA",
  "TLAXCALA , TLAXCALA",
  "MATAMOROS , TAMAULIPAS",
  "MIGUEL ALEMAN , TAMAULIPAS",
  "CIUDAD VICTORIA , TAMAULIPAS",
  "CIUDAD MANTE , TAMAULIPAS",
  "NUEVO LAREDO , TAMAULIPAS",
  "REYNOSA , TAMAULIPAS",
  "SAN FERNANDO , TAMAULIPAS",
  "TAMPICO , TAMAULIPAS",
  "SAN LUIS POTOSI , SAN LUIS POTOSI",
  "CIUDAD VALLES , SAN LUIS POTOSI",
  "MATEHUALA , SAN LUIS POTOSI",
  "BOCA DEL RIO , VERACRUZ",
  "COATZACOALCOS , VERACRUZ",
  "CORDOBA , VERACRUZ",
  "ORIZABA , VERACRUZ",
  "POZA RICA , VERACRUZ",
  "TUXPAN , VERACRUZ",
  "XALAPA , VERACRUZ",
  "MERIDA , YUCATAN",
  "VALLADOLID , YUCATAN",
  "FRESNILLO , ZACATECAS",
];

// ── Gestión de grupos autorizados ──
let gruposAutorizados = new Map(); // chatId → adminId

function cargarGrupos() {
  try {
    if (fs.existsSync(CONFIG.GRUPOS_FILE)) {
      const data = JSON.parse(fs.readFileSync(CONFIG.GRUPOS_FILE, "utf-8"));
      if (Array.isArray(data)) {
        // Formato viejo: descartar, necesitan re-activarse
        gruposAutorizados = new Map();
        console.log(`📋 Formato viejo detectado — ${data.length} grupo(s) descartados. Necesitan =activar de nuevo.`);
      } else {
        // Formato nuevo: { chatId: adminId }
        gruposAutorizados = new Map(Object.entries(data));
        // Limpiar solo grupos sin adminId (valor null/vacío) — no eliminar por formato de ID
        let limpiados = 0;
        for (const [gId, adminId] of gruposAutorizados) {
          if (!adminId || adminId === "desconocido") {
            gruposAutorizados.delete(gId);
            limpiados++;
          }
        }
        if (limpiados > 0) {
          guardarGrupos();
          console.log(`🧹 ${limpiados} grupo(s) sin admin eliminados.`);
        }
      }
      console.log(`📋 ${gruposAutorizados.size} grupo(s) autorizado(s) cargado(s).`);
    }
  } catch (e) {
    console.warn("⚠️  Error cargando grupos:", e.message);
  }
}

function guardarGrupos() {
  try {
    const obj = Object.fromEntries(gruposAutorizados);
    fs.writeFileSync(CONFIG.GRUPOS_FILE, JSON.stringify(obj, null, 2));
  } catch (e) {
    console.warn("⚠️  Error guardando grupos:", e.message);
  }
}

function esAdmin(msg) {
  const autor = msg.author || msg.from;
  return CONFIG.ADMINS.includes(autor);
}

function grupoAutorizado(chatId) {
  return gruposAutorizados.has(chatId);
}

cargarGrupos();

// Limpiar PDFs huérfanos de ejecuciones anteriores (crashes, timeouts)
function limpiarDescargasHuerfanas() {
  try {
    const archivos = fs.readdirSync(CONFIG.DOWNLOAD_DIR);
    let borrados = 0;
    const ahora = Date.now();
    for (const archivo of archivos) {
      if (!archivo.endsWith(".pdf") && !archivo.endsWith(".docx")) continue;
      const ruta = path.join(CONFIG.DOWNLOAD_DIR, archivo);
      try {
        const stat = fs.statSync(ruta);
        // FIX: subido de 10 a 30 min. Si hay rate-limit largo o muchos mensajes
        // en cola, un PDF puede tardar más de 10 min en enviarse. Borrarlo antes
        // hacía que el cliente recibiera "archivo no encontrado".
        if (ahora - stat.mtimeMs > 30 * 60 * 1000) {
          fs.unlinkSync(ruta);
          borrados++;
        }
      } catch (e) {}
    }
    if (borrados > 0) console.log(`🧹 ${borrados} PDF(s) huérfano(s) eliminado(s).`);
  } catch (e) {}
}

limpiarDescargasHuerfanas();
// Limpiar periódicamente cada 30 min. unref() para que este timer no impida
// que el proceso termine si llega a hacer apagado limpio.
setInterval(limpiarDescargasHuerfanas, 30 * 60 * 1000).unref?.();


const esperar = (ms) => new Promise((r) => setTimeout(r, ms));

function randInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
function esperarHumano(minMs = 300, maxMs = 1200) {
  return esperar(randInt(minMs, maxMs));
}

let csfBrowser   = null;
let csfContext    = null;  // Mantenido para limpieza en cerrarNavegador (legacy)
let csfPage      = null;   // Mantenido para compatibilidad con código antiguo (legacy)
let generandoCSF    = false;
let generandoDesde  = null;

const stats = {
  exitosas: 0,
  fallidas: 0,
  inicio: new Date(),
  hoy: 0,
  ultimoReset: new Date().toDateString(), // Fecha de hoy (sin hora)
};

// Reset automático del contador "hoy" cuando cambia el día
function verificarResetDiario() {
  const hoyStr = new Date().toDateString();
  if (stats.ultimoReset !== hoyStr) {
    console.log(`📅 Nuevo día — reseteando contador "hoy" (era ${stats.hoy})`);
    stats.hoy = 0;
    stats.ultimoReset = hoyStr;
  }
}
// Verificar cada hora si cambió el día (para resetear contador hoy)
setInterval(verificarResetDiario, 60 * 60 * 1000).unref?.();

// Stats por grupo: chatId → { csf, clon, errores }
const statsPorGrupo = new Map();

// FIX Bug #44: contadores de solicitudes por ADMIN (no solo por grupo).
// Permite ver en =grupos y =grupos_semanal cuántas solicitudes hace cada admin
// individual, independiente del grupo donde las haga. Solo cuenta solicitudes
// EXITOSAS hechas por admins (no usuarios normales).
const statsPorAdmin = new Map();
const statsPorAdminSemanal = new Map();

function getGrupoStats(chatId) {
  if (!statsPorGrupo.has(chatId)) {
    statsPorGrupo.set(chatId, { csf: 0, clon: 0, errores: 0 });
  }
  return statsPorGrupo.get(chatId);
}

function getAdminStats(adminId) {
  if (!statsPorAdmin.has(adminId)) {
    statsPorAdmin.set(adminId, { csf: 0, clon: 0 });
  }
  return statsPorAdmin.get(adminId);
}

function getAdminStatsSemanal(adminId) {
  if (!statsPorAdminSemanal.has(adminId)) {
    statsPorAdminSemanal.set(adminId, { csf: 0, clon: 0 });
  }
  return statsPorAdminSemanal.get(adminId);
}

// FIX Bug #33: debounce para no escribir a disco en cada solicitud.
// Antes: 2 writeFileSync por solicitud bloqueaban el event loop bajo alta carga.
// Ahora: las escrituras se acumulan y se hacen en lote cada 5 segundos.
let _statsDirty = false;
let _statsSemanalDirty = false;

function _guardarStatsAhora() {
  try {
    // FIX Bug #44: incluir stats de admins en el archivo de stats diarias
    const obj = { fecha: statsHoy(), grupos: {}, admins: {} };
    for (const [chatId, s] of statsPorGrupo) obj.grupos[chatId] = s;
    for (const [adminId, s] of statsPorAdmin) obj.admins[adminId] = s;
    fs.writeFileSync(CONFIG.STATS_FILE, JSON.stringify(obj, null, 2));
  } catch (e) { console.warn("⚠️  No se pudieron guardar stats:", e.message); }
}

function guardarStats() {
  _statsDirty = true; // marcar pendiente; se persiste en el flush periódico
}

function flushStatsSiPendiente() {
  if (_statsDirty) { _guardarStatsAhora(); _statsDirty = false; }
  if (_statsSemanalDirty) { _guardarStatsSemanalAhora(); _statsSemanalDirty = false; }
}

// Flush cada 5s. unref() para no bloquear apagadoLimpio.
setInterval(flushStatsSiPendiente, 5000).unref?.();

function statsHoy() {
  // Fecha en CDMX (UTC-6) para el reset
  const cdmx = new Date(Date.now() - 6 * 3600000);
  return `${cdmx.getUTCFullYear()}-${String(cdmx.getUTCMonth()+1).padStart(2,"0")}-${String(cdmx.getUTCDate()).padStart(2,"0")}`;
}

function cargarStats() {
  try {
    if (!fs.existsSync(CONFIG.STATS_FILE)) return;
    const data = JSON.parse(fs.readFileSync(CONFIG.STATS_FILE, "utf8"));

    // Formato nuevo: { fecha, grupos: {...} }
    // Formato antiguo: { chatId: { csf, clon, errores } }
    const esNuevoFormato = data.fecha && data.grupos;
    const fechaGuardada = esNuevoFormato ? data.fecha : null;
    const grupos = esNuevoFormato ? data.grupos : data;

    // Si es de otro día → no cargar (reset)
    if (fechaGuardada && fechaGuardada !== statsHoy()) {
      console.log(`📅 Stats de ayer (${fechaGuardada}) — reseteando contadores diarios.`);
      guardarStats(); // guardar vacío con fecha de hoy
      return;
    }

    for (const [chatId, s] of Object.entries(grupos)) {
      statsPorGrupo.set(chatId, { csf: s.csf || 0, clon: s.clon || 0, errores: s.errores || 0 });
    }
    // FIX Bug #44: cargar también stats de admins si existen en el archivo
    if (data.admins) {
      for (const [adminId, s] of Object.entries(data.admins)) {
        statsPorAdmin.set(adminId, { csf: s.csf || 0, clon: s.clon || 0 });
      }
    }
    console.log(`📊 Stats cargadas para ${statsPorGrupo.size} grupo(s) y ${statsPorAdmin.size} admin(s) (${statsHoy()}).`);
  } catch (e) { console.warn("⚠️  No se pudieron cargar stats:", e.message); }
}

// Reset automático a medianoche CDMX (UTC-6)
function programarResetStats() {
  const ahora = new Date(Date.now() - 6 * 3600000); // hora CDMX
  // 11pm CDMX del día actual, o del día siguiente si ya pasaron las 11pm
  let reset11pm = new Date(Date.UTC(ahora.getUTCFullYear(), ahora.getUTCMonth(), ahora.getUTCDate(), 23, 0, 0));
  if (ahora.getUTCHours() >= 23) {
    reset11pm = new Date(Date.UTC(ahora.getUTCFullYear(), ahora.getUTCMonth(), ahora.getUTCDate() + 1, 23, 0, 0));
  }
  const msHastaMedianoche = reset11pm.getTime() - (Date.now() - 6 * 3600000);

  setTimeout(async () => {
    console.log(`📅 11pm CDMX — enviando resumen diario y reseteando stats`);

    // ── Enviar resumen del día al grupo RFC e idCIF bot ──
    const GRUPO_RESUMEN = "120363406508489674@g.us";
    try {
      if (waClient) {
        // Construir el mismo resumen que =grupos
        const resolverNombreAdminRes = (adminId) => {
          if (!adminId) return "Sin admin";
          if (CONFIG.ADMIN_NOMBRES[adminId]) return CONFIG.ADMIN_NOMBRES[adminId];
          const numBase = adminId.replace(/^(521?|)/, "").replace(/@.*$/, "");
          for (const [key, nombre] of Object.entries(CONFIG.ADMIN_NOMBRES)) {
            const keyBase = key.replace(/^(521?|)/, "").replace(/@.*$/, "");
            if (keyBase === numBase) return nombre;
          }
          return adminId;
        };

        const porAdminRes = new Map();
        await Promise.all(
          Array.from(gruposAutorizados.entries()).map(async ([gId, adminId]) => {
            const adminNombre = resolverNombreAdminRes(adminId);
            if (!porAdminRes.has(adminNombre)) porAdminRes.set(adminNombre, []);
            let nombreGrupo = gId;
            try {
              const chatGrupo = await waClient.getChatById(gId);
              nombreGrupo = chatGrupo.name || gId;
            } catch (e) {}
            const gs = getGrupoStats(gId);
            porAdminRes.get(adminNombre).push({ nombreGrupo, gs });
          })
        );

        const fechaCDMX = new Date(Date.now() - 6 * 3600000);
        const fechaStr = `${String(fechaCDMX.getUTCDate()).padStart(2,"0")}/${String(fechaCDMX.getUTCMonth()+1).padStart(2,"0")}/${fechaCDMX.getUTCFullYear()}`;
        let resumen = `📊 *RESUMEN DEL DÍA — ${fechaStr}*

`;
        let totalCSF = 0, totalClon = 0, totalErrores = 0, numG = 0;

        for (const [adminNombre, grupos] of porAdminRes) {
          resumen += `👤 *${adminNombre}*
`;
          resumen += `━━━━━━━━━━━━━━━━━━━━━━━━━━
`;
          for (const { nombreGrupo, gs } of grupos) {
            numG++;
            resumen += `  *${numG}.* ${nombreGrupo}
`;
            resumen += `     📄 CSF: ${gs.csf}  📋 Clon: ${gs.clon || 0}  ❌ Errores: ${gs.errores}
`;
            totalCSF += gs.csf;
            totalClon += (gs.clon || 0);
            totalErrores += gs.errores;
          }
          resumen += `
`;
        }

        resumen += `━━━━━━━━━━━━━━━━━━━━━━━━━━
`;
        resumen += `📄 *Total CSF:* ${totalCSF}
`;
        resumen += `📋 *Total Clon:* ${totalClon}
`;
        resumen += `❌ *Total Errores:* ${totalErrores}
`;
        resumen += `👥 *Grupos activos:* ${gruposAutorizados.size}`;

        // FIX: getChatById no devuelve un objeto con .sendMessage en este wrapper.
        // Usar waSendTexto directamente (que sí está implementado vía Baileys).
        await waSendTexto(GRUPO_RESUMEN, resumen);
        console.log(`✅ Resumen diario enviado a ${GRUPO_RESUMEN}`);
      }
    } catch (e) {
      console.warn(`⚠️  No se pudo enviar resumen diario: ${e.message}`);
    }

    // ── Resetear contadores ──
    statsPorGrupo.clear();
    statsPorAdmin.clear(); // FIX Bug #44: también resetear admins
    guardarStats();
    flushStatsSiPendiente(); // FIX Bug #33: persistir el reset inmediatamente
    programarResetStats(); // reprogramar para mañana
  }, msHastaMedianoche);

  const h = Math.floor(msHastaMedianoche / 3600000);
  const m = Math.floor((msHastaMedianoche % 3600000) / 60000);
  console.log(`⏰ Reset stats programado en ${h}h ${m}m (11pm CDMX)`);
}

cargarStats();
programarResetStats();

// ── Stats semanales por grupo ─────────────────────────────────────────────────
const statsSemanalPorGrupo = new Map();

function getGrupoStatsSemanal(chatId) {
  if (!statsSemanalPorGrupo.has(chatId)) {
    statsSemanalPorGrupo.set(chatId, { csf: 0, clon: 0, errores: 0 });
  }
  return statsSemanalPorGrupo.get(chatId);
}

function semanaActual() {
  // Número de semana ISO en CDMX (UTC-6)
  const cdmx = new Date(Date.now() - 6 * 3600000);
  const inicio = new Date(Date.UTC(cdmx.getUTCFullYear(), 0, 1));
  const diff = cdmx - inicio;
  const semana = Math.floor(diff / (7 * 24 * 3600 * 1000));
  return `${cdmx.getUTCFullYear()}-S${String(semana).padStart(2, "0")}`;
}

function _guardarStatsSemanalAhora() {
  try {
    // FIX Bug #44: incluir stats de admins en el archivo de stats semanales
    const obj = { semana: semanaActual(), grupos: {}, admins: {} };
    for (const [chatId, s] of statsSemanalPorGrupo) obj.grupos[chatId] = s;
    for (const [adminId, s] of statsPorAdminSemanal) obj.admins[adminId] = s;
    fs.writeFileSync(CONFIG.STATS_SEM_FILE, JSON.stringify(obj, null, 2));
  } catch (e) { console.warn("⚠️  No se pudieron guardar stats semanales:", e.message); }
}

function guardarStatsSemanal() {
  _statsSemanalDirty = true; // FIX Bug #33: ver función guardarStats arriba
}

function cargarStatsSemanal() {
  try {
    if (!fs.existsSync(CONFIG.STATS_SEM_FILE)) return;
    const data = JSON.parse(fs.readFileSync(CONFIG.STATS_SEM_FILE, "utf8"));
    if (data.semana && data.semana !== semanaActual()) {
      console.log(`📅 Stats semanales de semana anterior (${data.semana}) — reseteando.`);
      guardarStatsSemanal();
      return;
    }
    const grupos = data.grupos || data;
    for (const [chatId, s] of Object.entries(grupos)) {
      statsSemanalPorGrupo.set(chatId, { csf: s.csf || 0, clon: s.clon || 0, errores: s.errores || 0 });
    }
    // FIX Bug #44: cargar también stats de admins si existen
    if (data.admins) {
      for (const [adminId, s] of Object.entries(data.admins)) {
        statsPorAdminSemanal.set(adminId, { csf: s.csf || 0, clon: s.clon || 0 });
      }
    }
    console.log(`📊 Stats semanales cargadas para ${statsSemanalPorGrupo.size} grupo(s) y ${statsPorAdminSemanal.size} admin(s) (${semanaActual()}).`);
  } catch (e) { console.warn("⚠️  No se pudieron cargar stats semanales:", e.message); }
}

// Reset semanal: Domingo 11:30pm CDMX
function programarResetStatsSemanal() {
  const ahora = new Date(Date.now() - 6 * 3600000); // hora CDMX
  const diaSemana = ahora.getUTCDay(); // 0=Dom, 1=Lun... 6=Sab
  // FIX Bug #45: si hoy es domingo Y aún no son las 11:30pm, disparar HOY.
  // Antes saltaba el reset del mismo domingo si el bot arrancaba en domingo
  // por la mañana/tarde.
  const minutosActualesCDMX = ahora.getUTCHours() * 60 + ahora.getUTCMinutes();
  const minutoObjetivo = 23 * 60 + 30; // 23:30 = 11:30pm
  let diasHastaDom;
  if (diaSemana === 0 && minutosActualesCDMX < minutoObjetivo) {
    diasHastaDom = 0; // disparar HOY
  } else if (diaSemana === 0) {
    diasHastaDom = 7; // ya pasaron las 11:30pm del domingo, ir al siguiente
  } else {
    diasHastaDom = 7 - diaSemana; // días hasta el próximo domingo
  }
  const proximoDom = new Date(Date.UTC(
    ahora.getUTCFullYear(), ahora.getUTCMonth(), ahora.getUTCDate() + diasHastaDom,
    23, 30, 0 // 11:30pm CDMX = 23:30 hora CDMX
  ));
  const msHasta = proximoDom.getTime() - (Date.now() - 6 * 3600000);

  setTimeout(async () => {
    console.log(`📅 Domingo 11:30pm CDMX — enviando resumen semanal y reseteando stats`);

    const GRUPO_RESUMEN = "120363406508489674@g.us";
    try {
      if (waClient) {
        const resolverNombreAdminSemRes = (adminId) => {
          if (!adminId) return "Sin admin";
          if (CONFIG.ADMIN_NOMBRES[adminId]) return CONFIG.ADMIN_NOMBRES[adminId];
          const numBase = adminId.replace(/^(521?|)/, "").replace(/@.*$/, "");
          for (const [key, nombre] of Object.entries(CONFIG.ADMIN_NOMBRES)) {
            const keyBase = key.replace(/^(521?|)/, "").replace(/@.*$/, "");
            if (keyBase === numBase) return nombre;
          }
          return adminId;
        };

        const porAdminSemRes = new Map();
        await Promise.all(
          Array.from(gruposAutorizados.entries()).map(async ([gId, adminId]) => {
            const adminNombre = resolverNombreAdminSemRes(adminId);
            if (!porAdminSemRes.has(adminNombre)) porAdminSemRes.set(adminNombre, []);
            let nombreGrupo = gId;
            try {
              const chatGrupo = await waClient.getChatById(gId);
              nombreGrupo = chatGrupo.name || gId;
            } catch (e) {}
            const gs = getGrupoStatsSemanal(gId);
            porAdminSemRes.get(adminNombre).push({ nombreGrupo, gs });
          })
        );

        let resumenSem = `📊 *RESUMEN SEMANAL — ${semanaActual()}*

`;
        let totalCSF = 0, totalClon = 0, totalErrores = 0, numG = 0;

        for (const [adminNombre, grupos] of porAdminSemRes) {
          resumenSem += `👤 *${adminNombre}*
`;
          resumenSem += `━━━━━━━━━━━━━━━━━━━━━━━━━━
`;
          for (const { nombreGrupo, gs } of grupos) {
            numG++;
            resumenSem += `  *${numG}.* ${nombreGrupo}
`;
            resumenSem += `     📄 CSF: ${gs.csf}  📋 Clon: ${gs.clon || 0}  ❌ Errores: ${gs.errores}
`;
            totalCSF += gs.csf;
            totalClon += (gs.clon || 0);
            totalErrores += gs.errores;
          }
          resumenSem += `
`;
        }

        resumenSem += `━━━━━━━━━━━━━━━━━━━━━━━━━━
`;
        resumenSem += `📄 *Total CSF:* ${totalCSF}
`;
        resumenSem += `📋 *Total Clon:* ${totalClon}
`;
        resumenSem += `❌ *Total Errores:* ${totalErrores}
`;
        resumenSem += `👥 *Grupos activos:* ${gruposAutorizados.size}`;

        // FIX: ver Bug #1 — usar waSendTexto en lugar del chat.sendMessage que no existe
        await waSendTexto(GRUPO_RESUMEN, resumenSem);
        console.log(`✅ Resumen semanal enviado a ${GRUPO_RESUMEN}`);
      }
    } catch (e) {
      console.warn(`⚠️  No se pudo enviar resumen semanal: ${e.message}`);
    }

    statsSemanalPorGrupo.clear();
    statsPorAdminSemanal.clear(); // FIX Bug #44: también resetear admins semanales
    guardarStatsSemanal();
    flushStatsSiPendiente(); // FIX Bug #33: persistir el reset inmediatamente
    programarResetStatsSemanal(); // reprogramar siguiente semana
  }, msHasta);

  const d = Math.floor(msHasta / 86400000);
  const h = Math.floor((msHasta % 86400000) / 3600000);
  console.log(`⏰ Reset stats semanal programado en ${d}d ${h}h (Domingo 11:30pm CDMX)`);
}

cargarStatsSemanal();
programarResetStatsSemanal();

// Contadores específicos por tipo (para verificación precisa de créditos CSF/CLON)
// Se declara aquí (ANTES del sistema de créditos) para que puedeDescontarCredito pueda usarlo
// Estructura: chatId → { csf: number, clon: number }
const solicitudesPorTipo = new Map();
function contarEnGrupoPorTipo(chatId, tipo) {
  const info = solicitudesPorTipo.get(chatId);
  if (!info) return 0;
  return info[tipo] || 0;
}
function incrementarGrupoPorTipo(chatId, tipo) {
  if (!solicitudesPorTipo.has(chatId)) {
    solicitudesPorTipo.set(chatId, { csf: 0, clon: 0 });
  }
  const info = solicitudesPorTipo.get(chatId);
  info[tipo] = (info[tipo] || 0) + 1;
}
function decrementarGrupoPorTipo(chatId, tipo) {
  const info = solicitudesPorTipo.get(chatId);
  if (!info) return;
  info[tipo] = Math.max(0, (info[tipo] || 0) - 1);
  if (info.csf === 0 && info.clon === 0) solicitudesPorTipo.delete(chatId);
}

// ══════════════════════════════════════════════════════════════════════════════
//  SISTEMA DE CRÉDITOS POR GRUPO (separado: CSF y CLON)
// ══════════════════════════════════════════════════════════════════════════════

// creditosPorGrupo: chatId → {
//   activo_csf: bool, creditos_csf: number, aviso10_csf: bool, aviso0_csf: bool,
//   activo_clon: bool, creditos_clon: number, aviso10_clon: bool, aviso0_clon: bool
// }
const creditosPorGrupo = new Map();

function cargarCreditos() {
  try {
    if (fs.existsSync(CONFIG.CREDITOS_FILE)) {
      const data = JSON.parse(fs.readFileSync(CONFIG.CREDITOS_FILE, "utf-8"));
      for (const [chatId, info] of Object.entries(data)) {
        // Migración automática desde formato viejo (creditos unificados)
        if (typeof info.creditos === "number" && info.creditos_csf === undefined) {
          // Migrar: los créditos existentes se asignan a CSF
          creditosPorGrupo.set(chatId, {
            activo_csf: info.activo === true,
            creditos_csf: info.creditos || 0,
            aviso10_csf: info.aviso10 === true,
            aviso0_csf: info.aviso0 === true,
            activo_clon: info.activo === true,
            creditos_clon: 0, // Empiezan en 0
            aviso10_clon: false,
            aviso0_clon: false,
          });
        } else {
          // Formato nuevo
          creditosPorGrupo.set(chatId, {
            activo_csf: info.activo_csf === true,
            creditos_csf: typeof info.creditos_csf === "number" ? info.creditos_csf : 0,
            aviso10_csf: info.aviso10_csf === true,
            aviso0_csf: info.aviso0_csf === true,
            activo_clon: info.activo_clon === true,
            creditos_clon: typeof info.creditos_clon === "number" ? info.creditos_clon : 0,
            aviso10_clon: info.aviso10_clon === true,
            aviso0_clon: info.aviso0_clon === true,
          });
        }
      }
      console.log(`💳 Créditos cargados para ${creditosPorGrupo.size} grupos`);
      guardarCreditos(); // Guardar en formato nuevo (migración)
    }
  } catch (e) {
    console.warn("⚠️  No se pudieron cargar créditos:", e.message);
  }
}

function guardarCreditos() {
  try {
    const obj = {};
    for (const [chatId, info] of creditosPorGrupo) {
      obj[chatId] = info;
    }
    fs.writeFileSync(CONFIG.CREDITOS_FILE, JSON.stringify(obj, null, 2));
  } catch (e) {
    console.warn("⚠️  No se pudieron guardar créditos:", e.message);
  }
}

function getCreditos(chatId) {
  if (!creditosPorGrupo.has(chatId)) {
    creditosPorGrupo.set(chatId, {
      activo_csf: false, creditos_csf: 0, aviso10_csf: false, aviso0_csf: false,
      activo_clon: false, creditos_clon: 0, aviso10_clon: false, aviso0_clon: false,
    });
  }
  return creditosPorGrupo.get(chatId);
}

// Verificar si un grupo puede procesar un tipo específico (csf o clon)
function puedeDescontarCredito(chatId, tipo = "csf") {
  const c = getCreditos(chatId);
  const activo = tipo === "clon" ? c.activo_clon : c.activo_csf;
  const creditos = tipo === "clon" ? c.creditos_clon : c.creditos_csf;
  if (!activo) return true; // Sistema desactivado = ilimitado
  // Restar solicitudes del MISMO tipo ya en cola (evita exceder créditos)
  const enColaTipo = contarEnGrupoPorTipo(chatId, tipo);
  return (creditos - enColaTipo) > 0;
}

// Descontar 1 crédito del tipo específico (después de éxito)
async function descontarCredito(chatId, msg, tipo = "csf") {
  const c = getCreditos(chatId);
  const activo = tipo === "clon" ? c.activo_clon : c.activo_csf;
  if (!activo) return; // No hay sistema activo

  if (tipo === "clon") {
    c.creditos_clon = Math.max(0, c.creditos_clon - 1);

    if (c.creditos_clon === 10 && !c.aviso10_clon) {
      c.aviso10_clon = true;
      try {
        await msg.reply(`⚠️ Quedan *10 créditos CLON*.\nRecarga pronto.`);
      } catch (e) {}
    }
    if (c.creditos_clon === 0 && !c.aviso0_clon) {
      c.aviso0_clon = true;
      try {
        await msg.reply(`❌ Sin créditos CLON.\nContacta a un admin para recargar.`);
      } catch (e) {}
    }
  } else {
    c.creditos_csf = Math.max(0, c.creditos_csf - 1);

    if (c.creditos_csf === 10 && !c.aviso10_csf) {
      c.aviso10_csf = true;
      try {
        await msg.reply(`⚠️ Quedan *10 créditos CSF*.\nRecarga pronto.`);
      } catch (e) {}
    }
    if (c.creditos_csf === 0 && !c.aviso0_csf) {
      c.aviso0_csf = true;
      try {
        await msg.reply(`❌ Sin créditos CSF.\nContacta a un admin para recargar.`);
      } catch (e) {}
    }
  }

  guardarCreditos();
}

// Agregar créditos del tipo especificado
function agregarCreditos(chatId, cantidad, tipo = "csf") {
  const c = getCreditos(chatId);
  if (tipo === "clon") {
    c.creditos_clon += cantidad;
    if (c.creditos_clon >= 10) c.aviso10_clon = false;
    if (c.creditos_clon > 0) c.aviso0_clon = false;
    guardarCreditos();
    return c.creditos_clon;
  } else {
    c.creditos_csf += cantidad;
    if (c.creditos_csf >= 10) c.aviso10_csf = false;
    if (c.creditos_csf > 0) c.aviso0_csf = false;
    guardarCreditos();
    return c.creditos_csf;
  }
}

// Quitar créditos del tipo especificado
function quitarCreditos(chatId, cantidad, tipo = "csf") {
  const c = getCreditos(chatId);
  if (tipo === "clon") {
    c.creditos_clon = Math.max(0, c.creditos_clon - cantidad);
    guardarCreditos();
    return c.creditos_clon;
  } else {
    c.creditos_csf = Math.max(0, c.creditos_csf - cantidad);
    guardarCreditos();
    return c.creditos_csf;
  }
}

// Activar sistema de créditos para un tipo (csf, clon, ambos)
function activarCreditos(chatId, tipo = "ambos") {
  const c = getCreditos(chatId);
  if (tipo === "csf" || tipo === "ambos") c.activo_csf = true;
  if (tipo === "clon" || tipo === "ambos") c.activo_clon = true;
  guardarCreditos();
}

// Desactivar sistema de créditos
function desactivarCreditos(chatId, tipo = "ambos") {
  const c = getCreditos(chatId);
  if (tipo === "csf" || tipo === "ambos") c.activo_csf = false;
  if (tipo === "clon" || tipo === "ambos") c.activo_clon = false;
  guardarCreditos();
}

// Cargar créditos al arranque (aquí después de que todas las variables están definidas)
cargarCreditos();


// ══════════════════════════════════════════════════════════════════════════════
//  (PERSISTENCIA DE SESIÓN VERCEL — REMOVIDA)
// ══════════════════════════════════════════════════════════════════════════════

// ══════════════════════════════════════════════════════════════════════════════
//  NAVEGADOR COMPARTIDO — Chromium reusable para CURP gob.mx y SAT directo
//  (Vercel removido — CSF se genera con generarCSFLocal.js que abre su propio Chromium)
// ══════════════════════════════════════════════════════════════════════════════

async function cerrarNavegador() {
  try {
    if (csfBrowser) await csfBrowser.close();
  } catch (e) {}
  csfBrowser   = null;
  csfContext   = null;
  csfPage      = null;
  curpPage     = null;
  curpContext  = null;
}

// Devuelve un browser de Chromium compartido (lanzado on-demand).
// Usado por consultarCURPgob() y extraerDatosSAT() — NO por la generación de CSF.
async function obtenerBrowser() {
  if (csfBrowser && csfBrowser.isConnected()) return csfBrowser;

  console.log("🌐 Iniciando navegador compartido (CURP/SAT lookup)...");
  csfBrowser = await chromium.launch({
    headless: true,
    args: [
      "--no-sandbox",
      "--disable-setuid-sandbox",
      "--disable-dev-shm-usage",
      "--disable-gpu",
      "--disable-extensions",
      "--no-default-browser-check",
    ],
    downloadsPath: CONFIG.DOWNLOAD_DIR,
  });

  csfBrowser.on("disconnected", () => {
    console.log("⚠️  Browser desconectado");
    csfBrowser  = null;
    csfContext  = null;
    csfPage     = null;
    curpPage    = null;
    curpContext = null;
  });

  return csfBrowser;
}

// ══════════════════════════════════════════════════════════════════════════════
//  GENERAR CSF — ahora delega 100% a generarCSFLocal (scrape directo SAT)
// ══════════════════════════════════════════════════════════════════════════════

async function generarCSF({ rfc, idCif, lugar = "", formato = "pdf" }) {
  generandoCSF   = true;
  generandoDesde = Date.now();

  // FIX Bug #4: timer cancelable para no acumular setTimeouts pendientes
  // cuando generarCSFLocal termina antes del timeout (caso normal).
  let timeoutHandle = null;
  const timeoutPromise = new Promise((_, reject) => {
    timeoutHandle = setTimeout(() => reject(new Error("timeout_global")), CONFIG.TIMEOUT_GENERAR);
  });

  try {
    return await Promise.race([
      generarCSFLocal({
        rfc,
        idCif,
        lugar,
        formato,
        downloadDir: CONFIG.DOWNLOAD_DIR,
      }),
      timeoutPromise,
    ]);
  } finally {
    if (timeoutHandle) clearTimeout(timeoutHandle);
    generandoCSF   = false;
    generandoDesde = null;
  }
}


// ══════════════════════════════════════════════════════════════════════════════
//  HELPERS DE PARSEO — compartidos por parsearMensaje, parsearMultiples y parsearURL
// ══════════════════════════════════════════════════════════════════════════════

// RFC: 3-4 letras (Ñ, &) + 6 dígitos + 2-3 alfanuméricos. No CURP.
function esRFCvalido(s) {
  return /^[A-ZÑ&]{3,4}\d{6}[A-Z0-9]{2,3}$/i.test(s) &&
         !/^[A-Z]{4}\d{6}[HM][A-Z]{5}[A-Z0-9]{2}$/i.test(s);
}
// idCIF: 10-15 dígitos, sin ser teléfono mexicano
function esIdCifValido(s) {
  return /^\d{10,15}$/.test(s) &&
         !/^52\d{10,11}$/.test(s) &&
         !/^[2-9]\d{9}$/.test(s);
}
// CURP: 18 chars con H/M en posición 10
function esCURPvalida(s) {
  return /^[A-Z]{4}\d{6}[HM][A-Z]{5}[A-Z0-9]\d$/i.test(s);
}
// Palabras que indican frase en lugar de topónimo
const REGEX_NO_LUGAR = /(hola|gracias|necesito|favor|buenas|tardes|dias|noches|para|que|una|esta|esto|por|los|las|del|etc|aqui|ahi|solo|hay|dia|mes|como|cuando|donde|quien|todo|nada|algo|muy|mas|menos|bien|mal|puede|quiero|tengo|dame|manda|enviame|adjunto|datos|cliente|constancia|documento|archivo|info|no\s*id|sin\s*id)/i;

function parsearMensaje(texto) {
  let rfc = null, idCif = null, lugar = "";

  // Limpiar caracteres invisibles, markdown links, tel:, URLs no-SAT
  texto = texto.replace(/\[([^\]]+)\]\([^)]+\)/g, "$1");
  texto = texto.replace(/tel:([0-9]+)/gi, "$1");
  texto = texto.replace(/[\u200B-\u200D\uFEFF\u00A0]/g, " ").trim();
  texto = texto.replace(/https?:\/\/(?!siat\.sat\.gob\.mx)\S+/g, "");

  // Usar helpers compartidos de módulo (esRFCvalido, esIdCifValido, esCURPvalida, REGEX_NO_LUGAR)
  const esRFC   = esRFCvalido;
  const esIdCif = esIdCifValido;
  const esCURP  = esCURPvalida;
  const NO_LUGAR = REGEX_NO_LUGAR;

  // ── Procesar línea por línea ──
  const lineas = texto.split(/\n/).map(l => l.trim()).filter(l => l);

  for (const linea of lineas) {
    // Tokenizar separando por todo lo que no sea alfanumérico o Ñ/& (incluye _ para idCIF_RFC)
    const tokens = linea
      .split(/[\s,|\/:=\[\](){}*+\-_]+/)
      .map(t => t.replace(/^[^A-ZÑ&0-9]*/i, "").replace(/[^A-ZÑ&0-9]*$/i, "").trim())
      .filter(t => t.length >= 10);

    let rfcLinea   = null;
    let idCifLinea = null;

    for (const token of tokens) {
      if (esCURP(token))              continue;
      if (!rfcLinea   && esRFC(token))   { rfcLinea   = token.toUpperCase(); continue; }
      if (!idCifLinea && esIdCif(token)) { idCifLinea = token;               continue; }
    }

    if (rfcLinea   && !rfc)   rfc   = rfcLinea;
    if (idCifLinea && !idCif) idCif = idCifLinea;

    // ── Lugar: texto DESPUÉS del último dato (RFC o idCIF) en la misma línea ──
    if ((rfcLinea || idCifLinea) && !lugar) {
      // Encontrar la posición del último token detectado en la línea
      const ultimoToken = idCifLinea || rfcLinea;
      const posUltimo = linea.toUpperCase().lastIndexOf(ultimoToken.toUpperCase());
      // Solo tomar lo que viene DESPUÉS del último dato
      let resto = posUltimo >= 0 ? linea.slice(posUltimo + ultimoToken.length) : "";

      // Quitar el otro dato si también aparece en el segmento (ej: idCIF primero, RFC después)
      if (rfcLinea)   resto = resto.replace(new RegExp(`\\b${rfcLinea.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}\\b`, "i"), " ");
      if (idCifLinea) resto = resto.replace(new RegExp(`\\b${idCifLinea}\\b`), " ");
      // Limpiar etiquetas, CURPs, dígitos y separadores
      // La coma se preserva ya que es parte del formato oficial del lugar (ej: "VILLAGRAN , GUANAJUATO")
      resto = resto
        .replace(/\b(idcif|id\s*cif|cif|rfc|id|nombre|curp|fecha|sexo|entidad|ciudad|municipio|colonia|estado)\b\s*[:\-]?/gi, " ")
        .replace(/\b[A-Z]{4}\d{6}[HM][A-Z]{5}[A-Z0-9]\d\b/gi, " ")
        .replace(/[\d|\/:=\[\](){}*+\-_@#$%^&!?¿¡]+/g, " ")
        .replace(/\s+/g, " ")
        .trim();

      const palabras = resto.split(/\s+/).filter(p => p.length > 1);
      if (
        resto.length >= 3 &&
        palabras.length >= 1 &&
        palabras.length <= 12 &&
        !REGEX_NO_LUGAR.test(palabras[0]) &&
        palabras.filter(p => p.length <= 2).length <= palabras.length / 2 &&
        // Rechazar si alguna palabra tiene estructura EXACTA de RFC (letras+dígitos+alfanum)
        // Usar regex más estricta: debe tener dígitos para ser RFC, no solo letras
        !palabras.some(p => /^[A-ZÑ&]{3,4}\d{2,6}[A-Z0-9]{0,3}$/.test(p))
      ) {
        lugar = resto.toUpperCase();
      }
    }

    if (rfc && idCif) break;
  }

  // ── Segunda pasada global si aún falta alguno (están en líneas separadas) ──
  if (!rfc || !idCif) {
    const todosTokens = texto
      .split(/[\s,|\/:=\[\](){}*+\-_\n]+/)
      .map(t => t.replace(/^[^A-ZÑ&0-9]*/i,"").replace(/[^A-ZÑ&0-9]*$/i,"").trim())
      .filter(t => t.length >= 10);

    for (const token of todosTokens) {
      if (esCURP(token)) continue;
      if (!rfc   && esRFC(token))   { rfc   = token.toUpperCase(); continue; }
      if (!idCif && esIdCif(token)) { idCif = token;               continue; }
      if (rfc && idCif) break;
    }
  }

  // ── Si aún no hay lugar, buscar en línea siguiente al RFC/idCIF ──
  if (rfc && idCif && !lugar) {
    const lineasAll = texto.split(/\n/).map(l => l.trim()).filter(l => l);
    // Encontrar la ÚLTIMA línea que contiene RFC o idCIF
    let idxDatos = -1;
    for (let i = 0; i < lineasAll.length; i++) {
      const lu = lineasAll[i].toUpperCase();
      if (lu.includes(rfc) || lu.includes(idCif)) idxDatos = i;
    }
    if (idxDatos >= 0 && idxDatos + 1 < lineasAll.length) {
      const sig = lineasAll[idxDatos + 1].trim();
      const sigUpper = sig.toUpperCase();
      const primerToken = sig.split(/\s/)[0];
      // Excluir CURPs, prefijos de datos conocidos (CURP:, NOMBRE:, etc.)
      const esCURPlinea = /^[A-Z]{4}\d{6}[HM][A-Z]{5}[A-Z0-9]{2}$/.test(sigUpper.replace(/[*:\s]/g, ""));
      const tienePrefijoDatos = /^(CURP|RFC|IDCIF|ID\s*CIF|NOMBRE|FECHA|SEXO|ESTADO|ENTIDAD)\s*:/i.test(sig);
      if (
        sig.length >= 3 &&
        !esRFC(primerToken) &&
        !esIdCif(primerToken) &&
        !esCURPlinea &&
        !tienePrefijoDatos
      ) {
        lugar = sigUpper;
      }
    }
  }

  return { rfc, idCif, lugar };
}

// ── Parsear URL del SAT → extraer RFC e idCIF del parámetro D3 ──
function parsearURL(texto) {
  // Descomponer link Markdown: [texto](url) → procesar URL + texto visible
  const mdMatch = texto.match(/\[([^\]]+)\]\((https?:\/\/[^)]+)\)/i);
  if (mdMatch) {
    texto = mdMatch[2] + " " + mdMatch[1];
  }

  // ── Patrón 1: URL del SAT con D3=idCIF_RFC ──
  const urlMatch = texto.match(/https?:\/\/siat\.sat\.gob\.mx\S+/i);
  if (urlMatch) {
    try {
      const urlLimpia = urlMatch[0].replace(/[)\]]+$/, "");
      const url = new URL(urlLimpia);
      const d3 = url.searchParams.get("D3");
      if (d3) {
        const partes = d3.split("_");
        if (partes.length >= 2) {
          const idCif = partes[0]?.trim();
          const rfc   = partes.slice(1).join("_").replace(/[^A-Z0-9]/gi,"").trim().toUpperCase();
          if (rfc && idCif && rfc.length >= 10 && idCif.length >= 5) {
            return { rfc, idCif, lugar: "" };
          }
        }
      }
    } catch (e) {}
  }

  // ── Patrón 2: idCIF_RFC suelto (ej: 15110486146_PERA920529835) ──
  const d3Match = texto.match(/(\d{5,15})_([A-ZÑ&]{3,4}\d{6}[A-Z0-9]{2,3})/i);
  if (d3Match) {
    const idCif = d3Match[1].trim();
    const rfc   = d3Match[2].replace(/[^A-Z0-9]/gi, "").trim().toUpperCase();
    if (!/^[A-Z]{4}\d{6}[HM][A-Z]{5}[A-Z0-9]{2}$/i.test(rfc) && rfc.length >= 10) {
      return { rfc, idCif, lugar: "" };
    }
  }

  return null;
}

// ── Parsear múltiples RFC + idCIF en un solo mensaje ──
// Detecta pares de CURP+RFC+idCIF o RFC+idCIF en líneas/bloques
function parsearMultiples(texto) {
  const resultados = [];

  // Limpiar caracteres invisibles y URLs no-SAT
  texto = texto.replace(/[\u200B-\u200D\uFEFF\u00A0]/g, " ").trim();
  texto = texto.replace(/https?:\/\/(?!siat\.sat\.gob\.mx)\S+/g, "");
  // Quitar links Markdown dejando solo el texto visible: [texto](url) → texto
  texto = texto.replace(/\[([^\]]+)\]\([^)]+\)/g, "$1");

  // Usar helpers compartidos de módulo
  const esRFC   = esRFCvalido;
  const esIdCif = esIdCifValido;
  const esCURP  = esCURPvalida;
  const NO_LUGAR = REGEX_NO_LUGAR;

  const extraerLugar = () => ""; // En lote no se acepta lugar de emisión

  // ── Procesar cada línea ──
  const lineas = texto.split(/\n/).map(l => l.trim()).filter(l => l);
  const elementos = []; // buffer para pares en líneas separadas

  for (const linea of lineas) {
    if (NO_LUGAR.test(linea) && !esRFC(linea.split(/\s+/)[0]) && !/\d{10,15}/.test(linea)) continue;

    // Tokenizar por separadores (igual que parsearMensaje)
    const tokens = linea
      .split(/[\s,|\/\\:=\[\](){}*+\-_]+/)
      .map(t => t.replace(/^[^A-ZÑ&0-9]*/i,"").replace(/[^A-ZÑ&0-9]*$/i,"").trim())
      .filter(t => t.length >= 10);

    let rfcLinea   = null;
    let idCifLinea = null;

    for (const token of tokens) {
      if (esCURP(token)) continue;
      if (!rfcLinea   && esRFC(token))   { rfcLinea   = token.toUpperCase(); continue; }
      if (!idCifLinea && esIdCif(token)) { idCifLinea = token;               continue; }
    }

    if (rfcLinea && idCifLinea) {
      resultados.push({ rfc: rfcLinea, idCif: idCifLinea, lugar: "" });
    } else if (rfcLinea) {
      elementos.push({ tipo: "rfc", valor: rfcLinea, linea });
    } else if (idCifLinea) {
      elementos.push({ tipo: "idcif", valor: idCifLinea, lugar: "", linea });
    }
  }

  // ── Emparejar elementos de líneas separadas (RFC↔idCIF consecutivos) ──
  for (let i = 0; i < elementos.length; i++) {
    const actual   = elementos[i];
    const siguiente = elementos[i + 1];
    if (!siguiente) continue;

    if (actual.tipo === "rfc" && siguiente.tipo === "idcif") {
      resultados.push({ rfc: actual.valor, idCif: siguiente.valor, lugar: "" });
      i++;
    } else if (actual.tipo === "idcif" && siguiente.tipo === "rfc") {
      resultados.push({ rfc: siguiente.valor, idCif: actual.valor, lugar: "" });
      i++;
    }
  }

  return resultados.length > 1 ? resultados : null;
}

let apagando = false;

async function apagadoLimpio() {
  if (apagando) return;
  apagando = true;
  apagandoWA = true;
  console.log("\n🛑 Apagando bot...");

  // FIX Bug #10: si hay una tarea en proceso, esperar hasta 7s a que termine
  // antes de cerrar (el kill_timeout de PM2 está en 8s, dejamos 1s de margen).
  // Esto evita perder solicitudes ya facturadas/respondidas.
  if (procesando || generandoCSF) {
    const tEsperaMax = Date.now() + 7000;
    console.log("⏳ Esperando a que termine la tarea actual (max 7s)...");
    while ((procesando || generandoCSF) && Date.now() < tEsperaMax) {
      await esperar(200);
    }
    if (procesando || generandoCSF) {
      console.warn("⚠️  La tarea no terminó a tiempo, forzando apagado.");
    } else {
      console.log("✅ Tarea completada antes del apagado.");
    }
  }

  // FIX Bug #33: persistir stats pendientes antes de cerrar
  try { flushStatsSiPendiente(); } catch (e) {}

  try {
    if (sock) { sock.end(); sock.ev.removeAllListeners(); }
    console.log("✅ WhatsApp cerrado.");
  } catch (e) { console.warn("⚠️  Error cerrando WhatsApp:", e.message); }
  await cerrarNavegador();
  await cerrarBrowserSAT();
  process.exit(0);
}

process.on("SIGTERM", apagadoLimpio);
// FIX: SIGINT también ahora hace apagado limpio. PM2 usa SIGTERM principalmente
// pero en reload con cluster puede enviar SIGINT. Antes lo ignorábamos y se
// perdían stats pendientes.
process.on("SIGINT", apagadoLimpio);
// FIX: uncaughtException antes solo logueaba, dejando el proceso en estado
// posiblemente corrupto. Ahora persiste stats y sale con código 1 para que
// PM2 lo reinicie limpiamente.
process.on("uncaughtException", (err) => {
  console.error("❌ Error no capturado:", err.message, "\n", err.stack);
  try { flushStatsSiPendiente(); } catch (e) {}
  setTimeout(() => process.exit(1), 500);
});
process.on("unhandledRejection", (reason) => {
  console.error("❌ Promesa rechazada:", reason?.message || reason, "\n", reason?.stack || "");
  // No matamos el proceso aquí porque las promesas rechazadas suelen ser de
  // operaciones que se pueden recuperar (timeouts de red, etc). Solo loggeamos.
});

// ══════════════════════════════════════════════════════════════════════════════
//  WHATSAPP — Baileys (WebSocket directo, sin Chromium)
// ══════════════════════════════════════════════════════════════════════════════

let sock = null;
let waReady = false;
let setupReadyHecho = false;
let apagandoWA = false;
let reconexionIntento = 0;          // backoff exponencial
let ultimoMensajeRecibido = Date.now(); // heartbeat watchdog

// FIX Bug #48: tracking de salud de Baileys para comando =salud
let waConectadoDesde = null;        // timestamp de la última conexión exitosa
let waTotalReconexiones = 0;        // contador acumulado desde el arranque
let waUltimasReconexiones = [];     // array de timestamps de las últimas 50 reconexiones
let waUltimoEnvioExitoso = null;    // timestamp del último msg enviado correctamente
let waEnvioFallidos = 0;            // contador acumulado de envíos fallidos
let waEnviosRetried = 0;            // contador de envíos que necesitaron reintentos

// ── Helpers de JID ──
const jidGrupo    = (jid) => jid?.endsWith("@g.us");
const jidNumero   = (jid) => (jid || "").replace(/@.+/, "").replace(/:\d+$/, "");

// ── Cache de mensajes enviados para getMessage (retry de Baileys) ──────────
// Cuando WhatsApp pide reenvío de un mensaje (común en grupos), Baileys
// llama a getMessage(). Si devuelve null repetidamente, el server cierra
// la sesión por "invalid behavior". Mantenemos los últimos 200 mensajes.
const msgRetryCache = new Map();
const MSG_RETRY_CACHE_MAX = 200;

function cachearMensajeEnviado(key, msg) {
  if (!key?.id) return;
  msgRetryCache.set(key.id, msg);
  if (msgRetryCache.size > MSG_RETRY_CACHE_MAX) {
    const firstKey = msgRetryCache.keys().next().value;
    msgRetryCache.delete(firstKey);
  }
}

// ── Cola de envío anti rate-limit ──────────────────────────────────────────
const envioQueue = [];
let enviandoWA = false;

async function procesarEnvioQueue() {
  if (enviandoWA || envioQueue.length === 0) return;
  if (!sock || !waReady) {
    // FIX Bug #29: si WA no está listo, reintentar más tarde sin bloquear la promesa.
    // Antes: el setTimeout reagenda procesarEnvioQueue, pero las promesas en cola
    // nunca resuelven hasta que WA conecte. Ahora: si tras varios intentos sigue
    // sin conectar, rechazamos los mensajes encolados para liberar callers.
    if (!envioQueue[0]._retries) envioQueue[0]._retries = 0;
    envioQueue[0]._retries++;
    if (envioQueue[0]._retries > 30) {
      // 30 reintentos × 2s = 60s sin conexión → rechazar para liberar caller
      const stale = envioQueue.shift();
      stale.reject(new Error("WhatsApp no disponible tras 60s"));
      console.warn(`⚠️  Mensaje WA descartado tras 60s sin conexión: ${stale.jid}`);
      // Procesar siguiente
      setImmediate(procesarEnvioQueue);
      return;
    }
    setTimeout(procesarEnvioQueue, 2000);
    return;
  }
  enviandoWA = true;
  const { jid, payload, opts, resolve, reject } = envioQueue.shift();
  // FIX Bug #47: reintentar envío si falla por error transitorio (red, rate-limit,
  // socket cerrado). Antes: un solo intento → si fallaba, el cliente NO recibía
  // su PDF/mensaje. Ahora: hasta 3 intentos con pausa entre ellos (500ms y 1.5s).
  // Solo reintenta errores transitorios (no errores de payload o jid inválido).
  const MAX_REINTENTOS_ENVIO = 3;
  let intentoEnvio = 0;
  let ultimoError = null;
  while (intentoEnvio < MAX_REINTENTOS_ENVIO) {
    intentoEnvio++;
    try {
      // FIX: timeout 30s para sendMessage. Antes sin timeout, si Baileys se
      // colgaba en un envío, TODA la cola de envío se bloqueaba indefinidamente
      // hasta que el watchdog detectara silencio de 5min.
      const result = await Promise.race([
        sock.sendMessage(jid, payload, opts),
        new Promise((_, rej) => setTimeout(() => rej(new Error("send_timeout_30s")), 30000)),
      ]);
      resolve(result);
      ultimoError = null;
      // Cachear para que getMessage pueda responder retries de WhatsApp
      if (result?.key) cachearMensajeEnviado(result.key, payload);
      // FIX Bug #48: trackear éxito de envío
      waUltimoEnvioExitoso = Date.now();
      if (intentoEnvio > 1) waEnviosRetried++;
      break;
    } catch (e) {
      ultimoError = e;
      const msg = e.message || "";
      // Errores NO transitorios (no tiene sentido reintentar)
      const esErrorPermanente = /jid|payload|invalid|not.*valid|forbidden|unauthorized/i.test(msg);
      if (esErrorPermanente || intentoEnvio >= MAX_REINTENTOS_ENVIO) break;
      // Esperar antes del reintento: 500ms tras el 1er fallo, 1.5s tras el 2do
      const espera = intentoEnvio === 1 ? 500 : 1500;
      console.warn(`⚠️  Envío falló (intento ${intentoEnvio}/${MAX_REINTENTOS_ENVIO}): ${msg.substring(0, 80)} — reintentando en ${espera}ms`);
      await new Promise(r => setTimeout(r, espera));
    }
  }
  if (ultimoError) {
    waEnvioFallidos++; // FIX Bug #48: trackear fallo de envío
    reject(ultimoError);
  }
  enviandoWA = false;
  if (envioQueue.length > 0) setTimeout(procesarEnvioQueue, 500);
}

function encolarEnvio(jid, payload, opts = {}) {
  return new Promise((resolve, reject) => {
    // FIX Bug #49: si opts.prioridad === true, va al FRENTE de la cola.
    // Usado por comandos admin (=salud, =grupos, =estatus, etc.) para que se
    // envíen rápidamente aunque haya muchos PDFs en cola por delante.
    const item = { jid, payload, opts, resolve, reject };
    if (opts.prioridad) {
      envioQueue.unshift(item);
    } else {
      envioQueue.push(item);
    }
    procesarEnvioQueue();
  });
}

// ── Enviar texto (reply o mensaje nuevo) ──
async function waSendTexto(jid, texto, quoted, prioridad = false) {
  if (!waReady || !sock) return;
  try {
    const opts = { ...(quoted && { quoted }), ...(prioridad && { prioridad: true }) };
    await encolarEnvio(jid, { text: texto }, opts);
  } catch (e) { console.error("❌ waSendTexto:", e.message); }
}

// ── Enviar archivo ──
async function waSendArchivo(jid, buffer, fileName, mimeType, caption, quoted) {
  if (!waReady || !sock) return;
  try {
    const opts = quoted ? { quoted } : {};
    await encolarEnvio(jid, { document: buffer, fileName, mimetype: mimeType, caption }, opts);
  } catch (e) { console.error("❌ waSendArchivo:", e.message); }
}

// ── Clase MessageMedia compatible ──
function crearMessageMedia(mimeType, base64Data, fileName) {
  return { _isBaileysMedia: true, mimeType, fileName, buffer: Buffer.from(base64Data, "base64") };
}
const MessageMedia = crearMessageMedia; // alias global

// ── Wrapper msg compatible con código existente ──
function wrapMsg(rawMsg, jid, chatMeta) {
  const bodyText =
    rawMsg.message?.conversation ||
    rawMsg.message?.extendedTextMessage?.text ||
    rawMsg.message?.imageMessage?.caption ||
    rawMsg.message?.documentMessage?.caption || "";

  const tipoMsg = rawMsg.message?.imageMessage    ? "image"    :
                  rawMsg.message?.documentMessage ? "document" :
                  rawMsg.message?.audioMessage    ? "audio"    :
                  rawMsg.message?.videoMessage    ? "video"    : "chat";

  const hasMedia = !!(rawMsg.message?.imageMessage || rawMsg.message?.documentMessage ||
                      rawMsg.message?.audioMessage || rawMsg.message?.videoMessage);

  return {
    // Propiedades compatibles
    from:       jid,
    author:     rawMsg.key.participant || rawMsg.key.remoteJid,
    body:       bodyText,
    type:       tipoMsg,
    hasMedia,
    notifyName: rawMsg.pushName || null,  // nombre del contacto (Baileys lo provee aquí)
    id:         { id: rawMsg.key.id, _serialized: rawMsg.key.id },
    _raw:       rawMsg,

    // msg.reply(texto) o msg.reply(mediaObj, null, {caption})
    reply: async (contenido, _jid2, opts) => {
      if (!contenido) return;
      // FIX Bug #49: si el mensaje original es un comando admin (=algo) enviado
      // por un admin, mandar la respuesta con prioridad para que no espere detrás
      // de PDFs/mensajes en la cola de envío.
      const bodyOriginal = (bodyText || "").trim();
      const esRespuestaAComandoAdmin = bodyOriginal.startsWith("=") &&
        CONFIG.ADMINS.includes(rawMsg.key.participant || rawMsg.key.remoteJid);
      if (typeof contenido === "string") {
        await waSendTexto(jid, contenido, rawMsg, esRespuestaAComandoAdmin);
      } else if (contenido?._isBaileysMedia) {
        await waSendArchivo(jid, contenido.buffer, contenido.fileName,
                            contenido.mimeType, opts?.caption || "", rawMsg);
      }
    },

    // msg.getChat()
    getChat: async () => ({
      isGroup: jidGrupo(jid),
      name: chatMeta?.subject || jidNumero(jid),
      id: { _serialized: jid },
    }),

    // msg.downloadMedia()
    downloadMedia: async () => {
      const MAX_INTENTOS_DL = 3;
      const TIMEOUT_DL_MS = 20000;
      for (let intento = 1; intento <= MAX_INTENTOS_DL; intento++) {
        try {
          // Timeout de 20s por intento. Si el server de WhatsApp se cuelga
          // descargando un media corrupto, antes podía colgarse indefinidamente.
          const buf = await Promise.race([
            downloadMediaMessage(
              rawMsg, "buffer", {},
              { reuploadRequest: sock.updateMediaMessage }
            ),
            new Promise((_, rej) => setTimeout(() => rej(new Error(`timeout_${TIMEOUT_DL_MS}ms`)), TIMEOUT_DL_MS)),
          ]);
          const mtype = rawMsg.message?.imageMessage?.mimetype || "image/jpeg";
          return { data: buf.toString("base64"), mimetype: mtype };
        } catch (e) {
          if (intento < MAX_INTENTOS_DL) {
            console.warn(`⚠️  downloadMedia intento ${intento}/${MAX_INTENTOS_DL}: ${e.message} — reintentando...`);
            await esperar(1000 * intento);
          } else {
            console.error(`❌ downloadMedia falló tras ${MAX_INTENTOS_DL} intentos:`, e.message);
            return null;
          }
        }
      }
    },
  };
}

// ── getChatById para comandos admin (con timeout 3s) ──
async function getChatById(jid) {
  try {
    if (jidGrupo(jid)) {
      const meta = await Promise.race([
        sock.groupMetadata(jid),
        new Promise((_, rej) => setTimeout(() => rej(new Error("timeout")), 3000))
      ]).catch(() => ({ subject: jid }));
      return { name: meta.subject || jid, id: { _serialized: jid }, isGroup: true };
    }
    return { name: jidNumero(jid), id: { _serialized: jid }, isGroup: false };
  } catch (e) {
    return { name: jid, id: { _serialized: jid }, isGroup: true };
  }
}

// ── Helper: resolver nombres de grupos en lotes (evita rate-limit) ──
async function resolverNombresGrupos(entries, resolverAdmin) {
  const porAdmin = new Map();
  // Procesar de a 4 en paralelo con delay entre lotes
  for (let i = 0; i < entries.length; i += 4) {
    const lote = entries.slice(i, i + 4);
    await Promise.all(lote.map(async ([gId, adminId]) => {
      const adminNombre = resolverAdmin(adminId);
      if (!porAdmin.has(adminNombre)) porAdmin.set(adminNombre, []);
      let nombreGrupo = gId;
      try {
        const chatGrupo = await waClient.getChatById(gId);
        nombreGrupo = chatGrupo.name || gId;
      } catch (e) {}
      porAdmin.get(adminNombre).push({ gId, nombreGrupo });
    }));
    if (i + 4 < entries.length) await new Promise(r => setTimeout(r, 200));
  }
  return porAdmin;
}

// Alias waClient para compatibilidad con comandos admin
const waClient = {
  getChatById,
  sendMessage: (jid, texto) => waSendTexto(jid, texto),
};

// ── Arrancar sistemas después de conectar (solo una vez) ──
function iniciarSistemasPostConexion() {
  if (setupReadyHecho) {
    console.log("ℹ️  Reconexión — sistemas ya iniciados.");
    return;
  }
  setupReadyHecho = true;

  console.log(`🐕 Watchdog cada ${CONFIG.WATCHDOG_MINUTOS} min\n`);

  // Watchdog de cola
  setInterval(() => {
    if (!procesando && cola.length > 0) { console.log("🐕 Watchdog: cola trabada, reactivando..."); procesarCola(); }
    if (generandoCSF && generandoDesde && (Date.now() - generandoDesde) > CONFIG.TIMEOUT_GENERAR + 30000) {
      console.warn("🐕 Watchdog: generandoCSF timeout, reseteando..."); generandoCSF = false; generandoDesde = null;
    }
  }, CONFIG.WATCHDOG_MINUTOS * 60 * 1000).unref?.();

  // Watchdog heartbeat Baileys — detecta desconexiones silenciosas
  setInterval(async () => {
    if (apagandoWA || !sock || !waReady) return;
    const silencioMs = Date.now() - ultimoMensajeRecibido;
    if (silencioMs < 5 * 60 * 1000) return;
    try {
      await Promise.race([
        sock.sendPresenceUpdate("unavailable"),
        new Promise((_, rej) => setTimeout(() => rej(new Error("heartbeat timeout")), 10000))
      ]);
      console.log(`💓 WA heartbeat OK (silencio ${Math.round(silencioMs/60000)}min)`);
    } catch (e) {
      console.warn(`🐕 WA heartbeat FALLÓ (silencio ${Math.round(silencioMs/60000)}min): ${e.message} — reconectando...`);
      waReady = false;
      try { sock.end(undefined); } catch (_) {}
      sock = null;
      setTimeout(() => conectarWhatsApp(), 2000);
    }
  }, 3 * 60 * 1000).unref?.();

  // Keepalive gob.mx/curp
  setInterval(async () => {
    try {
      if (!curpPage || curpPage.isClosed() || curpOcupado) return;
      const url = curpPage.url();
      if (!url.includes("gob.mx/curp")) {
        await curpPage.goto("https://www.gob.mx/curp/", { waitUntil: "domcontentloaded", timeout: 30000 });
        return;
      }
      await curpPage.evaluate(async () => {
        try { await fetch("https://www.gob.mx/curp/", { method: "HEAD", credentials: "include", cache: "no-store" }); } catch(e){}
      });
    } catch (e) {}
  }, 60000).unref?.();

  // Pre-cargar gob.mx/curp en background (abre browser on-demand)
  // FIX Bug #3: guardar la promesa de inicialización para que consultarCURPgob
  // pueda esperarla en lugar de crear su propio context y dejar uno huérfano.
  curpInitPromise = (async () => {
    try {
      const browser = await obtenerBrowser();
      const ctx = await browser.newContext({ viewport: { width: 1024, height: 768 }, locale: "es-MX" });
      curpContext = ctx;
      curpPage = await ctx.newPage();
      curpPage.on("dialog", async d => { try { await d.dismiss(); } catch(e){} });
      await curpPage.goto("https://www.gob.mx/curp/", { waitUntil: "load", timeout: 60000 });
      await curpPage.waitForFunction(() => {
        const inputs = document.querySelectorAll("input");
        for (const inp of inputs) { const r = inp.getBoundingClientRect(); if (r.width > 0 && r.height > 0) return true; }
        return false;
      }, { timeout: 40000 });
      console.log("🌐 gob.mx/curp pre-cargado");
    } catch (e) { console.warn("⚠️  Pre-carga gob.mx/curp falló:", e.message); }
  })();

  // ── Pre-cargar gob.mx/curp en background — el warmup de OnlyOffice se eliminó
  // porque OnlyOffice no cachea el worker LibreOffice entre requests; el warmup
  // gastaba 1 conversión innecesaria al arranque sin ningún beneficio medible.
}

// ── Función principal de conexión Baileys ──
async function conectarWhatsApp() {
  if (apagandoWA) return;

  // Cerrar socket anterior limpiamente
  if (sock) { try { sock.end(undefined); } catch (e) {} sock = null; }

  // Garantizar que la carpeta de credenciales existe
  if (!fs.existsSync("auth_wa_baileys")) {
    fs.mkdirSync("auth_wa_baileys", { recursive: true });
    console.log("📁 Carpeta auth_wa_baileys recreada.");
  }

  const { state, saveCreds } = await useMultiFileAuthState("auth_wa_baileys");

  // fetchLatestBaileysVersion con timeout y fallback
  let version;
  try {
    const res = await Promise.race([
      fetchLatestBaileysVersion(),
      new Promise((_, rej) => setTimeout(() => rej(new Error("timeout")), 15000)),
    ]);
    version = res.version;
  } catch (e) {
    console.warn("⚠️  No se pudo obtener versión WA, usando fallback:", e.message);
    // Fallback actualizable — verificar la versión activa en web.whatsapp.com:
    // DevTools → Application → Local Storage → WA-VERSION
    version = [2, 3000, 1023223821];
  }
  console.log(`📱 WhatsApp Web v${version.join(".")}`);

  const P = require("pino");
  // "error" en vez de "fatal" — vemos warnings reales (decrypt fails, LID, retry exhausted)
  const logger = P({ level: "error" });

  sock = makeWASocket({
    version,
    auth: state,
    printQRInTerminal: false,
    logger,
    // Identificador estándar de la lista de Baileys (strings custom suelen
    // ser rechazados por el anti-fraude de WhatsApp).
    browser: ["Ubuntu", "Chrome", "120.0.0"],

    // ── Timings ──
    connectTimeoutMs:        60000,
    defaultQueryTimeoutMs:   60000,   // ↑ 30s → 60s (groupMetadata grupos grandes)
    keepAliveIntervalMs:     30000,   // ↑ 25s → 30s (alineado con WhatsApp)
    retryRequestDelayMs:     2000,
    maxMsgRetryCount:        5,       // ↑ 3 → 5 (menos kicks por retry exhausted)

    // ── Comportamiento ──
    generateHighQualityLinkPreview: false,
    syncFullHistory:                false,
    markOnlineOnConnect:            false,
    fireInitQueries:                true,
    emitOwnEvents:                  false,

    // ── CRÍTICO: getMessage para retry de Baileys ──
    // Devolver { conversation: "" } en lugar de null cuando no tenemos el
    // mensaje cacheado: WhatsApp acepta esto como "retry completado sin
    // contenido" y no nos cierra la sesión.
    getMessage: async (key) => {
      const cached = msgRetryCache.get(key.id);
      if (cached) return cached;
      return { conversation: "" };
    },

    // ── Descartar JIDs irrelevantes (reduce carga del socket) ──
    shouldIgnoreJid: (jid) => /(@broadcast|@newsletter)$/.test(jid),

    // ── No procesar historial al reconectar ──
    shouldSyncHistoryMessage: () => false,
  });

  // Guardar credenciales
  sock.ev.on("creds.update", saveCreds);

  // Estado de conexión
  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr) {
      console.log("\n📱 Escanea este QR con WhatsApp Business:\n");
      qrcode.generate(qr, { small: true });
    }

    if (connection === "connecting") {
      console.log("🔐 WhatsApp conectando...");

    } else if (connection === "open") {
      waReady = true;
      // NO resetear reconexionIntento aquí — lo reseteamos en messages.upsert
      // cuando llegue el primer mensaje real. "open" sin tráfico real puede
      // ser una conexión zombie que cae en segundos.
      ultimoMensajeRecibido = Date.now();
      // FIX Bug #48: registrar reconexión para stats de salud
      if (waConectadoDesde !== null) {
        waTotalReconexiones++;
        waUltimasReconexiones.push(Date.now());
        if (waUltimasReconexiones.length > 50) waUltimasReconexiones.shift();
      }
      waConectadoDesde = Date.now();
      console.log("✅ WhatsApp conectado\n");
      iniciarSistemasPostConexion();

    } else if (connection === "close") {
      waReady = false;
      const statusCode = lastDisconnect?.error instanceof Boom
        ? lastDisconnect.error.output?.statusCode : null;
      const razon = Object.keys(DisconnectReason).find(k => DisconnectReason[k] === statusCode) || statusCode || "desconocida";
      console.warn(`⚠️  WhatsApp desconectado: ${razon} (${statusCode})`);

      // Sesión revocada por WhatsApp — borrar credenciales y reiniciar
      if (statusCode === DisconnectReason.loggedOut || statusCode === DisconnectReason.forbidden) {
        console.error("💀 Sesión revocada. Borrando credenciales y reiniciando...");
        // FIX: persistir stats pendientes antes de matar el proceso (antes se perdían)
        try { flushStatsSiPendiente(); } catch (e) {}
        try { fs.rmSync("auth_wa_baileys", { recursive: true, force: true }); } catch(e){}
        setTimeout(() => process.exit(1), 2000);
        return;
      }

      // Sesión corrupta — borrar credenciales (forzará re-escaneo QR al reiniciar)
      if (statusCode === DisconnectReason.badSession ||
          statusCode === DisconnectReason.multideviceMismatch) {
        console.error("💀 Sesión corrupta. Borrando credenciales...");
        // FIX: persistir stats pendientes antes de matar el proceso
        try { flushStatsSiPendiente(); } catch (e) {}
        try { fs.rmSync("auth_wa_baileys", { recursive: true, force: true }); } catch(e){}
        setTimeout(() => process.exit(1), 2000);
        return;
      }

      if (!apagandoWA) {
        reconexionIntento++;
        let delayBase;
        // Errores transitorios (keep-alive de WhatsApp) → reconectar rápido
        if (statusCode === DisconnectReason.connectionClosed ||      // 428
            statusCode === DisconnectReason.connectionLost ||        // 408
            statusCode === DisconnectReason.timedOut) {
          delayBase = 1000; // 1s (antes 500ms — demasiado agresivo)
        } else if (statusCode === DisconnectReason.restartRequired) { // 515
          delayBase = 1500;
        } else {
          delayBase = 3000;
        }
        // Cap del exponente para que no crezca infinito si nunca conecta
        const exp = Math.min(reconexionIntento - 1, 5);
        const delay = Math.min(delayBase * Math.pow(2, exp), 30000);
        console.log(`🔄 Reconectando en ${(delay/1000).toFixed(1)}s (intento #${reconexionIntento})...`);
        setTimeout(() => conectarWhatsApp(), delay);
      }
    }
  });

  // Mensajes entrantes
  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;
    ultimoMensajeRecibido = Date.now();
    // Reset del contador al primer mensaje real tras reconexión.
    // Antes se reseteaba en connection==="open", pero "open" sin tráfico
    // a veces es una conexión zombie. Esto garantiza que solo reseteamos
    // cuando la conexión efectivamente funciona.
    if (reconexionIntento > 0 && waReady) reconexionIntento = 0;

    // FIX: cache local de groupMetadata por batch. Si en un mismo batch
    // llegan N mensajes del mismo grupo, antes hacíamos N llamadas idénticas
    // a groupMetadata (red + parsing). Con cache por batch hacemos 1 sola.
    const metaCache = new Map();
    const getMetaCached = async (jid) => {
      if (metaCache.has(jid)) return metaCache.get(jid);
      let meta = { subject: jid };
      for (let i = 1; i <= 3; i++) {
        try { meta = await sock.groupMetadata(jid); break; }
        catch (e) { if (i < 3) await esperar(500 * i); }
      }
      metaCache.set(jid, meta);
      return meta;
    };

    // Detectar múltiples imágenes del mismo usuario en el mismo batch
    const imagenesGrupo = messages.filter(m =>
      !m.key.fromMe && m.message?.imageMessage && jidGrupo(m.key.remoteJid)
    );
    if (imagenesGrupo.length > 1) {
      const porAutor = new Map();
      for (const m of imagenesGrupo) {
        const key = `${m.key.remoteJid}|${m.key.participant || m.key.remoteJid}`;
        if (!porAutor.has(key)) porAutor.set(key, { jid: m.key.remoteJid, rawMsg: m, count: 0 });
        porAutor.get(key).count++;
      }
      for (const { jid, rawMsg, count } of porAutor.values()) {
        if (count > 1) {
          const chatMeta = await getMetaCached(jid);
          const msgTemp = wrapMsg(rawMsg, jid, chatMeta);
          const senderTemp = msgTemp.notifyName || "cliente";
          await waSendTexto(jid, `📋 *${senderTemp}*, se detectaron *${count}* imágenes.\n⏳ Se procesarán una por una...`, rawMsg);
        }
      }
    }

    await Promise.allSettled(messages.map(async (rawMsg) => {
      try {
        if (rawMsg.key.fromMe) return;
        if (!rawMsg.message) return;
        const jid = rawMsg.key.remoteJid;
        if (!jidGrupo(jid)) return;

        // Usar cache compartido del batch (evita N llamadas redundantes)
        const chatMeta = await getMetaCached(jid);

        const msg = wrapMsg(rawMsg, jid, chatMeta);
        await manejarMensaje(msg);
      } catch (e) {
        console.error("❌ Error procesando mensaje:", e.message);
      }
    }));
  });
}

// Iniciar
conectarWhatsApp().catch(console.error);

// ── Cola ──────────────────────────────────────────────────────────────────────
let procesando = false;
const cola = [];

// Contador de solicitudes activas por grupo (en cola + procesándose)
const solicitudesPorGrupo = new Map();
function contarEnGrupo(chatId) {
  return solicitudesPorGrupo.get(chatId) || 0;
}
function incrementarGrupo(chatId) {
  solicitudesPorGrupo.set(chatId, contarEnGrupo(chatId) + 1);
}
function decrementarGrupo(chatId) {
  const n = contarEnGrupo(chatId) - 1;
  if (n <= 0) solicitudesPorGrupo.delete(chatId);
  else solicitudesPorGrupo.set(chatId, n);
}

const recientes = new Map();
const ANTI_DUP_MS = 30000;

// Limpieza periódica del Map de anti-duplicados (por si el bot está inactivo horas)
setInterval(() => {
  const ahora = Date.now();
  for (const [k, t] of recientes) {
    if (ahora - t > ANTI_DUP_MS) recientes.delete(k);
  }
}, 5 * 60 * 1000).unref?.();

let tiempoPromedioMs = 10000;

// FIX: actualizar el promedio de tiempo de procesamiento con EMA (Exponential
// Moving Average). Antes el valor era fijo 10s, lo que sobreestimaba ~6x el
// tiempo real (~1.7s por tarea) y daba estimaciones de cola engañosas.
// alpha=0.3 → reacciona razonablemente rápido a cambios sin ser nervioso.
function actualizarPromedio(msTarea) {
  if (!msTarea || msTarea < 100 || msTarea > 120000) return; // ignora outliers
  tiempoPromedioMs = Math.round(tiempoPromedioMs * 0.7 + msTarea * 0.3);
}

// ── Obtener nombre del remitente de forma robusta ──
async function obtenerNombre(msg) {
  if (msg.notifyName) return msg.notifyName;
  try {
    const contact = await msg.getContact();
    return contact.pushname || contact.name || contact.shortName || "cliente";
  } catch (e) {
    return "cliente";
  }
}

function esDuplicado(rfc, idCif) {
  const clave = `${rfc}_${idCif}`;
  const ahora = Date.now();

  // Limpiar entradas viejas primero
  for (const [k, t] of recientes) {
    if (ahora - t > ANTI_DUP_MS) recientes.delete(k);
  }

  if (recientes.has(clave)) return true;

  // Registrar como en proceso
  recientes.set(clave, ahora);
  return false;
}

// Liberar un duplicado registrado (usar cuando la tarea falla para permitir reintento)
function liberarDuplicado(rfc, idCif) {
  const clave = `${rfc}_${idCif}`;
  recientes.delete(clave);
}

function tiempoEspera(posicion) {
  const segs = Math.round((posicion * tiempoPromedioMs) / 1000);
  if (segs < 60) return `~${segs} seg`;
  return `~${Math.ceil(segs / 60)} min`;
}

async function procesarCola() {
  if (procesando || cola.length === 0) return;
  procesando = true;

  const tarea = cola.shift();
  if (cola.length > 0) console.log(`📋 Quedan ${cola.length} solicitud(es) en cola.`);

  const tInicio = Date.now();
  try {
    await tarea.fn();
  } catch (err) {
    console.error("❌ Error inesperado en tarea:", err.message);
  } finally {
    // FIX: actualizar promedio para mejores estimaciones de espera
    actualizarPromedio(Date.now() - tInicio);
    if (tarea.chatId) {
      decrementarGrupo(tarea.chatId);
      if (tarea.tipo) decrementarGrupoPorTipo(tarea.chatId, tarea.tipo);
    }
    // Nota: generandoCSF se resetea dentro de generarCSF() — no duplicar aquí
    await esperar(CONFIG.PAUSA_ENTRE_TAREAS);
    procesando = false;
    setImmediate(() => procesarCola());
  }
}

// ══════════════════════════════════════════════════════════════════════════════
//  HELPER: Intentar generar y enviar CSF (elimina código duplicado)
// ══════════════════════════════════════════════════════════════════════════════

async function intentarGenerarYEnviar({ msg, rfc, idCif, lugar, sender, tiempoInicio, formato = "pdf" }) {
  if (!tiempoInicio) tiempoInicio = Date.now();
  const chat = await msg.getChat();
  const chatId = chat.id._serialized;
  let pdfPath = null;

  try {
    pdfPath = await generarCSF({ rfc, idCif, lugar, formato });
  } catch (err) {
    const tipoError = err.message === "datos_invalidos" ? "DATOS_INVÁLIDOS" :
                      err.message === "timeout_descarga" ? "TIMEOUT_DESCARGA" :
                      err.message === "timeout_global" ? "TIMEOUT_GLOBAL" :
                      "OTRO";
    console.error(`❌ Error CSF [${tipoError}]: RFC=${rfc} idCIF=${idCif}${lugar ? ` Lugar="${lugar}"` : ""} | Cliente: ${sender} | Mensaje: ${err.message}`);

    stats.fallidas++;
    getGrupoStats(chatId).errores++; guardarStats();

    if (err.message !== "datos_invalidos") {
      liberarDuplicado(rfc, idCif);
    }

    if (err.message === "datos_invalidos") {
      await msg.reply(`❌ *${rfc}* no es válido en SAT.\nRevisa el RFC y el idCIF.`);
    } else if (err.message === "timeout_descarga" || err.message === "timeout_global") {
      await msg.reply(`⏰ SAT lento. Intenta de nuevo.\nRFC: ${rfc}`);
    } else {
      await msg.reply(`⚠️ Error procesando *${rfc}*.\nIntenta de nuevo.`);
    }
    return;
  }

  if (pdfPath) {
    try {
      const archivoBase64 = fs.readFileSync(pdfPath, { encoding: "base64" });
      // FIX Bug #24: detectar extensión REAL del archivo, no asumir por `formato`.
      // Si OnlyOffice falla, generarCSFLocal hace fallback y devuelve DOCX aunque
      // se haya pedido PDF — antes el archivo se enviaba con MIME y nombre PDF
      // pero contenido DOCX, dejándolo corrupto al abrir.
      const esRealmenteDocx = pdfPath.toLowerCase().endsWith(".docx");
      const esDocxPedido = formato === "docx";
      const esDocx = esRealmenteDocx || esDocxPedido;
      const mimeType = esDocx
        ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        : "application/pdf";
      const extension = esDocx ? "docx" : "pdf";
      // FIX Bug #9: MessageMedia es una función factory, no constructor. `new` sobra.
      const media = MessageMedia(mimeType, archivoBase64, `${rfc}.${extension}`);
      const totalSeg  = (Date.now() - tiempoInicio) / 1000;
      const min = Math.floor(totalSeg / 60);
      const seg = (totalSeg % 60).toFixed(2);
      const tiempoTexto = min > 0 ? `${min} min ${seg} segundos` : `${seg} segundos`;
      const iconoFormato = esDocx ? "📝" : "📄";
      await msg.reply(media, null, { caption: `${iconoFormato} ${rfc} · ${tiempoTexto}` });
      stats.exitosas++;
      stats.hoy++;
      getGrupoStats(chatId).csf++;
      getGrupoStatsSemanal(chatId).csf++;
      // FIX Bug #44: si quien pidió es admin, contarle aparte para =grupos / =grupos_semanal
      if (esAdmin(msg)) {
        const autorMsg = msg.author || msg.from;
        getAdminStats(autorMsg).csf++;
        getAdminStatsSemanal(autorMsg).csf++;
      }
      guardarStats(); guardarStatsSemanal();
      // Descontar 1 crédito CSF si el sistema está activo en este grupo
      await descontarCredito(chatId, msg, "csf");
      tiempoPromedioMs = Math.round(tiempoPromedioMs * 0.7 + (Date.now() - tiempoInicio) * 0.3);
      console.log(`📊 Stats: ✅${stats.exitosas} ❌${stats.fallidas} | Hoy: ${stats.hoy} | Tiempo: ${tiempoTexto} | Uptime: ${Math.floor((Date.now() - stats.inicio) / 3600000)}h`);
    } catch (sendErr) {
      console.error(`❌ Error al enviar ${formato.toUpperCase()}:`, sendErr.message);
      await msg.reply(`⚠️ Archivo generado pero no se pudo enviar.\nIntenta de nuevo. RFC: ${rfc}`);
    } finally {
      try { fs.unlinkSync(pdfPath); } catch (e) {}
    }
  } else {
    stats.fallidas++;
    getGrupoStats(chatId).errores++; guardarStats();
    await msg.reply(`⚠️ IDCIF se leyó, pero no arrojó información en SAT.`);
  }
}

// ══════════════════════════════════════════════════════════════════════════════
//  CONSULTA CURP — gob.mx
// ══════════════════════════════════════════════════════════════════════════════

let curpPage    = null;
let curpContext  = null; // contexto de curpPage — guardado para cerrarlo al recrear
let curpOcupado = false;
// FIX Bug #3: lock de inicialización compartido. Lo set desde iniciarSistemasPostConexion()
// y consultarCURPgob lo espera ANTES de chequear si curpPage existe.
let curpInitPromise = null;

// ── Consultar CURP en www.gob.mx/curp/ y extraer datos (con reintentos) ──
async function _intentarConsultaCURP(curp, numIntento = 1) {
  const t0 = Date.now();
  const ms = () => `${Date.now() - t0}ms`;

  const urlActual = curpPage.url();
  const yaEnCurp = urlActual.includes('gob.mx/curp');

  // Intentar reusar la página sin recargar (más rápido)
  // Solo recargar/navegar si no estamos en la página O si es reintento (intento >= 2)
  let necesitaRecarga = !yaEnCurp || numIntento >= 2;

  if (yaEnCurp && !necesitaRecarga) {
    // FIX Bug #41: limpiar input con page.fill('', '') nativo en lugar de setter.call
    // (que está bloqueado por anti-bot con "Illegal invocation").
    try {
      let selectorLimpiar = null;
      for (const sel of ['#curpinput', 'input[name="curp"]', 'input[placeholder*="CURP" i]']) {
        const existe = await curpPage.$(sel);
        if (existe && await existe.isVisible().catch(() => false)) {
          selectorLimpiar = sel;
          break;
        }
      }
      if (selectorLimpiar) {
        await curpPage.fill(selectorLimpiar, '');
      } else {
        necesitaRecarga = true;
      }
    } catch (e) {
      necesitaRecarga = true;
    }
  }

  if (necesitaRecarga) {
    if (yaEnCurp) {
      await curpPage.reload({ waitUntil: 'domcontentloaded', timeout: 30000 });
      console.log(`   [CURP] Página recargada (${ms()})`);
    } else {
      await curpPage.goto('https://www.gob.mx/curp/', { waitUntil: 'domcontentloaded', timeout: 30000 });
      console.log(`   [CURP] Página cargada (${ms()})`);
    }
  } else {
    console.log(`   [CURP] Reusando página (input limpio) (${ms()})`);
  }

  // Esperar input visible Y llenar la CURP en un solo evaluate —
  // elimina el round-trip de evaluateHandle + click + fill + type por separado.
  // gob.mx necesita eventos de teclado para activar su validación interna,
  // pero simularlos desde evaluate es equivalente y mucho más rápido que
  // inputEl.type(curp, {delay:15}) que tarda 18×15ms = ~270ms.
  await curpPage.waitForFunction(() => {
    const inputs = document.querySelectorAll('input');
    for (const inp of inputs) {
      const r = inp.getBoundingClientRect();
      if (r.width > 0 && r.height > 0) return true;
    }
    return false;
  }, { timeout: 15000 });

  // FIX Bug #41: usar page.type() nativo en lugar de setter.call() + dispatchEvent.
  // El sistema anti-bot de gob.mx bloquea setter.call() con "Illegal invocation".
  // page.type() simula tecleo a nivel CDP (Chrome DevTools Protocol), indistinguible
  // de un humano. Stealth plugin maneja el resto de la detección.

  // Buscar el selector del input — primero #curpinput (lo más común), después fallbacks
  let selectorInput = null;
  const candidatos = ['#curpinput', 'input[name="curp"]', 'input[placeholder*="CURP" i]', 'input[placeholder*="curp" i]'];
  for (const sel of candidatos) {
    const existe = await curpPage.$(sel);
    if (existe) {
      const visible = await existe.isVisible().catch(() => false);
      if (visible) { selectorInput = sel; break; }
    }
  }

  if (!selectorInput) {
    // Último fallback: cualquier input visible que no sea checkbox/radio/hidden
    selectorInput = await curpPage.evaluate(() => {
      const inputs = Array.from(document.querySelectorAll('input'));
      const inp = inputs.find(i => {
        const r = i.getBoundingClientRect();
        return r.width > 0 && r.height > 0 &&
               !['checkbox','radio','hidden','submit','button'].includes(i.type);
      });
      if (!inp) return null;
      // Devolver un selector único — preferir id, después name
      if (inp.id) return '#' + inp.id;
      if (inp.name) return 'input[name="' + inp.name + '"]';
      return 'input';
    });
  }

  if (!selectorInput) throw new Error('No se encontró ningún input visible');

  // Click para focus + limpiar + escribir con type (delay 25ms entre teclas — natural)
  try {
    await curpPage.click(selectorInput, { timeout: 5000 });
    await curpPage.fill(selectorInput, ''); // limpiar primero
    await curpPage.type(selectorInput, curp, { delay: 25 });
  } catch (e) {
    throw new Error(`Error al llenar input ${selectorInput}: ${e.message}`);
  }

  console.log(`   [CURP] CURP escrita (${ms()})`);

  // FIX Bug #42: gob.mx solo procesa la búsqueda con la tecla Enter en el input.
  // El click del botón Buscar visualmente funciona pero NO dispara la búsqueda real
  // (el JS del sitio escucha keydown Enter para evitar bots que clickean botones).
  // Esto se descubrió tras pruebas exhaustivas: form.submit() y click('#searchButton')
  // ambos fallan, solo keyboard.press('Enter') con focus en el input funciona.
  let clickOK = false;
  try {
    // Asegurar que el input siga en focus (el type() lo dejó así, pero por seguridad)
    await curpPage.focus(selectorInput);
    await curpPage.keyboard.press('Enter');
    clickOK = true;
  } catch (e) {
    // Fallback: intentar click del botón (no debería ser necesario, pero por si gob.mx cambia)
    for (const sel of ['button:has-text("Buscar")', '#searchButton', 'input[value*="Buscar" i]']) {
      try {
        await curpPage.click(sel, { timeout: 2000 });
        clickOK = true;
        break;
      } catch (e2) { /* probar siguiente */ }
    }
  }

  if (!clickOK) {
    throw new Error('No se pudo enviar la búsqueda (Enter ni click funcionaron)');
  }
  console.log(`   [CURP] Click Buscar (${ms()})`);

  // Esperar resultado — 12s max (gob.mx puede tardar hasta 10s en responder)
  await curpPage.waitForFunction((curpEsperada) => {
    const body = document.body.innerText;
    if ((body.includes('Primer apellido') || body.includes('Segundo apellido') || body.includes('Descarga del CURP')) && body.includes(curpEsperada)) return true;
    if (body.includes('no son correctos') || body.includes('nvalido') || body.includes('campo es inv')) return true;
    if (body.includes('no disponible') || body.includes('intente más tarde') || body.includes('intente mas tarde') ||
        body.includes('Servicio no disponible') || body.includes('Error del servidor') ||
        body.includes('no se puede procesar') || body.includes('tiempo de espera') ||
        body.includes('502') || body.includes('503') || body.includes('504')) return true;
    return false;
  }, curp, { timeout: 12000 });
  console.log(`   [CURP] Resultado recibido (${ms()})`);

  // Detectar errores y extraer datos en un solo evaluate (evita 3 round-trips separados)
  const resultado = await curpPage.evaluate((curpEsperada) => {
    const body = document.body.innerText;
    const bodyLower = body.toLowerCase();

    // Error de servidor → reintentar
    if (bodyLower.includes('no disponible') || bodyLower.includes('intente más tarde') ||
        bodyLower.includes('intente mas tarde') || bodyLower.includes('error de conexión') ||
        bodyLower.includes('error de conexion')) {
      return { tipo: 'servidor' };
    }

    // CURP inválida → no reintentar
    if (body.includes('no son correctos') || body.includes('nvalido') || body.includes('campo es inv')) {
      return { tipo: 'invalida' };
    }

    // Extraer datos de la tabla en un solo recorrido
    const tabla = {};
    const rows = document.querySelectorAll('tr');
    for (const row of rows) {
      const celdas = row.querySelectorAll('td');
      if (celdas.length >= 2) {
        const label = celdas[0].textContent.trim().toLowerCase();
        const valor = celdas[1].textContent.trim();
        tabla[label] = valor;
      }
    }

    const get = (key) => {
      for (const [label, valor] of Object.entries(tabla)) {
        if (label.includes(key.toLowerCase())) return valor;
      }
      return '';
    };

    return {
      tipo: 'exito',
      nombre:  get('nombre'),
      ap1:     get('primer apellido'),
      ap2:     get('segundo apellido'),
      sexo:    get('sexo'),
      fecha:   get('fecha de nacimiento'),
      entidad: get('entidad de nacimiento'),
    };
  }, curp);

  if (resultado.tipo === 'servidor') throw new Error('Servicio gob.mx no disponible — reintentar');
  if (resultado.tipo === 'invalida') return null;

  console.log(`   [CURP] Datos extraídos (${ms()})`);

  if (!resultado.nombre) {
    const bodyText = await curpPage.evaluate(() => document.body.innerText.substring(0, 500));
    console.warn(`   [CURP] Página sin datos: ${bodyText.replace(/\n/g, ' | ').substring(0, 300)}`);
    throw new Error('Datos vacíos tras búsqueda');
  }
  return resultado;
}

// ── Normalizar entidad para que YODA la reconozca ──
// Mapa de variantes comunes → nombre oficial que usa YODA
const ENTIDAD_NORM = {
  // CDMX (antes DF)
  "DISTRITO FEDERAL": "Ciudad de México",
  "DF": "Ciudad de México",
  "D.F.": "Ciudad de México",
  "CDMX": "Ciudad de México",
  "CIUDAD DE MEXICO": "Ciudad de México",
  "CIUDAD DE MÉXICO": "Ciudad de México",

  // Estado de México
  "MEXICO": "Estado de México",
  "EDO MEXICO": "Estado de México",
  "EDO DE MEXICO": "Estado de México",
  "EDO. DE MEXICO": "Estado de México",
  "ESTADO DE MEXICO": "Estado de México",
  "ESTADO DE MÉXICO": "Estado de México",
  "EDOMEX": "Estado de México",
  "MEX": "Estado de México",

  // Estados con nombres oficiales largos
  "COAHUILA DE ZARAGOZA": "Coahuila",
  "COAHUILA": "Coahuila",
  "MICHOACAN DE OCAMPO": "Michoacán",
  "MICHOACAN": "Michoacán",
  "MICHOACÁN": "Michoacán",
  "VERACRUZ DE IGNACIO DE LA LLAVE": "Veracruz",
  "VERACRUZ LLAVE": "Veracruz",
  "VERACRUZ": "Veracruz",

  // Estados con acentos
  "YUCATAN": "Yucatán",
  "YUCATÁN": "Yucatán",
  "NUEVO LEON": "Nuevo León",
  "NUEVO LEÓN": "Nuevo León",
  "N.L.": "Nuevo León",
  "NL": "Nuevo León",
  "SAN LUIS POTOSI": "San Luis Potosí",
  "SAN LUIS POTOSÍ": "San Luis Potosí",
  "SLP": "San Luis Potosí",
  "QUERETARO": "Querétaro",
  "QUERÉTARO": "Querétaro",
  "QUERETARO DE ARTEAGA": "Querétaro",

  // Baja California
  "BAJA CALIFORNIA": "Baja California",
  "BAJA CALIFORNIA NORTE": "Baja California",
  "BCN": "Baja California",
  "BC": "Baja California",
  "BAJA CALIFORNIA SUR": "Baja California Sur",
  "BCS": "Baja California Sur",

  // Quintana Roo
  "QUINTANA ROO": "Quintana Roo",
  "Q. ROO": "Quintana Roo",
  "QROO": "Quintana Roo",

  // Extranjero
  "NACIDO EN EL EXTRANJERO": "Extranjero",
  "EXTRANJERO": "Extranjero",
  "EXTRANJERA": "Extranjero",
  "EXT": "Extranjero",
  "NE": "Extranjero",

  // Otros estados (sin cambios pero presentes para consistencia)
  "AGUASCALIENTES": "Aguascalientes",
  "CAMPECHE": "Campeche",
  "CHIAPAS": "Chiapas",
  "CHIHUAHUA": "Chihuahua",
  "COLIMA": "Colima",
  "DURANGO": "Durango",
  "GUANAJUATO": "Guanajuato",
  "GUERRERO": "Guerrero",
  "HIDALGO": "Hidalgo",
  "JALISCO": "Jalisco",
  "MORELOS": "Morelos",
  "NAYARIT": "Nayarit",
  "OAXACA": "Oaxaca",
  "PUEBLA": "Puebla",
  "SINALOA": "Sinaloa",
  "SONORA": "Sonora",
  "TABASCO": "Tabasco",
  "TAMAULIPAS": "Tamaulipas",
  "TLAXCALA": "Tlaxcala",
  "ZACATECAS": "Zacatecas",
};

function normalizarEntidad(entidad) {
  if (!entidad) return entidad;
  // Normalizar: mayúsculas, sin acentos, sin espacios extra
  const clave = entidad.toUpperCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, " ").trim();
  if (ENTIDAD_NORM[clave]) return ENTIDAD_NORM[clave];
  return entidad;
}

// ══════════════════════════════════════════════════════════════════════════════
//  VALIDACIÓN DE CURP (antes de gastar créditos de la API)
// ══════════════════════════════════════════════════════════════════════════════

// Códigos de entidad válidos en la CURP (posiciones 11-12)
const ENTIDADES_CURP_VALIDAS = new Set([
  "AS","BC","BS","CC","CL","CM","CS","CH","DF","DG",
  "GT","GR","HG","JC","MC","MN","MS","NT","NL","OC",
  "PL","QT","QR","SP","SL","SR","TC","TS","TL","VZ",
  "YN","ZS","NE", // NE = Nacido en el extranjero
]);

function validarCURPestructura(curp) {
  // 1) Formato: 4 letras + 6 dígitos + H/M + 5 letras + 1 alfanumérico + 1 dígito
  if (!/^[A-Z]{4}\d{6}[HM][A-Z]{5}[A-Z0-9]\d$/i.test(curp)) {
    return { valida: false, razon: "Formato inválido — debe ser 18 caracteres con patrón AAAA######H/MAAAAA##" };
  }

  const c = curp.toUpperCase();

  // 2) Fecha válida (posiciones 4-9: AAMMDD)
  const anio2 = parseInt(c.substring(4, 6), 10);
  const mes   = parseInt(c.substring(6, 8), 10);
  const dia   = parseInt(c.substring(8, 10), 10);

  if (mes < 1 || mes > 12) {
    return { valida: false, razon: `Mes inválido: ${mes}` };
  }
  if (dia < 1 || dia > 31) {
    return { valida: false, razon: `Día inválido: ${dia}` };
  }

  // Verificar fecha real (ej: 30 de febrero no existe)
  const anioCompleto = anio2 <= (new Date().getFullYear() % 100) ? 2000 + anio2 : 1900 + anio2;
  const fechaPrueba = new Date(anioCompleto, mes - 1, dia);
  if (fechaPrueba.getMonth() !== mes - 1 || fechaPrueba.getDate() !== dia) {
    return { valida: false, razon: `Fecha no existe: ${dia}/${mes}/${anioCompleto}` };
  }

  // 3) Entidad válida (posiciones 11-12)
  const entidad = c.substring(11, 13);
  if (!ENTIDADES_CURP_VALIDAS.has(entidad)) {
    return { valida: false, razon: `Código de entidad inválido: ${entidad}` };
  }

  // 4) Dígito verificador (último carácter)
  const tabla = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ";
  let suma = 0;
  for (let i = 0; i < 17; i++) {
    const charIdx = tabla.indexOf(c[i]);
    if (charIdx < 0) {
      return { valida: false, razon: `Carácter inválido en posición ${i + 1}: ${c[i]}` };
    }
    suma += charIdx * (18 - i);
  }
  const verificador = (10 - (suma % 10)) % 10;
  if (parseInt(c[17], 10) !== verificador) {
    return { valida: false, razon: `Dígito verificador incorrecto (esperado ${verificador}, tiene ${c[17]})` };
  }

  return { valida: true };
}

// ══════════════════════════════════════════════════════════════════════════════
//  CONSULTA CURP — API valida-curp.com.mx (principal) + gob.mx (fallback)
// ══════════════════════════════════════════════════════════════════════════════

const CURP_API_TOKEN = process.env.CURP_API_TOKEN || "b075a154-c369-4799-8f93-51d9d98260e5";

// ── Método 1: API valida-curp.com.mx (~1-3s) ──
async function _consultarCURPapi(curp) {

  return new Promise((resolve, reject) => {
    const url = `https://api.valida-curp.com.mx/curp/obtener_datos/?token=${CURP_API_TOKEN}&curp=${curp}`;

    https.get(url, { timeout: 10000 }, (res) => {
      let data = "";
      res.on("data", (chunk) => { data += chunk; });
      res.on("end", () => {
        try {
          const json = JSON.parse(data);
          if (json.error || !json.response?.Solicitante) {
            reject(new Error(json.error_message || "CURP no encontrada en API"));
            return;
          }
          // Cachear respuesta completa para que generarConstanciaLocal no
          // tenga que consultar otra vez (ahorra 1 crédito por clon)
          try { cachearRespuestaCURP(curp, json); } catch (e) {}

          const s = json.response.Solicitante;
          // Normalizar fecha a DD/MM/YYYY (la API puede devolver YYYY-MM-DD o DD/MM/YYYY)
          let fechaRaw = (s.FechaNacimiento || "").trim();
          if (/^\d{4}-\d{2}-\d{2}$/.test(fechaRaw)) {
            // YYYY-MM-DD → DD/MM/YYYY
            const [anio, mes, dia] = fechaRaw.split("-");
            fechaRaw = `${dia}/${mes}/${anio}`;
          }
          resolve({
            nombre: (s.Nombres || "").trim().toUpperCase(),
            ap1: (s.ApellidoPaterno || "").trim().toUpperCase(),
            ap2: (s.ApellidoMaterno || "").trim().toUpperCase(),
            sexo: (s.Sexo || "").toUpperCase(),
            fecha: fechaRaw,
            entidad: (s.EntidadNacimiento || "").trim().toUpperCase(),
          });
        } catch (e) {
          reject(new Error("Error parseando respuesta API CURP"));
        }
      });
    }).on("error", (e) => reject(e))
      .on("timeout", function() { this.destroy(); reject(new Error("API CURP timeout")); });
  });
}

// ── Función principal: API primero, gob.mx como fallback ──
async function consultarCURP(curp) {
  // 0) Validar estructura ANTES de gastar créditos de la API
  const validacion = validarCURPestructura(curp);
  if (!validacion.valida) {
    console.warn(`⚠️  CURP inválida (${validacion.razon}): ${curp}`);
    return null;
  }

  // 1) API valida-curp.com.mx (rápido)
  try {
    console.log(`🔍 Consultando CURP vía API: ${curp}`);
    const t0 = Date.now();
    const datos = await _consultarCURPapi(curp);

    if (!datos.nombre) throw new Error("Datos vacíos de API");

    let sexo = datos.sexo;
    if (sexo === 'H' || sexo.includes('HOMBRE') || sexo.includes('MASC')) sexo = 'HOMBRE';
    else if (sexo === 'M' || sexo.includes('MUJER') || sexo.includes('FEM')) sexo = 'MUJER';

    const entidad = normalizarEntidad(datos.entidad);
    if (entidad !== datos.entidad) console.log(`   Entidad normalizada: ${datos.entidad} → ${entidad}`);

    console.log(`✅ API CURP (${Date.now() - t0}ms): ${datos.nombre} ${datos.ap1} | ${datos.fecha} | ${entidad}`);
    return { curp, nombre: datos.nombre, ap1: datos.ap1, ap2: datos.ap2, sexo, fecha: datos.fecha, entidad };

  } catch (apiErr) {
    console.warn(`⚠️  API CURP falló: ${apiErr.message} — cayendo a gob.mx...`);
  }

  // 2) Fallback: gob.mx (lento pero gratis)
  return await consultarCURPgob(curp);
}

// ── Método 2: gob.mx/curp (fallback, ~5-30s) ──
async function consultarCURPgob(curp) {
  // FIX Bug #3: si la pre-carga sigue en curso, esperarla antes de tocar curpPage.
  // Esto evita que se creen 2 contexts en paralelo (la pre-carga + esta consulta).
  if (curpInitPromise) {
    try { await curpInitPromise; } catch (e) { /* si falla, intentamos crear desde cero abajo */ }
    curpInitPromise = null; // ya esperada, no requerimos esperarla otra vez
  }

  // Esperar si otra consulta está usando curpPage — máximo 30s para evitar deadlock
  const maxEspera = Date.now() + 30000;
  while (curpOcupado) {
    if (Date.now() > maxEspera) throw new Error("curpPage ocupado — timeout de espera");
    await esperar(300);
  }
  curpOcupado = true;

  try {
    console.log(`🔍 Consultando CURP en gob.mx: ${curp}`);

  if (!curpPage || curpPage.isClosed()) {
    if (!csfBrowser) await obtenerBrowser();
    if (curpContext) { try { await curpContext.close(); } catch (e) {} curpContext = null; }
    const nuevoCurpContext = await csfBrowser.newContext({
      viewport: { width: 1024, height: 768 },
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
      locale: 'es-MX',
    });
    curpContext = nuevoCurpContext;
    curpPage = await nuevoCurpContext.newPage();
    curpPage.on('dialog', async d => { try { await d.dismiss(); } catch(e){} });
  }

  const MAX_INTENTOS_CURP = 4;

  for (let intento = 1; intento <= MAX_INTENTOS_CURP; intento++) {
    try {
      // Timeout global de 25s por intento. Si gob.mx está lento (anti-bot,
      // captcha invisible, red saturada), evitamos que un intento individual
      // tarde 90+ segundos y bloquee el event loop completo.
      const datos = await Promise.race([
        _intentarConsultaCURP(curp, intento),
        new Promise((_, rej) => setTimeout(() => rej(new Error("timeout_global_25s")), 25000)),
      ]);

      if (datos === null) {
        console.warn(`⚠️  gob.mx/curp: CURP ${curp} inválida o no encontrada`);
        return null;
      }

      console.log(`✅ gob.mx datos (intento ${intento}): ${datos.nombre} ${datos.ap1} | ${datos.fecha} | ${datos.entidad}`);

      let sexo = (datos.sexo || '').toUpperCase();
      if (sexo === 'H' || sexo.includes('HOMBRE') || sexo.includes('MASC')) sexo = 'HOMBRE';
      else if (sexo === 'M' || sexo.includes('MUJER') || sexo.includes('FEM')) sexo = 'MUJER';

      // Normalizar entidad para que YODA la reconozca
      let entidad = normalizarEntidad(datos.entidad.trim().toUpperCase());
      if (entidad !== datos.entidad.trim().toUpperCase()) {
        console.log(`   Entidad normalizada: ${datos.entidad.trim().toUpperCase()} → ${entidad}`);
      }

      return {
        curp,
        nombre:  datos.nombre.trim().toUpperCase(),
        ap1:     datos.ap1.trim().toUpperCase(),
        ap2:     datos.ap2.trim().toUpperCase(),
        sexo,
        fecha:   datos.fecha.trim(),
        entidad,
      };

    } catch (err) {
      console.warn(`⚠️  gob.mx intento ${intento}/${MAX_INTENTOS_CURP}: ${err.message}`);
      if (intento < MAX_INTENTOS_CURP) await esperar(500);
    }
  }

  console.error(`❌ gob.mx/curp: falló tras ${MAX_INTENTOS_CURP} intentos`);
  return null;

  } finally {
    curpOcupado = false;
  }
}

// ── Parsear mensaje "rfc generico" con datos ──
function parsearRFCcurp(texto) {
  const t = texto.replace(/[\u200B-\u200D\uFEFF\u00A0]/g, " ").trim();

  // Debe contener "clon", "clondocx", "clonsinobli", "rfc generico" o "rfc con curp"
  if (!/(?:^clon(?:docx|sinobli)?\b|rfc\s*(con\s*)?(?:curp|generico))/i.test(t)) return null;

  // Extraer CURP (18 caracteres)
  const curpMatch = t.match(/\b([A-Z]{4}\d{6}[HM][A-Z]{5}[A-Z0-9]\d)\b/i);
  if (!curpMatch) return null;

  const curp = curpMatch[1].toUpperCase().replace(/[^A-Z0-9]/g, "");

  // Parsear línea por línea para mayor flexibilidad
  const lineas = t.split(/\n/);
  let nombre = "", ap1 = "", ap2 = "", sexo = "", fecha = "", entidad = "";

  for (const linea of lineas) {
    const l = linea.trim();

    // Nombre / Nombre(s) / Nombres
    if (/^Nombre(?:s|\(s\))?[:\s]/i.test(l)) {
      nombre = l.replace(/^Nombre(?:s|\(s\))?[:\s]+/i, "").trim().toUpperCase();
    }
    // Primer apellido / Apellido paterno / Apellido 1
    else if (/^(?:Primer\s*)?apellido(?:\s*paterno)?[:\s]/i.test(l) && !ap1) {
      ap1 = l.replace(/^(?:Primer\s*)?apellido(?:\s*paterno)?[:\s]+/i, "").trim().toUpperCase();
    }
    // Segundo apellido / Apellido materno / Apellido 2
    else if (/^Segundo\s*apellido|^Apellido\s*materno/i.test(l)) {
      ap2 = l.replace(/^(?:Segundo\s*)?apellido(?:\s*materno)?[:\s]+/i, "").trim().toUpperCase();
    }
    // Sexo
    else if (/^Sexo[:\s]/i.test(l)) {
      sexo = l.replace(/^Sexo[:\s]+/i, "").trim().toUpperCase();
    }
    // Fecha de nacimiento
    else if (/^Fecha/i.test(l)) {
      const fechaMatch = l.match(/(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})/);
      if (fechaMatch) fecha = fechaMatch[1].replace(/-/g, "/");
    }
    // Entidad de nacimiento
    else if (/^Entidad/i.test(l)) {
      entidad = l.replace(/^Entidad\s*(?:de\s*)?nacimiento[:\s]+/i, "").trim().toUpperCase();
    }
  }

  if (entidad) {
    const entidadNorm = normalizarEntidad(entidad);
    if (entidadNorm !== entidad) {
      console.log(`   Entidad normalizada: ${entidad} → ${entidadNorm}`);
      entidad = entidadNorm;
    }
    // Para el resto (ej: "Coahuila de Zaragoza", "Veracruz de Ignacio de la Llave")
    // el selector de YODA usará solo la primera palabra como clave de búsqueda
  }

  // ── Fecha: usar la del mensaje si viene; si no, extraer de la CURP ──
  // La CURP tiene la fecha en posiciones 4-9 formato AAMMDD
  const anio2  = curp.substring(4, 6);
  const mes    = curp.substring(6, 8);
  const dia    = curp.substring(8, 10);
  const anioNum = parseInt(anio2, 10);
  const anioCompleto = anioNum <= (new Date().getFullYear() % 100) ? `20${anio2}` : `19${anio2}`;
  const fechaDeCURP = `${dia}/${mes}/${anioCompleto}`;

  if (fecha) {
    // Normalizar a DD/MM/YYYY por si vino con año de 2 dígitos (ej: 31/01/60 -> 31/01/1960)
    const partes = fecha.split("/");
    if (partes.length === 3 && partes[2].length === 2) {
      const a = parseInt(partes[2], 10);
      partes[2] = a <= (new Date().getFullYear() % 100) ? `20${partes[2]}` : `19${partes[2]}`;
      fecha = partes.join("/");
    }
  } else {
    // No vino fecha en el mensaje — tomarla de la CURP
    fecha = fechaDeCURP;
    console.log(`   Fecha (de CURP): ${fecha}`);
  }

  // Normalizar sexo
  let sexoNorm = "";
  if (sexo === "H" || sexo.includes("HOMBRE") || sexo.includes("MASC")) sexoNorm = "HOMBRE";
  else if (sexo === "M" || sexo.includes("MUJER") || sexo.includes("FEM")) sexoNorm = "MUJER";
  else sexoNorm = curp[10] === "H" ? "HOMBRE" : "MUJER";

  return { curp, nombre, ap1, ap2, sexo: sexoNorm, fecha, entidad };
}

// ── Extraer número de oficina del mensaje clon ──
// Formato: "clon CURP 45" — busca un número suelto (1-84) que no sea parte de la CURP
function extraerNumeroOficina(texto) {
  const t = texto.replace(/[\u200B-\u200D\uFEFF\u00A0]/g, " ").trim();
  // Quitar la CURP del texto para no confundir números dentro de ella
  const sinCurp = t.replace(/\b[A-Z]{4}\d{6}[HM][A-Z]{5}[A-Z0-9]\d\b/gi, "").trim();
  // Buscar números sueltos (no pegados a letras)
  const numeros = sinCurp.match(/\b(\d{1,3})\b/g);
  if (!numeros) return null;
  // Tomar el último número encontrado
  const num = parseInt(numeros[numeros.length - 1], 10);
  if (num >= 1 && num <= OFICINAS_EMISION.length) return num;
  return null;
}

// ── (Eliminado: convertirDocxAPdf con Adobe PDF Services) ───────────────────
// FIX Bug #8: la función con Adobe estaba aquí pero NO se llamaba desde ningún lado
// (todo el flujo PDF en producción usa OnlyOffice via generarCSFLocal/generarClonLocal).
// Se removió para limpiar código muerto. Si alguna vez se necesita reactivar:
//   - clientId/secret estaban en producción y siguen activos
//   - Reinstalar: npm install @adobe/pdfservices-node-sdk
//   - Restaurar la función desde git history o backup previo a este parche.

// ── Sub-función: llenar formulario, generar datos y descargar (un solo intento) ──
async function intentarConvertirCURP({ msg, datos, sender }) {
  try {
    const rfcGenerado = generarRFC(datos.nombre, datos.ap1, datos.ap2, datos.fecha);
    await msg.reply(`${rfcGenerado}`);
    console.log(`📊 Convertir: ✅ ${datos.curp} → ${rfcGenerado} (local)`);
  } catch (err) {
    console.error(`❌ Error calculando RFC:`, err.message);
    await msg.reply(`⚠️ No se pudo calcular el RFC para *${datos.curp}*`);
  }
}

// ══════════════════════════════════════════════════════════════════════════════
//  EXTRAER DATOS DEL SAT — HTTP nativo (rápido) + fallback Playwright
// ══════════════════════════════════════════════════════════════════════════════

// ── Versión rápida con HTTP nativo (~500ms vs ~1500ms con Playwright) ──
function extraerDatosSATHttp(rfc, idCif) {
  return new Promise((resolve, reject) => {
    const url = `https://siat.sat.gob.mx/app/qr/faces/pages/mobile/validadorqr.jsf?D1=10&D2=1&D3=${idCif}_${rfc}`;
    const constants = require("constants");

    const req = https.get(url, {
      rejectUnauthorized: false,
      ciphers: "DEFAULT:@SECLEVEL=0",
      secureOptions: constants.SSL_OP_LEGACY_SERVER_CONNECT,
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
      },
      timeout: 15000,
    }, (res) => {
      if (res.statusCode !== 200) {
        return reject(new Error(`HTTP ${res.statusCode}`));
      }
      let html = "";
      res.on("data", (chunk) => (html += chunk));
      res.on("end", () => {
        try {
          // Optimización: tabla única de reemplazos de entidades HTML.
          // Antes: 14 regex.replace() en cascada (~40-60ms en HTMLs ~50KB del SAT).
          // Ahora: 1 sola pasada con tabla de lookup (~5-10ms).
          const ENTITIES = {
            "&nbsp;": " ", "&amp;": "&", "&lt;": "<", "&gt;": ">",
            "&quot;": '"', "&#39;": "'",
            "&aacute;": "á", "&Aacute;": "Á",
            "&eacute;": "é", "&Eacute;": "É",
            "&iacute;": "í", "&Iacute;": "Í",
            "&oacute;": "ó", "&Oacute;": "Ó",
            "&uacute;": "ú", "&Uacute;": "Ú",
            "&ntilde;": "ñ", "&Ntilde;": "Ñ",
          };

          // Limpiar HTML → texto plano. Tres pasadas necesarias:
          // 1) scripts/styles (regex con flag /s), 2) tags cerradas → \n, 3) entidades.
          const text = html
            .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, "")
            .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, "")
            .replace(/<\/(?:td|tr|div|p|h[1-6]|li)>/gi, "\n")
            .replace(/<br\s*\/?>/gi, "\n")
            .replace(/<[^>]+>/g, " ")
            .replace(/&(?:nbsp|amp|lt|gt|quot|#39|[aeiouAEIOU]acute|[nN]tilde);/g, m => ENTITIES[m] || m)
            .replace(/[ \t]+/g, " ")
            .replace(/\n\s*\n/g, "\n")
            .trim();

          // Caso 1: No se encontró
          if (text.includes("no se le ha emitido") || text.includes("No se encontr")) {
            const msgMatch = text.match(/(Al RFC:.*?fiscal)/is) || text.match(/(No se encontr.*?)$/im);
            return resolve({ encontrado: false, mensaje: msgMatch ? msgMatch[1].trim() : "No se encontró información para este RFC." });
          }

          // Caso 2: Datos encontrados
          // Optimización: extraer todos los campos en una sola pasada con un
          // solo regex compuesto en vez de 22 regex.match() separados (cada uno
          // recorre el string completo). En HTMLs ~3KB del SAT esto es ~5ms
          // en vez de ~25ms.
          const datos = {};
          const ubicacion = {};

          const TODOS_CAMPOS = [
            // [bucket, label, regex]
            ["datos", "CURP",                                  /CURP:\s*(.+)/i],
            ["datos", "Nombre",                                /Nombre:\s*(.+)/i],
            ["datos", "Apellido Paterno",                      /Apellido Paterno:\s*(.+)/i],
            ["datos", "Apellido Materno",                      /Apellido Materno:\s*(.+)/i],
            ["datos", "Fecha Nacimiento",                      /Fecha Nac[a-záéíóú]*:\s*(.+)/i],
            ["datos", "Fecha de Inicio de operaciones",        /Fecha de Inicio de operaciones:\s*(.+)/i],
            ["datos", "Situación del contribuyente",           /Situaci[oó]n del contribuyente:\s*(.+)/i],
            ["datos", "Fecha del último cambio de situación",  /Fecha del [uú]ltimo cambio de situaci[oó]n:\s*(.+)/i],
            ["ubic",  "Entidad Federativa",                    /Entidad Federativa:\s*(.+)/i],
            ["ubic",  "Municipio o delegación",                /Municipio o delegaci[oó]n:\s*(.+)/i],
            ["ubic",  "Colonia",                               /Colonia:\s*(.+)/i],
            ["ubic",  "Tipo de vialidad",                      /Tipo de vialidad:\s*(.+)/i],
            ["ubic",  "Nombre de la vialidad",                 /Nombre de la vialidad:\s*(.+)/i],
            ["ubic",  "Número exterior",                       /N[uú]mero exterior:\s*(.+)/i],
            ["ubic",  "Número interior",                       /N[uú]mero interior:\s*(.+)/i],
            ["ubic",  "CP",                                    /CP:\s*(.+)/i],
            ["ubic",  "Correo electrónico",                    /Correo electr[oó]nico:\s*(.+)/i],
            ["ubic",  "AL",                                    /\bAL:\s*(.+)/i],
          ];

          for (const [bucket, label, regex] of TODOS_CAMPOS) {
            const m = text.match(regex);
            if (m) (bucket === "datos" ? datos : ubicacion)[label] = m[1].trim();
          }

          let regimen = "";
          const regMatch = text.match(/R[eé]gimen:\s*(.+)/i);
          if (regMatch) regimen = regMatch[1].trim();

          let fechaAlta = "";
          const altaMatch = text.match(/Fecha de alta:\s*(.+)/i);
          if (altaMatch) fechaAlta = altaMatch[1].trim();

          // Validar que tengamos datos mínimos (al menos CURP o Nombre)
          if (!datos.CURP && !datos.Nombre) {
            return reject(new Error("HTML sin datos esperados"));
          }

          resolve({ encontrado: true, datos, ubicacion, regimen, fechaAlta });
        } catch (e) {
          reject(e);
        }
      });
    });
    req.on("error", reject);
    req.on("timeout", () => { req.destroy(); reject(new Error("timeout")); });
  });
}

// ── Versión Playwright (fallback si HTTP falla) ──
// Wrapper con timeout global de 25s. Si Playwright se cuelga (browser zombie,
// página bloqueada por anti-bot, network lenta) el bot quedaba bloqueado
// hasta 100+ segundos sin poder procesar otros mensajes y se desconectaba
// de WhatsApp por keep-alive perdido.
async function extraerDatosSATPlaywright(rfc, idCif) {
  const TIMEOUT_SAT_PLAYWRIGHT_MS = 25000;
  try {
    return await Promise.race([
      _extraerDatosSATPlaywrightInterno(rfc, idCif),
      new Promise((resolve) => setTimeout(() => {
        console.warn(`⏱️  SAT Playwright abortado por timeout (${TIMEOUT_SAT_PLAYWRIGHT_MS}ms)`);
        resolve({ encontrado: false, mensaje: "Timeout consultando SAT. Intenta de nuevo." });
      }, TIMEOUT_SAT_PLAYWRIGHT_MS)),
    ]);
  } catch (err) {
    console.error(`❌ SAT Playwright error fatal: ${err.message}`);
    return { encontrado: false, mensaje: "Error consultando SAT." };
  }
}

async function _extraerDatosSATPlaywrightInterno(rfc, idCif) {
  if (!csfBrowser) await obtenerBrowser();

  const ctx = await csfBrowser.newContext({
    viewport: { width: 1024, height: 768 },
    userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
  });

  // Solo necesitamos el texto — bloquear todo lo demás
  await ctx.route("**/*.{png,jpg,jpeg,gif,svg,woff,woff2,ttf,eot,css}", (route) => route.abort());
  await ctx.route("**/analytics*", (route) => route.abort());
  await ctx.route("**/google-analytics*", (route) => route.abort());
  await ctx.route("**/gtag*", (route) => route.abort());

  const page = await ctx.newPage();
  try {
    const url = `https://siat.sat.gob.mx/app/qr/faces/pages/mobile/validadorqr.jsf?D1=10&D2=1&D3=${idCif}_${rfc}`;
    console.log(`🔍 Extraer SAT (Playwright): ${url}`);
    await page.goto(url, { waitUntil: "domcontentloaded", timeout: 30000 });

    // Esperar a que cargue contenido
    await page.waitForFunction(() => {
      const body = document.body.innerText;
      return body.includes("RFC:") || body.includes("no se le ha emitido") || body.includes("Datos de Identificación") || body.length > 200;
    }, { timeout: 15000 });

    // Extraer todo el texto de la página
    const resultado = await page.evaluate(() => {
      const body = document.body.innerText.trim();

      if (body.includes("no se le ha emitido") || body.includes("No se encontr")) {
        const msgMatch = body.match(/(Al RFC:.*?fiscal)/is) || body.match(/(No se encontr.*?)$/im);
        return { encontrado: false, mensaje: msgMatch ? msgMatch[1].trim() : "No se encontró información para este RFC." };
      }

      const datos = {};
      const campos = [
        ["CURP", /CURP:\s*(.+)/i],
        ["Nombre", /Nombre:\s*(.+)/i],
        ["Apellido Paterno", /Apellido Paterno:\s*(.+)/i],
        ["Apellido Materno", /Apellido Materno:\s*(.+)/i],
        ["Fecha Nacimiento", /Fecha Nac[a-záéíóú]*:\s*(.+)/i],
        ["Fecha de Inicio de operaciones", /Fecha de Inicio de operaciones:\s*(.+)/i],
        ["Situación del contribuyente", /Situaci[oó]n del contribuyente:\s*(.+)/i],
        ["Fecha del último cambio de situación", /Fecha del [uú]ltimo cambio de situaci[oó]n:\s*(.+)/i],
      ];
      for (const [label, regex] of campos) {
        const m = body.match(regex);
        if (m) datos[label] = m[1].trim();
      }

      const ubicacion = {};
      const camposUbic = [
        ["Entidad Federativa", /Entidad Federativa:\s*(.+)/i],
        ["Municipio o delegación", /Municipio o delegaci[oó]n:\s*(.+)/i],
        ["Colonia", /Colonia:\s*(.+)/i],
        ["Tipo de vialidad", /Tipo de vialidad:\s*(.+)/i],
        ["Nombre de la vialidad", /Nombre de la vialidad:\s*(.+)/i],
        ["Número exterior", /N[uú]mero exterior:\s*(.+)/i],
        ["Número interior", /N[uú]mero interior:\s*(.+)/i],
        ["CP", /CP:\s*(.+)/i],
        ["Correo electrónico", /Correo electr[oó]nico:\s*(.+)/i],
        ["AL", /\bAL:\s*(.+)/i],
      ];
      for (const [label, regex] of camposUbic) {
        const m = body.match(regex);
        if (m) ubicacion[label] = m[1].trim();
      }

      let regimen = "";
      const regMatch = body.match(/R[eé]gimen:\s*(.+)/i);
      if (regMatch) regimen = regMatch[1].trim();

      let fechaAlta = "";
      const altaMatch = body.match(/Fecha de alta:\s*(.+)/i);
      if (altaMatch) fechaAlta = altaMatch[1].trim();

      return { encontrado: true, datos, ubicacion, regimen, fechaAlta };
    });

    return resultado;

  } catch (err) {
    console.error(`❌ Error extrayendo datos SAT: ${err.message}`);
    return { encontrado: false, mensaje: "No se pudo consultar el SAT. Intenta de nuevo." };
  } finally {
    await ctx.close();
  }
}

// ── Función principal: intenta HTTP primero, fallback Playwright ──
async function extraerDatosSAT(rfc, idCif) {
  const t0 = Date.now();
  try {
    const resultado = await extraerDatosSATHttp(rfc, idCif);
    console.log(`✅ SAT extraído via HTTP nativo en ${Date.now() - t0}ms`);
    return resultado;
  } catch (err) {
    console.warn(`⚠️  HTTP nativo falló (${err.message}) — usando Playwright`);
    return await extraerDatosSATPlaywright(rfc, idCif);
  }
}

// ── Helper: calcular edad desde los primeros 6 dígitos de la CURP (AAMMDD) ──
function calcularEdadDesdeCURP(curp) {
  const anio2 = parseInt(curp.substring(4, 6), 10);
  const anioNac = anio2 <= (new Date().getFullYear() % 100) ? 2000 + anio2 : 1900 + anio2;
  return new Date().getFullYear() - anioNac;
}

// ── Helper: Intentar generar RFC genérico y enviar ──
async function intentarGenerarRFCyCurp({ msg, datos, sender }) {
  const tiempoInicio = Date.now();
  const chat = await msg.getChat();
  const chatId = chat.id._serialized;
  let filePath = null;
  let fileType = null;
  let rfcGenerado = null;

  try {
    // FIX Bug #28: agregar timeout global de 120s para que si el flujo clon se
    // cuelga (Python child process trabado, OnlyOffice no responde, etc.) la
    // cola no se bloquee indefinidamente. Antes solo el CSF tenía esto.
    let clonTimeoutHandle = null;
    const clonTimeoutPromise = new Promise((_, reject) => {
      clonTimeoutHandle = setTimeout(() => reject(new Error("timeout_clon")), 120000);
    });

    const docxPath = await Promise.race([
      generarConstanciaLocal({
        curp:            datos.curp,
        token:           "x",
        downloadDir:     CONFIG.DOWNLOAD_DIR,
        emisionForzada:  datos.emisionForzada || datos.oficina || null,
        soloDocx:        datos.soloDocx === true,
        sinObligaciones: datos.sinObligaciones === true,
      }),
      clonTimeoutPromise,
    ]).finally(() => {
      if (clonTimeoutHandle) clearTimeout(clonTimeoutHandle);
    });

    filePath    = docxPath;
    fileType    = docxPath.endsWith(".pdf") ? "pdf" : "docx";
    rfcGenerado = null;
  } catch (err) {
    const esTimeout = /timeout|tiempo/i.test(err.message);
    console.error(`❌ Clon local falló [${esTimeout ? "TIMEOUT" : "ERROR"}]:`, err.message);
    stats.fallidas++;
    getGrupoStats(chatId).errores++; guardarStats();
    liberarDuplicado(datos.curp, "rfcgenerico");
    if (esTimeout) {
      await msg.reply(`⏰ Tardó demasiado. Intenta de nuevo.\nCURP: ${datos.curp}`);
    } else {
      await msg.reply(`⚠️ No se pudo generar.\nCURP: ${datos.curp}`);
    }
    return;
  }

  if (filePath) {
    try {
      const fileBase64 = fs.readFileSync(filePath, { encoding: "base64" });
      const mimeType = fileType === "pdf"
        ? "application/pdf"
        : "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
      const fileName = `${datos.curp}.${fileType}`;
      // FIX Bug #9: ver arriba — MessageMedia es factory, no constructor.
      const media = MessageMedia(mimeType, fileBase64, fileName);
      const segundos = ((Date.now() - tiempoInicio) / 1000).toFixed(1);
      await msg.reply(media, null, {
        caption: `✅ ${datos.curp} · ${segundos}s`
      });
      stats.exitosas++;
      stats.hoy++;
      getGrupoStats(chatId).clon++;
      getGrupoStatsSemanal(chatId).clon++;
      // FIX Bug #44: si quien pidió es admin, contarle aparte
      if (esAdmin(msg)) {
        const autorClon = msg.author || msg.from;
        getAdminStats(autorClon).clon++;
        getAdminStatsSemanal(autorClon).clon++;
      }
      guardarStats(); guardarStatsSemanal();
      // Descontar 1 crédito CLON si el sistema está activo en este grupo
      await descontarCredito(chatId, msg, "clon");
      console.log(`📊 RFC genérico: ✅ ${datos.curp}${rfcGenerado ? ` → ${rfcGenerado}` : ""} | ${segundos}s (${fileType})`);
    } catch (sendErr) {
      console.error("❌ Error al enviar archivo RFC:", sendErr.message);
      await msg.reply(`⚠️ Archivo generado pero no se pudo enviar. Intenta de nuevo.`);
    } finally {
      try { fs.unlinkSync(filePath); } catch (e) {}
    }
  }
}
// ── Control de horario de servicio ──────────────────────────────────────────
// Horario normal: 7:30am - 11:00pm hora CDMX
// Los admins pueden extender con =extender hasta las 2am
const HORARIO = {
  inicioH: 7, inicioM: 30,   // 7:30am
  finH: 23,   finM: 0,       // 11:00pm
  finExtendidoH: 4, finExtendidoM: 0, // 4:00am (con =extender)
};
let modoExtendido = false;     // true cuando admin usó =extender

function estaEnHorario() {
  const ahora = new Date();
  const cdmx = new Date(ahora.toLocaleString("en-US", { timeZone: "America/Mexico_City" }));
  const h = cdmx.getHours();
  const m = cdmx.getMinutes();
  const minutos = h * 60 + m;

  const inicio  = HORARIO.inicioH * 60 + HORARIO.inicioM;  // 450 = 7:30
  const fin     = HORARIO.finH    * 60 + HORARIO.finM;     // 1380 = 23:00
  const finExt  = HORARIO.finExtendidoH * 60 + HORARIO.finExtendidoM; // 240 = 4:00am

  if (modoExtendido) {
    // Extendido: 7:30am hasta las 4:00am del día siguiente (inclusive)
    // 7:30-23:59 ó 0:00-4:00am
    return minutos >= inicio || minutos <= finExt;
  }

  // Normal: 7:30am - 11:00pm
  return minutos >= inicio && minutos < fin;
}

function horaInicioMensaje() {
  return "7:30 a.m.";
}

async function manejarMensaje(msg) {
  const chat = await msg.getChat();

  // Imágenes van al handler de QR
  if (msg.hasMedia && ["image"].includes(msg.type)) {
    await manejarImagen(msg, chat);
    return;
  }

  let texto = msg.body || "";
  if (!texto) return;

  const chatId = chat.id._serialized;

  // ── Detectar formato DOCX (palabra "docx" en el texto) ──
  // Si el mensaje contiene "docx" como palabra suelta, descargar en DOCX en lugar de PDF
  let formatoSolicitado = "pdf";
  if (/\bdocx\b/i.test(texto)) {
    formatoSolicitado = "docx";
    // Remover la palabra "docx" del texto para que no interfiera con el parseo
    texto = texto.replace(/\bdocx\b/gi, "").replace(/\s+/g, " ").trim();
  }

  // ── Comandos de admin (funcionan en cualquier horario) ──
  const textoLimpio = texto.trim().toLowerCase();

  // ── =extender — activar modo extendido hasta las 2am ──
  if (textoLimpio === "=extender") {
    if (!esAdmin(msg)) return;
    modoExtendido = true;
    await msg.reply(`✅ *Modo extendido activado*\nEl bot seguirá activo hasta las 4:00 a.m.\nSe reiniciará automáticamente el horario normal mañana a las ${horaInicioMensaje()}.`);
    return;
  }

  // ── =horario — ver estado del horario ──
  if (textoLimpio === "=horario") {
    if (!esAdmin(msg)) return;
    const activo = estaEnHorario();
    const ahora = new Date().toLocaleString("es-MX", { timeZone: "America/Mexico_City", hour: "2-digit", minute: "2-digit" });
    await msg.reply(
      `🕐 *Horario de servicio*\n\n` +
      `Hora CDMX: ${ahora}\n` +
      `Estado: ${activo ? "✅ Activo" : "🔴 Fuera de horario"}\n` +
      `Horario normal: 7:30 a.m. — 11:00 p.m.\n` +
      `Modo extendido: ${modoExtendido ? "✅ Hasta las 4:00 a.m." : "❌ Desactivado"}\n\n` +
      `_Usa_ \`=extender\` _para activar hasta las 4:00 a.m._`
    );
    return;
  }

  if (textoLimpio === "=activar") {
    const autor = msg.author || msg.from;
    console.log(`🔑 Intento de activar grupo por: ${autor}`);
    if (!esAdmin(msg)) {
      await msg.reply("⛔ No tienes permisos para activar este grupo.");
      return;
    }

    if (grupoAutorizado(chatId)) {
      await msg.reply(`✅ Este grupo ya está autorizado.\n📋 ID: ${chatId}`);
      return;
    }

    gruposAutorizados.set(chatId, autor);
    guardarGrupos();
    console.log(`✅ Grupo autorizado: ${chat.name} (${chatId})`);
    await msg.reply(
      `🚀 *SPARTAN PRO activado*\n\n` +
      `¡Listo en *${chat.name}*! ⚡\n\n` +
      `📋 *Comandos:*\n\n` +
      `📄 *Generar CSF*\n` +
      `RFC + idCIF\n` +
      `_Ej:_ RAAM831207TR8 21110033036\n\n` +
      `🆔 *Generar RFC genérico*\n` +
      `clon CURP\n` +
      `_Ej:_ clon RARH050220HVZMVMA6\n\n` +
      `📸 *Leer QR de CSF*\n` +
      `Envía la foto del QR\n\n` +
      `🔍 *Consultar SAT sin PDF*\n` +
      `extraer RFC idCIF\n\n` +
      `💬 Cualquier duda contacta a un admin.`
    );
    return;
  }

  if (textoLimpio === "=desactivar") {
    if (!esAdmin(msg)) {
      await msg.reply("⛔ No tienes permisos para desactivar este grupo.");
      return;
    }

    if (!grupoAutorizado(chatId)) {
      await msg.reply("⚠️ Este grupo no está autorizado.");
      return;
    }

    gruposAutorizados.delete(chatId);
    guardarGrupos();
    console.log(`🚫 Grupo desautorizado: ${chat.name} (${chatId})`);
    await msg.reply(`🚫 *Grupo desautorizado*\n📋 ${chat.name}`);
    return;
  }

  // ── Comando =anuncio (solo Jose Angel y Josue R) ──
  if (textoLimpio.startsWith("=anuncio")) {
    const autor = msg.author || msg.from;
    const nombreAdmin = CONFIG.ADMIN_NOMBRES[autor];
    if (nombreAdmin !== "Jose Angel" && nombreAdmin !== "Josue R") {
      await msg.reply("⛔ No tienes permisos para enviar anuncios.");
      return;
    }

    const mensaje = texto.replace(/^=anuncio\s*/i, "").trim();
    if (!mensaje) {
      await msg.reply("⚠️ Escribe el mensaje después del comando.\n\nEjemplo: =anuncio El bot estará en mantenimiento de 10pm a 11pm");
      return;
    }

    const grupos = [...gruposAutorizados.keys()];
    if (grupos.length === 0) {
      await msg.reply("⚠️ No hay grupos autorizados.");
      return;
    }

    let enviados = 0;
    let fallidos = 0;

    for (const grupoId of grupos) {
      try {
        await waClient.sendMessage(grupoId, `📢 *ANUNCIO*\n\n${mensaje}`);
        enviados++;
        await esperar(500); // Pausa entre envíos para no saturar
      } catch (e) {
        console.error(`❌ No se pudo enviar anuncio a ${grupoId}:`, e.message);
        fallidos++;
      }
    }

    console.log(`📢 Anuncio enviado a ${enviados}/${grupos.length} grupos`);
    await msg.reply(`📢 Anuncio enviado a *${enviados}* grupo(s)${fallidos > 0 ? `\n⚠️ ${fallidos} fallido(s)` : ""}`);
    return;
  }

  // ── Verificar que el grupo esté autorizado ──
  // Los admins con comandos = pasan siempre (=grupos, =estatus, =creditos_todos, etc.)
  const esComandoAdmin = textoLimpio.startsWith("=");
  if (!grupoAutorizado(chatId) && !(esComandoAdmin && esAdmin(msg))) return;

  // ── Verificar horario de servicio ──
  // Comandos admin (=total, =estatus, =creditos, etc.) pasan siempre
  // Admins también pasan siempre (incluso solicitudes csf/clon/convertir fuera de horario)
  // Solicitudes de constancias y clones de usuarios normales respetan el horario
  if (!esComandoAdmin && !esAdmin(msg) && !estaEnHorario()) {
    // FIX Bug #2: 'sender' antes se definía después; aquí se usa, así que lo derivamos
    // del notifyName (suficiente para la clave del Map). Si no hay, usar autor del jid.
    const senderHorario = msg.notifyName || (msg.author || msg.from || "cliente");
    // Solo avisar una vez cada 30 min por usuario por grupo (evitar spam)
    const claveAviso = `horario_${chatId}_${senderHorario}`;
    const ultimoAviso = recientes.get(claveAviso);
    if (!ultimoAviso || Date.now() - ultimoAviso > 30 * 60 * 1000) {
      recientes.set(claveAviso, Date.now());
      await msg.reply(
        `🕐 *SPARTAN PRO*\n\n` +
        `Estamos fuera de horario de servicio.\n\n` +
        `📅 Horario: *7:30 a.m. — 11:00 p.m.*\n` +
        `🌙 Te atenderemos a partir de las *${horaInicioMensaje()}*`
      );
    }
    return;
  }

  // ── Resetear modo extendido al inicio del día ──
  if (modoExtendido) {
    const cdmx = new Date(new Date().toLocaleString("en-US", { timeZone: "America/Mexico_City" }));
    const h = cdmx.getHours();
    // Desactivar solo entre 4:01am y 7am
    const m = cdmx.getMinutes();
    if ((h === 4 && m > 0) || (h > 4 && h < 7)) modoExtendido = false;
  }
  if (texto.trim() === "=total") {
    const ahora = new Date().toLocaleString("es-MX", { timeZone: "America/Mexico_City", hour: "2-digit", minute: "2-digit" });
    const gs = getGrupoStats(chatId);
    const totalGrupo = gs.csf + gs.clon;

    // Obtener el número de grupo (posición en la lista de grupos autorizados)
    const grupoIds = Array.from(gruposAutorizados.keys());
    const numGrupo = grupoIds.indexOf(chatId) + 1;
    const numGrupoTexto = numGrupo > 0 ? `*Grupo #${numGrupo}*\n` : "";

    // Obtener info de créditos (CSF y CLON por separado)
    const c = getCreditos(chatId);

    let creditosCSF;
    if (c.activo_csf) {
      const emoji = c.creditos_csf > 10 ? "🟢" : c.creditos_csf > 0 ? "🟡" : "🔴";
      creditosCSF = `💳 Créditos CSF: ${emoji} ${c.creditos_csf}`;
    } else {
      creditosCSF = `💳 Créditos CSF: ⚪ Ilimitado`;
    }

    let creditosCLON;
    if (c.activo_clon) {
      const emoji = c.creditos_clon > 10 ? "🟢" : c.creditos_clon > 0 ? "🟡" : "🔴";
      creditosCLON = `🎁 Créditos Clon: ${emoji} ${c.creditos_clon}`;
    } else {
      creditosCLON = `🎁 Créditos Clon: ⚪ Ilimitado`;
    }

    await msg.reply(
      `📊 *Total del grupo*\n` +
      numGrupoTexto + `\n` +
      `📄 CSF idCIF: ${gs.csf}\n` +
      `📋 Clon: ${gs.clon}\n` +
      `❌ Errores: ${gs.errores}\n` +
      `✅ Total: ${totalGrupo}\n\n` +
      `${creditosCSF}\n` +
      `${creditosCLON}\n` +
      `🕐 Hora CDMX: ${ahora}`
    );
    return;
  }

  // ── Comando =estatus (solo admins) — estado completo del sistema ──
  if (textoLimpio === "=estatus") {
    if (!esAdmin(msg)) return;

    const ahora = new Date().toLocaleString("es-MX", { timeZone: "America/Mexico_City", hour: "2-digit", minute: "2-digit" });
    const uptimeMs = Date.now() - stats.inicio;
    const uptimeH = Math.floor(uptimeMs / 3600000);
    const uptimeM = Math.floor((uptimeMs % 3600000) / 60000);
    const ramMB = Math.round(process.memoryUsage().rss / 1024 / 1024);
    const heapMB = Math.round(process.memoryUsage().heapUsed / 1024 / 1024);
    const csfEstado = csfBrowser && csfBrowser.isConnected() ? "✅" : "❌";
    const curpEstado = curpPage && !curpPage.isClosed() ? "✅" : "❌";
    const colaActual = cola.length;
    const grupos = gruposAutorizados.size;

    await msg.reply(
      `🤖 *SPARTAN PRO — Estado*\n\n` +
      `⏱️ Uptime: ${uptimeH}h ${uptimeM}m\n` +
      `🕐 Hora CDMX: ${ahora}\n\n` +
      `📊 *Hoy:* ${stats.hoy} generadas\n` +
      `✅ Exitosas: ${stats.exitosas}\n` +
      `❌ Fallidas: ${stats.fallidas}\n\n` +
      `🌐 SAT: ${csfEstado}  RENAPO: ${curpEstado}\n` +
      `📋 Cola: ${colaActual} pendientes\n` +
      `👥 Grupos: ${grupos}\n\n` +
      `💾 RAM: ${ramMB}MB (heap: ${heapMB}MB)`
    );
    return;
  }

  // ── Comando =salud (solo admins) — diagnóstico de WhatsApp / Baileys ──
  // FIX Bug #48: monitor de salud de la conexión WhatsApp
  if (textoLimpio === "=salud") {
    if (!esAdmin(msg)) return;

    const formatearTiempo = (ms) => {
      if (!ms || ms < 0) return "N/A";
      const s = Math.floor(ms / 1000);
      if (s < 60) return `${s}s`;
      const m = Math.floor(s / 60);
      if (m < 60) return `${m}m ${s % 60}s`;
      const h = Math.floor(m / 60);
      return `${h}h ${m % 60}m`;
    };

    const ahoraMs = Date.now();
    const estadoWA = waReady ? "🟢 Conectado" : "🔴 Desconectado";
    const tiempoConectado = waConectadoDesde ? formatearTiempo(ahoraMs - waConectadoDesde) : "N/A";
    const desdeUltimoMsgRecibido = formatearTiempo(ahoraMs - ultimoMensajeRecibido);
    const desdeUltimoEnvio = waUltimoEnvioExitoso ? formatearTiempo(ahoraMs - waUltimoEnvioExitoso) : "N/A";

    // Reconexiones en la última hora
    const haceUnaHora = ahoraMs - 3600000;
    const reconexionesUltimaHora = waUltimasReconexiones.filter(t => t > haceUnaHora).length;

    // Cola actual
    const colaEnvio = envioQueue.length;
    const colaProcesamiento = cola.length;

    // Indicadores de salud
    let alertas = [];
    if (!waReady) alertas.push("🔴 WhatsApp desconectado");
    if (reconexionesUltimaHora >= 5) alertas.push(`⚠️ ${reconexionesUltimaHora} reconexiones en 1h (alta)`);
    if (colaEnvio >= 10) alertas.push(`⚠️ Cola envío grande: ${colaEnvio}`);
    if (colaProcesamiento >= 5) alertas.push(`⚠️ Cola procesamiento: ${colaProcesamiento}`);
    if (ahoraMs - ultimoMensajeRecibido > 1800000) alertas.push("⚠️ Sin mensajes recibidos >30 min");

    const indicadorGeneral = alertas.length === 0 ? "✅ *Todo bien*" : "⚠️ *Alertas detectadas*";

    await msg.reply(
      `🩺 *SALUD DE WHATSAPP*\n\n` +
      `${indicadorGeneral}\n\n` +
      `📡 Estado: ${estadoWA}\n` +
      `⏱️ Conectado desde: ${tiempoConectado}\n\n` +
      `📥 Último mensaje recibido: hace ${desdeUltimoMsgRecibido}\n` +
      `📤 Último envío exitoso: hace ${desdeUltimoEnvio}\n\n` +
      `🔄 *Reconexiones:*\n` +
      `  • Última hora: ${reconexionesUltimaHora}\n` +
      `  • Total desde arranque: ${waTotalReconexiones}\n\n` +
      `📊 *Envíos:*\n` +
      `  • Fallos totales: ${waEnvioFallidos}\n` +
      `  • Recuperados con reintento: ${waEnviosRetried}\n\n` +
      `📋 *Colas:*\n` +
      `  • Envío WhatsApp: ${colaEnvio}\n` +
      `  • Procesamiento: ${colaProcesamiento}\n` +
      (alertas.length > 0 ? `\n*Alertas:*\n${alertas.map(a => `  ${a}`).join("\n")}` : "")
    );
    return;
  }

  // ── Comando =grupos (solo admins) — stats por grupo, agrupado por admin ──
  if (textoLimpio === "=grupos") {
    if (!esAdmin(msg)) return;

    if (gruposAutorizados.size === 0) {
      await msg.reply("📊 No hay grupos autorizados aún.");
      return;
    }

    // Resolver nombre de admin tolerando distintos formatos de ID (@lid vs @c.us)
    const resolverNombreAdmin = (adminId) => {
      if (!adminId) return "Sin admin";
      // Búsqueda directa
      if (CONFIG.ADMIN_NOMBRES[adminId]) return CONFIG.ADMIN_NOMBRES[adminId];
      // Buscar por número base (quitar prefijo 52/521 y sufijo @c.us/@lid)
      const numBase = adminId.replace(/^(521?|)/, "").replace(/@.*$/, "");
      for (const [key, nombre] of Object.entries(CONFIG.ADMIN_NOMBRES)) {
        const keyBase = key.replace(/^(521?|)/, "").replace(/@.*$/, "");
        if (keyBase === numBase) return nombre;
      }
      return adminId; // fallback: mostrar el ID crudo
    };

    // Agrupar grupos por admin en lotes de 4 (evita rate-limit)
    const porAdmin = await resolverNombresGrupos(
      Array.from(gruposAutorizados.entries()), resolverNombreAdmin
    );
    // Agregar stats a cada grupo
    for (const grupos of porAdmin.values()) {
      for (const item of grupos) {
        item.gs = getGrupoStats(item.gId);
      }
    }

    let respuesta = "📊 *ESTADÍSTICAS POR GRUPO*\n\n";
    let totalCSF = 0;
    let totalClon = 0;
    let totalErrores = 0;
    let numGrupo = 0;

    for (const [adminNombre, grupos] of porAdmin) {
      respuesta += `👤 *${adminNombre}*\n`;
      respuesta += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;

      for (const { nombreGrupo, gs } of grupos) {
        numGrupo++;
        respuesta += `  *${numGrupo}.* ${nombreGrupo}\n`;
        respuesta += `     📄 CSF idCIF: ${gs.csf}  📋 Clon: ${gs.clon || 0}  ❌ Errores: ${gs.errores}\n`;
        totalCSF += gs.csf;
        totalClon += (gs.clon || 0);
        totalErrores += gs.errores;
      }
      respuesta += `\n`;
    }

    respuesta += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    respuesta += `📄 *Total CSF idCIF:* ${totalCSF}\n`;
    respuesta += `📋 *Total Clon:* ${totalClon}\n`;
    respuesta += `❌ *Total Errores:* ${totalErrores}\n`;
    respuesta += `👥 *Grupos activos:* ${gruposAutorizados.size}`;

    // FIX Bug #44: sección con solicitudes hechas por cada admin (independiente del grupo)
    if (statsPorAdmin.size > 0) {
      // Ordenar admins por total descendente
      const adminsOrdenados = Array.from(statsPorAdmin.entries())
        .map(([id, s]) => ({ id, ...s, total: (s.csf || 0) + (s.clon || 0) }))
        .filter(a => a.total > 0)
        .sort((a, b) => b.total - a.total);

      if (adminsOrdenados.length > 0) {
        respuesta += `\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        respuesta += `👑 *SOLICITUDES POR ADMIN*\n`;
        respuesta += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        let totalAdminCsf = 0, totalAdminClon = 0;
        for (const a of adminsOrdenados) {
          const nombre = resolverNombreAdmin(a.id);
          respuesta += `👤 *${nombre}*\n`;
          respuesta += `   📄 CSF: ${a.csf || 0}  📋 Clon: ${a.clon || 0}\n`;
          totalAdminCsf  += a.csf || 0;
          totalAdminClon += a.clon || 0;
        }
        respuesta += `\n📊 *Total admins:* ${totalAdminCsf} CSF, ${totalAdminClon} Clon`;
      }
    }

    await msg.reply(respuesta);
    return;
  }

  // ── Comando =grupos_semanal (solo admins) — stats acumuladas de la semana ──
  if (textoLimpio === "=grupos_semanal") {
    if (!esAdmin(msg)) return;

    if (gruposAutorizados.size === 0) {
      await msg.reply("📊 No hay grupos autorizados aún.");
      return;
    }

    const resolverNombreAdminSem = (adminId) => {
      if (!adminId) return "Sin admin";
      if (CONFIG.ADMIN_NOMBRES[adminId]) return CONFIG.ADMIN_NOMBRES[adminId];
      const numBase = adminId.replace(/^(521?|)/, "").replace(/@.*$/, "");
      for (const [key, nombre] of Object.entries(CONFIG.ADMIN_NOMBRES)) {
        const keyBase = key.replace(/^(521?|)/, "").replace(/@.*$/, "");
        if (keyBase === numBase) return nombre;
      }
      return adminId;
    };

    const porAdminSem = await resolverNombresGrupos(
      Array.from(gruposAutorizados.entries()), resolverNombreAdminSem
    );
    for (const grupos of porAdminSem.values()) {
      for (const item of grupos) {
        item.gs = getGrupoStatsSemanal(item.gId);
      }
    }

    let respuesta = `📊 *ESTADÍSTICAS SEMANALES* (${semanaActual()})
_Resetea cada Domingo 11:30pm CDMX_

`;
    let totalCSF = 0, totalClon = 0, totalErrores = 0, numGrupo = 0;

    for (const [adminNombre, grupos] of porAdminSem) {
      respuesta += `👤 *${adminNombre}*
`;
      respuesta += `━━━━━━━━━━━━━━━━━━━━━━━━━━
`;
      for (const { nombreGrupo, gs } of grupos) {
        numGrupo++;
        respuesta += `  *${numGrupo}.* ${nombreGrupo}
`;
        respuesta += `     📄 CSF idCIF: ${gs.csf}  📋 Clon: ${gs.clon || 0}  ❌ Errores: ${gs.errores}
`;
        totalCSF += gs.csf;
        totalClon += (gs.clon || 0);
        totalErrores += gs.errores;
      }
      respuesta += `
`;
    }

    respuesta += `━━━━━━━━━━━━━━━━━━━━━━━━━━
`;
    respuesta += `📄 *Total CSF idCIF:* ${totalCSF}
`;
    respuesta += `📋 *Total Clon:* ${totalClon}
`;
    respuesta += `❌ *Total Errores:* ${totalErrores}
`;
    respuesta += `👥 *Grupos activos:* ${gruposAutorizados.size}`;

    // FIX Bug #44: sección con solicitudes hechas por cada admin esta semana
    if (statsPorAdminSemanal.size > 0) {
      const adminsOrdenadosSem = Array.from(statsPorAdminSemanal.entries())
        .map(([id, s]) => ({ id, ...s, total: (s.csf || 0) + (s.clon || 0) }))
        .filter(a => a.total > 0)
        .sort((a, b) => b.total - a.total);

      if (adminsOrdenadosSem.length > 0) {
        respuesta += `\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        respuesta += `👑 *SOLICITUDES POR ADMIN (semana)*\n`;
        respuesta += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        let totalAdminCsfSem = 0, totalAdminClonSem = 0;
        for (const a of adminsOrdenadosSem) {
          const nombre = resolverNombreAdminSem(a.id);
          respuesta += `👤 *${nombre}*\n`;
          respuesta += `   📄 CSF: ${a.csf || 0}  📋 Clon: ${a.clon || 0}\n`;
          totalAdminCsfSem  += a.csf || 0;
          totalAdminClonSem += a.clon || 0;
        }
        respuesta += `\n📊 *Total admins semana:* ${totalAdminCsfSem} CSF, ${totalAdminClonSem} Clon`;
      }
    }

    await msg.reply(respuesta);
    return;
  }

  // ══════════════════════════════════════════════════════════════════════════════
  //  COMANDOS DE CRÉDITOS
  // ══════════════════════════════════════════════════════════════════════════════

  // ── =creditos — Ver créditos del grupo actual (todos los usuarios del grupo) ──
  if (textoLimpio === "=creditos") {
    const c = getCreditos(chatId);
    let respuesta = "💳 *Créditos del grupo*\n\n";

    // CSF
    if (!c.activo_csf) {
      respuesta += `📄 *CSF:* ⚪ Ilimitado\n`;
    } else {
      const emoji = c.creditos_csf > 10 ? "🟢" : c.creditos_csf > 0 ? "🟡" : "🔴";
      respuesta += `📄 *CSF:* ${emoji} ${c.creditos_csf} créditos\n`;
    }

    // CLON
    if (!c.activo_clon) {
      respuesta += `📋 *Clon:* ⚪ Ilimitado\n`;
    } else {
      const emoji = c.creditos_clon > 10 ? "🟢" : c.creditos_clon > 0 ? "🟡" : "🔴";
      respuesta += `📋 *Clon:* ${emoji} ${c.creditos_clon} créditos\n`;
    }

    respuesta += `\n_Cada CSF o clon exitoso descuenta 1 crédito del tipo correspondiente._\n_Los errores no cuentan._`;
    await msg.reply(respuesta);
    return;
  }

  // ── =creditos_todos — ver créditos de todos los grupos autorizados (admins) ──
  if (textoLimpio === "=creditos_todos") {
    if (!esAdmin(msg)) return;

    const grupoIds = Array.from(gruposAutorizados.keys());
    if (grupoIds.length === 0) {
      await msg.reply("📋 No hay grupos autorizados.");
      return;
    }

    let respuesta = "💳 *CRÉDITOS POR GRUPO*\n\n";

    // Obtener nombres de todos los grupos en paralelo
    const datosGrupos = await Promise.all(
      grupoIds.map(async (gId) => {
        let nombreGrupo = "(desconocido)";
        try {
          const chatGrupo = await waClient.getChatById(gId);
          nombreGrupo = chatGrupo.name || "(sin nombre)";
        } catch (e) {}
        return { gId, nombreGrupo };
      })
    );

    datosGrupos.forEach(({ gId, nombreGrupo }, idx) => {
      const c = getCreditos(gId);
      const csf = !c.activo_csf ? "⚪" : (c.creditos_csf > 10 ? `🟢 ${c.creditos_csf}` : (c.creditos_csf > 0 ? `🟡 ${c.creditos_csf}` : `🔴 0`));
      const clon = !c.activo_clon ? "⚪" : (c.creditos_clon > 10 ? `🟢 ${c.creditos_clon}` : (c.creditos_clon > 0 ? `🟡 ${c.creditos_clon}` : `🔴 0`));
      respuesta += `*${idx + 1}.* ${nombreGrupo}\n   📄 CSF: ${csf}  📋 Clon: ${clon}\n`;
    });
    respuesta += `\n💡 Usa:\n\`=agregar 100 csf 3\` (CSF al grupo 3)\n\`=agregar 50 clon 3\` (Clon al grupo 3)\n⚪ = ilimitado (desactivado)`;

    await msg.reply(respuesta);
    return;
  }

  // ── =agregar [cantidad] [tipo] [grupo#] — agregar créditos (admins) ──
  // Formatos aceptados:
  //   =agregar 100 3           → CSF por defecto
  //   =agregar 100 csf 3       → CSF explícito
  //   =agregar 50 clon 3       → CLON
  const matchAgregar = textoLimpio.match(/^=agregar\s+(\d+)(?:\s+(csf|clon))?\s+(\d+)$/i);
  if (matchAgregar) {
    if (!esAdmin(msg)) return;

    const cantidad = parseInt(matchAgregar[1], 10);
    const tipo = (matchAgregar[2] || "csf").toLowerCase();
    const numGrupo = parseInt(matchAgregar[3], 10);

    if (cantidad <= 0) {
      await msg.reply("⚠️ La cantidad debe ser mayor a 0.");
      return;
    }

    const grupoIds = Array.from(gruposAutorizados.keys());
    if (numGrupo < 1 || numGrupo > grupoIds.length) {
      await msg.reply(`⚠️ El grupo #${numGrupo} no existe.\nUsa \`=creditos_todos\` para ver los grupos disponibles.`);
      return;
    }

    const gId = grupoIds[numGrupo - 1];
    let nombreGrupo = "(desconocido)";
    try {
      const chatGrupo = await waClient.getChatById(gId);
      nombreGrupo = chatGrupo.name || "(sin nombre)";
    } catch (e) {}

    const nuevoTotal = agregarCreditos(gId, cantidad, tipo);
    const c = getCreditos(gId);
    const activo = tipo === "clon" ? c.activo_clon : c.activo_csf;
    const estadoActivo = activo ? "🟢 ACTIVO" : "⚪ DESACTIVADO (los créditos no se descuentan)";
    const tipoEmoji = tipo === "clon" ? "📋 CLON" : "📄 CSF";

    await msg.reply(`✅ *Créditos agregados*\n\n📋 Grupo: *${nombreGrupo}*\n${tipoEmoji}\n➕ Agregados: ${cantidad}\n💳 Total actual: *${nuevoTotal}*\n\nEstado: ${estadoActivo}`);
    return;
  }

  // ── =recargar [cantidad] [grupo#] — alias de =agregar csf (compatibilidad) ──
  // Formatos: =recargar 100 3 | =recargar_clon 50 3
  const matchRecargar = textoLimpio.match(/^=recargar(_clon)?\s+(\d+)\s+(\d+)$/i);
  if (matchRecargar) {
    if (!esAdmin(msg)) return;
    const esClon = !!matchRecargar[1];
    const cantidad = parseInt(matchRecargar[2], 10);
    const numGrupo = parseInt(matchRecargar[3], 10);

    if (cantidad <= 0) {
      await msg.reply("⚠️ La cantidad debe ser mayor a 0.");
      return;
    }

    const grupoIds = Array.from(gruposAutorizados.keys());
    if (numGrupo < 1 || numGrupo > grupoIds.length) {
      await msg.reply(`⚠️ El grupo #${numGrupo} no existe.\nUsa \`=creditos_todos\` para ver los grupos disponibles.`);
      return;
    }

    const gId = grupoIds[numGrupo - 1];
    let nombreGrupo = "(desconocido)";
    try {
      const chatGrupo = await waClient.getChatById(gId);
      nombreGrupo = chatGrupo.name || "(sin nombre)";
    } catch (e) {}

    const tipo = esClon ? "clon" : "csf";
    const nuevoTotal = agregarCreditos(gId, cantidad, tipo);
    const tipoEmoji = esClon ? "📋 CLON" : "📄 CSF";
    await msg.reply(`✅ *Créditos recargados*\n\n📋 Grupo: *${nombreGrupo}*\n${tipoEmoji}\n➕ Recargados: ${cantidad}\n💳 Total actual: *${nuevoTotal}*`);
    return;
  }

  // ── =quitar [cantidad] [tipo] [grupo#] — quitar créditos (admins) ──
  // Formatos: =quitar 50 3 | =quitar 50 csf 3 | =quitar 50 clon 3
  const matchQuitar = textoLimpio.match(/^=quitar\s+(\d+)(?:\s+(csf|clon))?\s+(\d+)$/i);
  if (matchQuitar) {
    if (!esAdmin(msg)) return;

    const cantidad = parseInt(matchQuitar[1], 10);
    const tipo = (matchQuitar[2] || "csf").toLowerCase();
    const numGrupo = parseInt(matchQuitar[3], 10);

    if (cantidad <= 0) {
      await msg.reply("⚠️ La cantidad debe ser mayor a 0.");
      return;
    }

    const grupoIds = Array.from(gruposAutorizados.keys());
    if (numGrupo < 1 || numGrupo > grupoIds.length) {
      await msg.reply(`⚠️ El grupo #${numGrupo} no existe.\nUsa \`=creditos_todos\` para ver los grupos disponibles.`);
      return;
    }

    const gId = grupoIds[numGrupo - 1];
    let nombreGrupo = "(desconocido)";
    try {
      const chatGrupo = await waClient.getChatById(gId);
      nombreGrupo = chatGrupo.name || "(sin nombre)";
    } catch (e) {}

    const nuevoTotal = quitarCreditos(gId, cantidad, tipo);
    const tipoEmoji = tipo === "clon" ? "📋 CLON" : "📄 CSF";
    await msg.reply(`✅ *Créditos quitados*\n\n📋 Grupo: *${nombreGrupo}*\n${tipoEmoji}\n➖ Quitados: ${cantidad}\n💳 Total actual: *${nuevoTotal}*`);
    return;
  }

  // ── =activar_creditos [tipo] [grupo#] — activar sistema (admins) ──
  // Formatos: =activar_creditos 3 | =activar_creditos csf 3 | =activar_creditos clon 3
  const matchActivar = textoLimpio.match(/^=activar_creditos(?:\s+(csf|clon|ambos))?\s+(\d+)$/i);
  if (matchActivar) {
    if (!esAdmin(msg)) return;

    const tipo = (matchActivar[1] || "ambos").toLowerCase();
    const numGrupo = parseInt(matchActivar[2], 10);
    const grupoIds = Array.from(gruposAutorizados.keys());
    if (numGrupo < 1 || numGrupo > grupoIds.length) {
      await msg.reply(`⚠️ El grupo #${numGrupo} no existe.\nUsa \`=creditos_todos\` para ver los grupos.`);
      return;
    }

    const gId = grupoIds[numGrupo - 1];
    let nombreGrupo = "(desconocido)";
    try {
      const chatGrupo = await waClient.getChatById(gId);
      nombreGrupo = chatGrupo.name || "(sin nombre)";
    } catch (e) {}

    activarCreditos(gId, tipo);
    const c = getCreditos(gId);

    let detalle = "";
    if (tipo === "ambos") detalle = `📄 CSF: ${c.creditos_csf}  📋 Clon: ${c.creditos_clon}`;
    else if (tipo === "csf") detalle = `📄 CSF: ${c.creditos_csf}`;
    else detalle = `📋 Clon: ${c.creditos_clon}`;

    const tipoTxt = tipo === "ambos" ? "CSF y CLON" : tipo.toUpperCase();
    await msg.reply(`🟢 *Sistema de créditos ACTIVADO (${tipoTxt})*\n\n📋 Grupo: *${nombreGrupo}*\n💳 ${detalle}\n\nA partir de ahora cada ${tipoTxt} exitoso descontará 1 crédito.`);
    return;
  }

  // ── =desactivar_creditos [tipo] [grupo#] — desactivar sistema (admins) ──
  const matchDesactivar = textoLimpio.match(/^=desactivar_creditos(?:\s+(csf|clon|ambos))?\s+(\d+)$/i);
  if (matchDesactivar) {
    if (!esAdmin(msg)) return;

    const tipo = (matchDesactivar[1] || "ambos").toLowerCase();
    const numGrupo = parseInt(matchDesactivar[2], 10);
    const grupoIds = Array.from(gruposAutorizados.keys());
    if (numGrupo < 1 || numGrupo > grupoIds.length) {
      await msg.reply(`⚠️ El grupo #${numGrupo} no existe.`);
      return;
    }

    const gId = grupoIds[numGrupo - 1];
    let nombreGrupo = "(desconocido)";
    try {
      const chatGrupo = await waClient.getChatById(gId);
      nombreGrupo = chatGrupo.name || "(sin nombre)";
    } catch (e) {}

    desactivarCreditos(gId, tipo);
    const tipoTxt = tipo === "ambos" ? "CSF y CLON" : tipo.toUpperCase();
    await msg.reply(`⚪ *Sistema de créditos DESACTIVADO (${tipoTxt})*\n\n📋 Grupo: *${nombreGrupo}*\n\nEl grupo puede generar ${tipoTxt} sin límite (los créditos no se descuentan).`);
    return;
  }

  // ── Comando =emision — mostrar lista de oficinas ──
  if (textoLimpio === "=emision") {
    let lista = "📍 *OFICINAS DE EMISIÓN DISPONIBLES*\n\n";
    for (let i = 0; i < OFICINAS_EMISION.length; i++) {
      lista += `*${i + 1}.* ${OFICINAS_EMISION[i]}\n`;
    }
    lista += `\n━━━━━━━━━━━━━━━━━━━━━━━━━━`;
    lista += `\n📌 *¿Cómo usarlo?*`;
    lista += `\nAgrega el número al final del comando clon:`;
    lista += `\n\n_Ejemplo:_`;
    lista += `\nclon RARH050220HVZMVMA6 *45*`;
    lista += `\n\n⚠️ Si no pones número, se usa la oficina *1* (CUAUHTEMOC, CDMX) por defecto.`;
    await msg.reply(lista);
    return;
  }

  const sender = await obtenerNombre(msg);

  // ── Comando: extraer RFC idCIF → consultar datos del SAT ──
  if (/^extraer\b/i.test(texto.trim())) {
    // Extraer RFC y idCIF del mensaje
    const partes = texto.replace(/^extraer\s*/i, "").trim().split(/\s+/);
    let rfcExtraer = null;
    let idCifExtraer = null;

    for (const p of partes) {
      const limpio = p.replace(/[^A-Z0-9]/gi, "");
      if (!rfcExtraer && /^[A-ZÑ&]{3,4}\d{6}[A-Z0-9]{2,3}$/i.test(limpio)) {
        rfcExtraer = limpio.toUpperCase();
      } else if (!idCifExtraer && /^\d{8,15}$/.test(limpio)) {
        idCifExtraer = limpio;
      }
    }

    if (!rfcExtraer || !idCifExtraer) {
      await msg.reply(`⚠️ Formato:\nextraer RFC idCIF\n_Ej:_ extraer RAAM831207TR8 21110033036`);
      return;
    }

    if (esDuplicado(rfcExtraer, "extraer")) {
      await msg.reply(`⏳ *${rfcExtraer}* ya está en proceso.`);
      return;
    }

    await msg.reply(`⏳ *Procesando solicitud...*\nCliente: *${sender}*\nRFC: ${rfcExtraer}`);

    try {
      const resultado = await extraerDatosSAT(rfcExtraer, idCifExtraer);

      if (!resultado.encontrado) {
        await msg.reply(`⚠️ *${sender}* ${resultado.mensaje}`);
        return;
      }

      // Construir mensaje con TODOS los campos (vacíos o no)
      const d = resultado.datos;
      const u = resultado.ubicacion;
      let respuesta = `📋 *Datos del SAT*\n\n`;
      respuesta += `📄 *Datos de Identificación:*\n`;
      respuesta += `• *CURP:* ${d["CURP"] || ""}\n`;
      respuesta += `• *Nombre:* ${d["Nombre"] || ""}\n`;
      respuesta += `• *Apellido Paterno:* ${d["Apellido Paterno"] || ""}\n`;
      respuesta += `• *Apellido Materno:* ${d["Apellido Materno"] || ""}\n`;
      respuesta += `• *Fecha Nacimiento:* ${d["Fecha Nacimiento"] || ""}\n`;
      respuesta += `• *Fecha de Inicio de operaciones:* ${d["Fecha de Inicio de operaciones"] || ""}\n`;
      respuesta += `• *Situación del contribuyente:* ${d["Situación del contribuyente"] || ""}\n`;
      respuesta += `• *Fecha del último cambio de situación:* ${d["Fecha del último cambio de situación"] || ""}\n`;
      respuesta += `\n📍 *Datos de Ubicación:*\n`;
      respuesta += `• *Entidad Federativa:* ${u["Entidad Federativa"] || ""}\n`;
      respuesta += `• *Municipio o delegación:* ${u["Municipio o delegación"] || ""}\n`;
      respuesta += `• *Colonia:* ${u["Colonia"] || ""}\n`;
      respuesta += `• *Tipo de vialidad:* ${u["Tipo de vialidad"] || ""}\n`;
      respuesta += `• *Nombre de la vialidad:* ${u["Nombre de la vialidad"] || ""}\n`;
      respuesta += `• *Número exterior:* ${u["Número exterior"] || ""}\n`;
      respuesta += `• *Número interior:* ${u["Número interior"] || ""}\n`;
      respuesta += `• *CP:* ${u["CP"] || ""}\n`;
      respuesta += `• *Correo electrónico:* ${u["Correo electrónico"] || ""}\n`;
      respuesta += `• *AL:* ${u["AL"] || ""}\n`;
      respuesta += `\n🏛️ *Régimen:* ${resultado.regimen || ""}\n`;
      respuesta += `📅 *Fecha de alta:* ${resultado.fechaAlta || ""}`;

      await msg.reply(respuesta);
      console.log(`📊 Extraer: ✅ ${rfcExtraer} | Datos encontrados`);

    } catch (err) {
      console.error(`❌ Error en extraer:`, err.message);
      await msg.reply(`⚠️ No se pudo consultar el SAT. Intenta de nuevo.`);
    }
    return;
  }

  // ── Comando: convertir CURP → RFC (solo texto, sin documento) ──
  // FIX Bug #43: comando deshabilitado temporalmente por bloqueo activo de gob.mx.
  // El sistema anti-bot Imperva detecta y bloquea las consultas automatizadas,
  // haciendo que el comando falle el 100% del tiempo. Se reactivará cuando se
  // tenga una alternativa estable (proxy residencial, IP nueva, o API de pago).
  if (/^convertir\b/i.test(texto.trim())) {
    await msg.reply(`⚠️ *Comando temporalmente no disponible*\n\nEl comando \`convertir\` está fuera de servicio por mantenimiento.\n\nMientras tanto puedes usar:\n• \`clon CURP\` — para generar constancia clon\n• \`clondocx CURP\` — para generar DOCX en lugar de PDF`);
    return;
  }

  // ── BLOQUE convertir ORIGINAL (deshabilitado) ────────────────────────
  if (false && /^convertir\b/i.test(texto.trim())) {
    const curpMatch = texto.match(/\b([A-Z]{4}\d{6}[HM][A-Z]{5}[A-Z0-9]\d)\b/i);
    if (!curpMatch) {
      await msg.reply(`⚠️ Formato:\nconvertir CURP\n_Ej:_ convertir RARH050220HVZMVMA6`);
      return;
    }

    const curp = curpMatch[1].toUpperCase().replace(/[^A-Z0-9]/g, "");

    // Validar estructura de la CURP antes de consultar
    const validacion = validarCURPestructura(curp);
    if (!validacion.valida) {
      await msg.reply(`❌ CURP *${curp}* inválida.\n${validacion.razon}`);
      return;
    }

    if (esDuplicado(curp, "convertir")) {
      await msg.reply(`⏳ *${curp}* ya está en proceso.`);
      return;
    }

    // Validar mayoría de edad
    const edad = calcularEdadDesdeCURP(curp);
    if (edad < 18) {
      await msg.reply(`🚫 Menor de edad (${edad} años).\nSolo se generan RFC para mayores de 18.`);
      return;
    }

    const datosGob = await consultarCURPgob(curp);
    if (!datosGob) {
      await msg.reply(`❌ CURP *${curp}* no encontrada en gob.mx.\nVerifica que esté bien escrita.`);
      return;
    }

    const datosConvertir = {
      curp,
      nombre: datosGob.nombre,
      ap1: datosGob.ap1,
      ap2: datosGob.ap2,
      sexo: datosGob.sexo,
      fecha: datosGob.fecha,
      entidad: datosGob.entidad,
    };

    // Cálculo local — no necesita cola ni YODA
    await intentarConvertirCURP({ msg, datos: datosConvertir, sender });
    return;
  }

  // ── 0. Detectar solicitud de RFC genérico (YODA) ──
  const datosCurp = parsearRFCcurp(texto);
  if (!datosCurp && /^clon(?:docx|sinobli)?\b/i.test(texto.trim())) {
    // Escribieron "clon", "clondocx" o "clonsinobli" pero no se detectó CURP válida de 18 caracteres
    await msg.reply(`⚠️ La CURP debe tener 18 caracteres.`);
    return;
  }
  if (datosCurp) {
    // Detectar si quiere DOCX sin conversión
    if (/^clondocx\b/i.test(texto.trim())) {
      datosCurp.soloDocx = true;
    }

    // Detectar si quiere variante "sin obligaciones fiscales"
    if (/^clonsinobli\b/i.test(texto.trim())) {
      datosCurp.sinObligaciones = true;
    }

    // Extraer lugar de emisión del mensaje
    // Soporta: número de oficina (ej: "45") O texto libre (ej: "TUXTLA GUTIERREZ , CHIAPAS")
    const numOficina = extraerNumeroOficina(texto);
    let nombreOficina;
    let emisionForzada = null;

    // ── Estrategia de extracción de lugar (orden de prioridad) ──
    // 1. Etiqueta explícita: "lugar: TEXTO" (cualquier capitalización)
    const lugarMatch = texto.match(/lugar\s*[:\-]\s*([^\n]+)/i);
    if (lugarMatch) {
      emisionForzada = lugarMatch[1].trim().toUpperCase();
      nombreOficina  = emisionForzada;
    }
    // 2. Número de oficina (1-84)
    else if (numOficina) {
      const idxOficina = numOficina - 1;
      nombreOficina    = OFICINAS_EMISION[idxOficina] || OFICINAS_EMISION[0];
      emisionForzada   = nombreOficina;
    }
    // 3. Texto en la misma línea que la CURP, después de ella (ej: "clon CURP pachuca , hidalgo")
    else {
      const lineaConCurp = texto.split(/\n/).find(l => /[A-Z]{4}\d{6}[HM][A-Z]{5}[A-Z0-9]\d/i.test(l));
      if (lineaConCurp) {
        const despuesDeCurp = lineaConCurp.replace(/\b[A-Z]{4}\d{6}[HM][A-Z]{5}[A-Z0-9]\d\b/gi, "")
          .replace(/^(clon(?:docx|sinobli)?)\s*/i, "").trim();
        if (despuesDeCurp.length >= 3) {
          emisionForzada = despuesDeCurp.toUpperCase();
          nombreOficina  = emisionForzada;
        }
      }
      // 4. Texto en línea siguiente a la que tiene la CURP
      if (!emisionForzada) {
        const lineas = texto.split(/\n/);
        const idxCurp = lineas.findIndex(l => /[A-Z]{4}\d{6}[HM][A-Z]{5}[A-Z0-9]\d/i.test(l));
        if (idxCurp >= 0 && idxCurp + 1 < lineas.length) {
          const siguienteLine = lineas[idxCurp + 1].trim();
          // Que no sea un campo con etiqueta (nombre:, fecha:, etc.)
          if (siguienteLine.length >= 3 && !/^(nombre|apellido|fecha|sexo|entidad|curp)\s*[:\s]/i.test(siguienteLine)) {
            emisionForzada = siguienteLine.toUpperCase();
            nombreOficina  = emisionForzada;
          }
        }
      }
      // 5. Texto libre con coma en cualquier línea (fallback anterior)
      if (!emisionForzada) {
        const libreMatch = texto.match(/([A-Za-záéíóúÁÉÍÓÚñÑ][A-Za-záéíóúÁÉÍÓÚñÑ\s]+,\s*[A-Za-záéíóúÁÉÍÓÚñÑ][A-Za-záéíóúÁÉÍÓÚñÑ\s]+)/);
        if (libreMatch) {
          const candidato = libreMatch[1].trim().toUpperCase();
          if (!candidato.match(/^[A-Z]{4}\d/)) {
            emisionForzada = candidato;
            nombreOficina  = emisionForzada;
          }
        }
      }
      if (!emisionForzada) {
        nombreOficina = null; // dejar que la API de valida-curp decida el lugar
      }
    }

    datosCurp.oficina        = nombreOficina;
    datosCurp.emisionForzada = emisionForzada; // null = usar lugar de la API

    if (esDuplicado(datosCurp.curp, "rfcgenerico")) {
      await msg.reply(`⏳ *${datosCurp.curp}* ya está en proceso.`);
      return;
    }

    // Validar estructura de la CURP antes de gastar créditos
    const validacionCurp = validarCURPestructura(datosCurp.curp);
    if (!validacionCurp.valida) {
      await msg.reply(`❌ CURP *${datosCurp.curp}* inválida.\n${validacionCurp.razon}`);
      return;
    }

    // Verificar créditos CLON ANTES de consultar la API (evita gastar API sin poder procesar)
    if (!puedeDescontarCredito(chatId, "clon")) {
      await msg.reply(`❌ Sin créditos CLON.\nContacta a un admin para recargar.`);
      return;
    }

    // Validar número de oficina si lo pusieron
    if (numOficina) {
      console.log(`📍 Oficina seleccionada: #${numOficina} → ${nombreOficina}`);
    }

    // Si no tiene datos completos y solo tiene CURP, consultar gob.mx
    if (!datosCurp.nombre && !datosCurp.ap1) {
      // Validar mayoría de edad desde la CURP
      const edad = calcularEdadDesdeCURP(datosCurp.curp);
      if (edad < 18) {
        await msg.reply(`🚫 Menor de edad (${edad} años).\nSolo se generan RFC para mayores de 18.`);
        return;
      }

      const datosGob = await consultarCURP(datosCurp.curp);
      if (!datosGob) {
        await msg.reply(`❌ CURP *${datosCurp.curp}* no encontrada en gob.mx.\n\nEnvía los datos manualmente:\n\nclon\nCURP: XXXX\nNombre: XXXX\nPrimer apellido: XXXX\nSegundo apellido: XXXX\nSexo: HOMBRE/MUJER\nFecha de nacimiento: DD/MM/AAAA\nEntidad de nacimiento: XXXX`);
        return;
      }

      // Usar los datos de gob.mx
      datosCurp.nombre = datosGob.nombre;
      datosCurp.ap1 = datosGob.ap1;
      datosCurp.ap2 = datosGob.ap2;
      datosCurp.sexo = datosGob.sexo;
      datosCurp.fecha = datosGob.fecha;
      datosCurp.entidad = datosGob.entidad;
    }

    if (!datosCurp.nombre || !datosCurp.ap1) {
      await msg.reply(`⚠️ Faltan datos. Formato:\n\nclon\nCURP: XXXX\nNombre: XXXX\nPrimer apellido: XXXX\nSegundo apellido: XXXX\nSexo: HOMBRE/MUJER\nFecha de nacimiento: DD/MM/AAAA\nEntidad de nacimiento: XXXX`);
      return;
    }

    if (contarEnGrupo(chatId) >= CONFIG.MAX_COLA) {
      await msg.reply(`⚠️ Cola llena (${CONFIG.MAX_COLA}). Espera a que terminen.`);
      return;
    }

    const posicion = cola.length + (procesando ? 1 : 0);
    if (posicion > 0) {
      await msg.reply(`⏳ En cola · posición #${posicion + 1} · ~${tiempoEspera(posicion + 1)}`);
    }

    incrementarGrupo(chatId);
    incrementarGrupoPorTipo(chatId, "clon");
    cola.push({
      chatId,
      tipo: "clon",
      fn: async () => {
        console.log(`\n📋 ${sender} → CURP:${datosCurp.curp} Nombre:${datosCurp.nombre} ${datosCurp.ap1} Oficina:${datosCurp.oficina || "auto"} (RFC genérico)`);
        await msg.reply(`⏳ *Procesando solicitud...*\nCliente: *${sender}*\n👤 ${datosCurp.nombre} ${datosCurp.ap1} ${datosCurp.ap2 || ""}${datosCurp.oficina ? `\n📍 ${datosCurp.oficina}` : ""}`);
        await intentarGenerarRFCyCurp({ msg, datos: datosCurp, sender });
      }
    });

    procesarCola();
    return;
  }

  // ── 0.5 Detectar URLs que parecen del SAT pero no son oficiales ──
  const urlFalsaSAT = texto.match(/https?:\/\/[^\s]*(?:siat|sat|validadorqr|constancia)[^\s]*/i);
  if (urlFalsaSAT && !texto.match(/https?:\/\/siat\.sat\.gob\.mx/i)) {
    console.log(`⚠️  URL no oficial detectada de ${sender}: ${urlFalsaSAT[0].substring(0, 80)}`);
    await msg.reply(`⚠️ URL se leyó, pero no arrojó información en SAT.`);
    return;
  }

  // ── 1. Detectar URL del SAT ──
  const datosURL = parsearURL(texto);
  if (datosURL) {
    const { rfc, idCif } = datosURL;
    console.log(`\n🔗 URL SAT de ${sender} → RFC:${rfc} idCIF:${idCif}`);

    if (esDuplicado(rfc, idCif)) {
      await msg.reply(`⏳ *${rfc}* ya está en proceso.`);
      return;
    }

    // Verificar créditos (si está activo el sistema en este grupo)
    if (!puedeDescontarCredito(chatId, "csf")) {
      await msg.reply(`❌ Sin créditos CSF.\nContacta a un admin para recargar.`);
      return;
    }

    if (contarEnGrupo(chatId) >= CONFIG.MAX_COLA) {
      await msg.reply(`⚠️ Cola llena (${CONFIG.MAX_COLA}). Espera a que terminen.`);
      return;
    }

    const posicion = cola.length + (procesando ? 1 : 0);
    if (posicion > 0) {
      await msg.reply(`⏳ En cola · posición #${posicion + 1} · ~${tiempoEspera(posicion + 1)}`);
    }

    incrementarGrupo(chatId);
    incrementarGrupoPorTipo(chatId, "csf");
    cola.push({
      chatId,
      tipo: "csf",
      fn: async () => {
        const t0URL = Date.now();
        console.log(`\n🔗 ${sender} → RFC:${rfc} idCIF:${idCif} (vía URL)${formatoSolicitado === "docx" ? " [DOCX]" : ""}`);
        if (posicion === 0) {
          await msg.reply(`⏳ *Procesando solicitud...*\nCliente: *${sender}*`);
        }
        await intentarGenerarYEnviar({ msg, rfc, idCif, lugar: "", sender, tiempoInicio: t0URL, formato: formatoSolicitado });
      }
    });

    procesarCola();
    return;
  }

  // ── 2. Detectar múltiples RFC + idCIF en un solo mensaje ──
  const multiples = parsearMultiples(texto);
  if (multiples && multiples.length > 1) {
    console.log(`\n📋 ${sender} → ${multiples.length} solicitudes en un mensaje`);

    // Verificar créditos CSF (si está activo)
    // IMPORTANTE: restamos solicitudes CSF ya en cola para no exceder créditos
    const credInfo = getCreditos(chatId);
    if (credInfo.activo_csf) {
      const enColaCSF = contarEnGrupoPorTipo(chatId, "csf");
      const disponibles = Math.max(0, credInfo.creditos_csf - enColaCSF);
      if (disponibles < multiples.length) {
        if (disponibles === 0) {
          await msg.reply(`❌ Sin créditos CSF disponibles.\n${enColaCSF > 0 ? `Hay ${enColaCSF} en cola que los consumirán.\n` : ""}Contacta a un admin para recargar.`);
        } else {
          await msg.reply(`⚠️ Créditos CSF insuficientes.\nNecesitas *${multiples.length}*, tienes *${disponibles}*${enColaCSF > 0 ? ` (${enColaCSF} en cola)` : ""}.\nContacta a un admin para recargar.`);
        }
        return;
      }
    }

    if (contarEnGrupo(chatId) + multiples.length > CONFIG.MAX_COLA) {
      const disponibles = Math.max(0, CONFIG.MAX_COLA - contarEnGrupo(chatId));
      await msg.reply(`⚠️ Este grupo tiene ${contarEnGrupo(chatId)} en proceso. Solo se pueden encolar ${disponibles} más.`);
      return;
    }

    await msg.reply(`📋 *${multiples.length}* solicitudes detectadas. Procesando...`);

    for (let i = 0; i < multiples.length; i++) {
      const { rfc, idCif, lugar } = multiples[i];

      if (esDuplicado(rfc, idCif)) continue;

      incrementarGrupo(chatId);
      incrementarGrupoPorTipo(chatId, "csf");
      const numActual = i + 1;
      const total = multiples.length;
      cola.push({
        chatId,
        tipo: "csf",
        fn: async () => {
          const t0Multi = Date.now();
          console.log(`\n📨 ${sender} → RFC:${rfc} idCIF:${idCif}${lugar ? ` Lugar:${lugar}` : ""} (${numActual}/${total})${formatoSolicitado === "docx" ? " [DOCX]" : ""}`);
          await msg.reply(`⏳ ${numActual}/${total}...`);
          await intentarGenerarYEnviar({ msg, rfc, idCif, lugar: lugar || "", sender, tiempoInicio: t0Multi, formato: formatoSolicitado });
        }
      });
    }

    procesarCola();
    return;
  }

  // ── 3. Parseo normal (un solo RFC + idCIF) ──
  const { rfc, idCif, lugar } = parsearMensaje(texto);
  if (!rfc || !idCif) return;

  if (esDuplicado(rfc, idCif)) {
    await msg.reply(`⏳ *${rfc}* ya está en proceso.`);
    return;
  }

  // Verificar créditos (si está activo el sistema en este grupo)
  if (!puedeDescontarCredito(chatId, "csf")) {
    await msg.reply(`❌ Sin créditos CSF.\nContacta a un admin para recargar.`);
    return;
  }

  if (contarEnGrupo(chatId) >= CONFIG.MAX_COLA) {
    await msg.reply(`⚠️ Cola llena (${CONFIG.MAX_COLA}). Espera a que terminen.`);
    return;
  }

  // posicion = número de solicitudes que van antes que esta
  // (las que ya están en la cola + 1 si hay una procesándose ahora)
  const posicion = cola.length + (procesando ? 1 : 0);

  if (posicion > 0) {
    await msg.reply(`⏳ En cola · posición #${posicion + 1} · ~${tiempoEspera(posicion + 1)}`);
  }

  incrementarGrupo(chatId);
  incrementarGrupoPorTipo(chatId, "csf");
  cola.push({
    chatId,
    tipo: "csf",
    fn: async () => {
      const t0Texto = Date.now(); // Medir desde ejecución, no desde encolado
      console.log(`\n📨 ${sender} → RFC:${rfc} idCIF:${idCif}${lugar ? ` Lugar:${lugar}` : ""}${formatoSolicitado === "docx" ? " [DOCX]" : ""}`);
      // Solo enviar confirmación si no había cola (si había, ya se avisó con la posición)
      if (posicion === 0) {
        await msg.reply(`⏳ *Procesando solicitud...*\nCliente: *${sender}*`);
      }
      await intentarGenerarYEnviar({ msg, rfc, idCif, lugar, sender, tiempoInicio: t0Texto, formato: formatoSolicitado });
    }
  });

  procesarCola();
}

// ══════════════════════════════════════════════════════════════════════════════
//  LECTURA QR — con procesamiento en lotes paralelos
// ══════════════════════════════════════════════════════════════════════════════

async function _leerQRDesdeImagenInterno(msg) {
  try {
    const media = await msg.downloadMedia();
    if (!media || !media.data) return { datos: null, error: null };

    const buffer = Buffer.from(media.data, "base64");
    const metadata = await sharp(buffer).metadata();
    console.log(`📷 Imagen recibida: ${metadata.width}x${metadata.height}`);

    // ── Helper para validar QR ──
    function procesarQRData(qrData) {
      if (!qrData || qrData.length < 5) return null;
      if (qrData.includes("siat.sat.gob.mx")) {
        try {
          const url = new URL(qrData);
          const d3 = url.searchParams.get("D3");
          if (!d3) return { tipo: "url_no_oficial", qrLeido: qrData };
          const partes = d3.split("_");
          if (partes.length < 2) return { tipo: "url_no_oficial", qrLeido: qrData };
          const idCif = partes[0]?.trim();
          const rfc   = partes.slice(1).join("_").trim().toUpperCase();
          if (!rfc || !idCif || rfc.length < 10) return { tipo: "url_no_oficial", qrLeido: qrData };
          return { tipo: "exito", datos: { rfc, idCif, lugar: "" } };
        } catch (e) { return { tipo: "url_no_oficial", qrLeido: qrData }; }
      }
      return { tipo: "url_no_oficial", qrLeido: qrData };
    }

    // ── Motores QR ──
    async function intentarZxing(raw) {
      const results = await readBarcodesFromImageData(
        { data: new Uint8ClampedArray(raw.data), width: raw.width, height: raw.height },
        { formats: ["QRCode"], tryHarder: true, tryRotate: true, tryInvert: true, tryDownscale: true }
      );
      return results?.length ? results[0].text : null;
    }

    function intentarJsQR(raw) {
      try {
        const jsQR = require("jsqr");
        const code = jsQR(new Uint8ClampedArray(raw.data), raw.width, raw.height, { inversionAttempts: "attemptBoth" });
        return code?.data || null;
      } catch (e) { return null; }
    }

    // ── ZBar: tercer motor (C nativo, distinto algoritmo que zxing/jsQR) ──
    async function intentarZbar(rawGray) {
      try {
        const results = await zbarWasm.scanGrayBuffer(rawGray.data, rawGray.width, rawGray.height);
        if (results?.length) {
          for (const r of results) {
            if (r.typeName === "ZBAR_QRCODE" || r.type === 64) {
              return r.decode();
            }
          }
        }
        return null;
      } catch (e) { return null; }
    }

    // ── Helper: sharp buffer → raw GRAYSCALE para zbar ──
    async function sharpToGray(sharpInstance) {
      const { data, info } = await sharpInstance
        .grayscale()
        .raw()
        .toBuffer({ resolveWithObject: true });
      return { data, width: info.width, height: info.height };
    }

    // ── Intentar con los 3 motores — reutiliza el buffer gray para los 3 ──
    // ZBar usa gray directamente. zxing y jsQR necesitan RGBA pero se construye
    // desde el mismo buffer gray para evitar un segundo pipeline sharp.
    async function intentarAmbos(sharpInst) {
      // Obtener grayscale una sola vez
      const { data: grayData, width, height } = await sharpToGray(sharpInst.clone());

      // ZBar — usa gray nativo
      let qr = await intentarZbar({ data: grayData, width, height });
      if (qr) return { qr, motor: "ZBar" };

      // zxing y jsQR necesitan RGBA — convertir gray a RGBA expandiendo canales
      // Más rápido que hacer un segundo pipeline sharp completo
      const rgbaData = Buffer.alloc(width * height * 4);
      for (let i = 0; i < width * height; i++) {
        const v = grayData[i];
        rgbaData[i * 4]     = v; // R
        rgbaData[i * 4 + 1] = v; // G
        rgbaData[i * 4 + 2] = v; // B
        rgbaData[i * 4 + 3] = 255; // A
      }
      const rawRGBA = { data: rgbaData, width, height };

      qr = await intentarZxing(rawRGBA);
      if (qr) return { qr, motor: "zxing" };

      qr = intentarJsQR(rawRGBA);
      if (qr) return { qr, motor: "jsQR" };

      return null;
    }

    // ── Procesar resultado QR ──
    function evaluar(resultado) {
      if (!resultado) return null;
      const qrData = typeof resultado === "string" ? resultado : resultado.qr;
      const motor = typeof resultado === "string" ? "?" : resultado.motor;
      if (!qrData) return null;
      const res = procesarQRData(qrData);
      if (res?.tipo === "exito") return { encontrado: true, resultado: res, motor };
      if (res?.tipo === "url_no_oficial") return { encontrado: true, resultado: res, motor };
      return null;
    }

    // Normalizar a max 2000px para RAM — reutilizar metadata ya leída
    let baseBuffer;
    if (metadata.width > 2000 || metadata.height > 2000) {
      baseBuffer = await sharp(buffer)
        .resize(2000, 2000, { fit: "inside", withoutEnlargement: true })
        .toBuffer();
    } else {
      baseBuffer = buffer;
    }
    // w2/h2: usar metadata original si no se redimensionó, o leer del buffer redimensionado
    let w2 = metadata.width;
    let h2 = metadata.height;
    if (metadata.width > 2000 || metadata.height > 2000) {
      const m2 = await sharp(baseBuffer).metadata();
      w2 = m2.width;
      h2 = m2.height;
    }

    // ══════════════════════════════════════════════════════════════
    //  FASE 0: intentos rápidos — imagen original + normalize (~50-150ms total)
    // ══════════════════════════════════════════════════════════════
    const fase0 = [
      () => sharp(baseBuffer),                                          // sin transformar
      () => sharp(baseBuffer).grayscale().normalize(),                  // normalizar contraste
      () => sharp(baseBuffer).grayscale().threshold(128),               // binario rápido
      () => sharp(baseBuffer).flatten({ background: "#ffffff" }).grayscale(), // si PNG con alfa
    ];
    for (const fn of fase0) {
      try {
        const qr = await intentarAmbos(fn());
        const r = evaluar(qr);
        if (r) {
          console.log(`📷 QR ${r.resultado.tipo === "exito" ? "SAT" : "no-oficial"} detectado (fase 0 rápido · ${r.motor})`);
          return r.resultado.tipo === "exito"
            ? { datos: r.resultado.datos, error: null }
            : { datos: null, error: "url_no_oficial" };
        }
      } catch (e) {}
    }

    // ══════════════════════════════════════════════════════════════
    //  FASE 0b: rotaciones — foto tomada de lado o invertida
    //  WhatsApp puede llegar sin EXIF correcto → QR rotado
    // ══════════════════════════════════════════════════════════════
    for (const angulo of [90, 270, 180]) {
      try {
        const rotado = await sharp(baseBuffer).rotate(angulo).toBuffer();
        const qr = await intentarAmbos(sharp(rotado));
        const r = evaluar(qr);
        if (r) {
          console.log(`📷 QR ${r.resultado.tipo === "exito" ? "SAT" : "no-oficial"} detectado (fase 0b rot${angulo}° · ${r.motor})`);
          return r.resultado.tipo === "exito"
            ? { datos: r.resultado.datos, error: null }
            : { datos: null, error: "url_no_oficial" };
        }
      } catch (e) {}
    }

    // Yield al event loop antes de fase 1 — permite que Baileys responda
    // su keep-alive y procese otros mensajes en cola mientras seguimos.
    await new Promise(r => setImmediate(r));

    // ══════════════════════════════════════════════════════════════
    //  FASE 1: variaciones de imagen con sharp (reducido a las más efectivas)
    //  Antes 33 variaciones — ahora 14. Las eliminadas casi nunca detectaban
    //  QRs que las restantes no detectaran también (verificado con logs reales).
    // ══════════════════════════════════════════════════════════════
    const variaciones = [
      // Contraste lineal (cubre fotos con poca luz / saturadas)
      () => sharp(baseBuffer).grayscale().linear(2.0, -50),
      () => sharp(baseBuffer).grayscale().linear(2.5, -80),
      // Sharpen real (fotos ligeramente borrosas)
      () => sharp(baseBuffer).grayscale().sharpen({ sigma: 2, m1: 1.5, m2: 0.7 }),
      () => sharp(baseBuffer).grayscale().sharpen({ sigma: 3, m1: 2.0, m2: 1.0 }),
      // Threshold binario
      () => sharp(baseBuffer).grayscale().threshold(100),
      () => sharp(baseBuffer).grayscale().threshold(160),
      // Brillo (fotos oscuras de WhatsApp)
      () => sharp(baseBuffer).grayscale().modulate({ brightness: 1.3 }).linear(1.5, -20),
      // Negar (QR invertido — fondo oscuro)
      () => sharp(baseBuffer).grayscale().negate(),
      // Escalar x2 + sharpen (QR pequeños)
      () => sharp(baseBuffer).resize(w2 * 2, h2 * 2, { kernel: "lanczos3" }).grayscale().sharpen({ sigma: 2 }),
      () => sharp(baseBuffer).resize(w2 * 2, h2 * 2, { kernel: "lanczos3" }).grayscale().threshold(128),
      // Sharpen + threshold (fotos muy borrosas)
      () => sharp(baseBuffer).grayscale().sharpen({ sigma: 3, m1: 2.5, m2: 1.5 }).threshold(128),
      // Normalización (rango de colores comprimido)
      () => sharp(baseBuffer).grayscale().normalize().sharpen({ sigma: 2 }),
      // Median filter (ruido sal y pimienta)
      () => sharp(baseBuffer).grayscale().median(3).threshold(128),
      // Anti-moiré para fotos de pantallas
      () => sharp(baseBuffer).grayscale().blur(1).sharpen({ sigma: 3, m1: 2 }),
    ];

    // Probar variaciones en lotes paralelos (CONCURRENCY_QR = 6)
    const BATCH = CONFIG.CONCURRENCY_QR;
    for (let b = 0; b < variaciones.length; b += BATCH) {
      const lote = variaciones.slice(b, b + BATCH);
      const resultados = await Promise.allSettled(
        lote.map(async (fn) => {
          try {
            const qr = await intentarAmbos(fn());
            return evaluar(qr);
          } catch (e) { return null; }
        })
      );
      for (const res of resultados) {
        if (res.status === "fulfilled" && res.value?.encontrado) {
          const r = res.value.resultado;
          console.log(`📷 QR ${r.tipo === "exito" ? "SAT" : "no-oficial"} detectado (fase 1 · ${res.value.motor})`);
          return r.tipo === "exito"
            ? { datos: r.datos, error: null }
            : { datos: null, error: "url_no_oficial" };
        }
      }
      // Yield entre lotes para no bloquear el event loop
      await new Promise(r => setImmediate(r));
    }

    // ══════════════════════════════════════════════════════════════
    //  FASE 2: zonas de crop (reducido de 10 a 4 zonas más probables)
    //  Las CSF tienen el QR en la esquina superior izquierda o mitad superior.
    // ══════════════════════════════════════════════════════════════
    const zonas = [
      { left: 0, top: 0, width: Math.floor(w2 * 0.55), height: Math.floor(h2 * 0.55) },
      { left: 0, top: 0, width: w2, height: Math.floor(h2 * 0.5) },
      { left: Math.floor(w2 * 0.1), top: Math.floor(h2 * 0.05), width: Math.floor(w2 * 0.8), height: Math.floor(h2 * 0.5) },
      { left: 0, top: 0, width: Math.floor(w2 * 0.4), height: Math.floor(h2 * 0.45) },
    ];

    // Procesar zonas en paralelo, pero con menos variaciones por zona (4 en vez de 8)
    const zonaResults = await Promise.allSettled(
      zonas
        .filter(zona => zona.width >= 50 && zona.height >= 50)
        .map(async (zona) => {
          try {
            const cropped = await sharp(baseBuffer).extract(zona).toBuffer();
            const cropVariaciones = [
              () => sharp(cropped).grayscale().sharpen({ sigma: 2 }),
              () => sharp(cropped).grayscale().threshold(128),
              () => sharp(cropped).grayscale().linear(2.0, -50),
              () => sharp(cropped).resize({ width: zona.width * 2, kernel: "lanczos3" }).grayscale().sharpen({ sigma: 2 }),
            ];
            const subResults = await Promise.allSettled(
              cropVariaciones.map(async (fn) => {
                try { return evaluar(await intentarAmbos(fn())); } catch (e) { return null; }
              })
            );
            for (const sub of subResults) {
              if (sub.status === "fulfilled" && sub.value?.encontrado) return sub.value;
            }
          } catch (e) {}
          return null;
        })
    );

    for (const res of zonaResults) {
      if (res.status === "fulfilled" && res.value?.encontrado) {
        const r = res.value.resultado;
        console.log(`📷 QR ${r.tipo === "exito" ? "SAT" : "no-oficial"} detectado (fase 2 crop · ${res.value.motor})`);
        return r.tipo === "exito"
          ? { datos: r.datos, error: null }
          : { datos: null, error: "url_no_oficial" };
      }
    }

    // Yield antes de fase 3
    await new Promise(r => setImmediate(r));

    // ══════════════════════════════════════════════════════════════
    //  FASE 3: escalas último recurso (reducido de 7 a 3 escalas)
    //  Las escalas 0.3x, 4x, 5x casi nunca aciertan si las x2-x3 fallaron.
    // ══════════════════════════════════════════════════════════════
    const escalas = [0.5, 1.5, 2.5];
    const escalaResults = await Promise.allSettled(
      escalas.map(async (escala) => {
        try {
          const w = Math.round(w2 * escala);
          const h = Math.round(h2 * escala);
          if (w < 50 || h < 50 || w > 8000 || h > 8000) return null;
          const intentos = [
            () => sharp(baseBuffer).resize(w, h, { kernel: "lanczos3" }).grayscale().sharpen({ sigma: 2 }),
            () => sharp(baseBuffer).resize(w, h, { kernel: "lanczos3" }).grayscale().threshold(128),
          ];
          for (const fn of intentos) {
            const r = evaluar(await intentarAmbos(fn()));
            if (r?.encontrado) return { ...r, escala };
          }
        } catch (e) {}
        return null;
      })
    );

    for (const res of escalaResults) {
      if (res.status === "fulfilled" && res.value?.encontrado) {
        const r = res.value.resultado;
        console.log(`📷 QR ${r.tipo === "exito" ? "SAT" : "no-oficial"} detectado (fase 3 escala ${res.value.escala}x · ${res.value.motor})`);
        return r.tipo === "exito"
          ? { datos: r.datos, error: null }
          : { datos: null, error: "url_no_oficial" };
      }
    }

    return { datos: null, error: "no_reconocido" };
  } catch (err) {
    console.error("❌ Error leyendo QR:", err.message);
    return { datos: null, error: "no_reconocido" };
  }
}

// ── Wrapper con timeout global de 12s ─────────────────────────────────────────
// Antes leerQRDesdeImagen podía tardar 30-90s con QR ilegibles, bloqueando
// el event loop y causando que Baileys se desconectara (sin poder enviar
// keep-alive) y que mensajes posteriores no se procesaran.
// 12s es suficiente para que las fases 0-2 corran completas en un VPS 2vCPU;
// si no se detectó en 12s, el QR es irrecuperable y se devuelve error.
async function leerQRDesdeImagen(msg) {
  const t0 = Date.now();
  const TIMEOUT_QR_MS = 12000;
  try {
    const resultado = await Promise.race([
      _leerQRDesdeImagenInterno(msg),
      new Promise((resolve) => setTimeout(() => {
        resolve({ datos: null, error: "no_reconocido", timeout: true });
      }, TIMEOUT_QR_MS)),
    ]);
    const ms = Date.now() - t0;
    if (resultado.timeout) {
      console.warn(`⏱️  Lectura QR abortada por timeout (${ms}ms) — QR ilegible`);
    } else if (ms > 5000) {
      console.log(`📷 Lectura QR completada en ${ms}ms (resultado: ${resultado.error || "ok"})`);
    }
    return { datos: resultado.datos, error: resultado.error, timeout: resultado.timeout || false };
  } catch (err) {
    console.error(`❌ Error fatal leyendo QR (${Date.now() - t0}ms):`, err.message);
    return { datos: null, error: "no_reconocido" };
  }
}

// ── Handler de imágenes/QR ────────────────────────────────────────────────────
async function manejarImagen(msg, chat) {
  if (!msg.hasMedia) return;
  if (!["image"].includes(msg.type)) return;

  if (!chat.isGroup) return;

  // Verificar grupo autorizado
  const chatId = chat.id._serialized;
  if (!grupoAutorizado(chatId)) return;

  // Verificar horario de servicio — admins bypass igual que en texto
  if (!estaEnHorario() && !esAdmin(msg)) return;

  // Detectar formato DOCX en el caption de la imagen
  let formatoSolicitado = "pdf";
  const captionMsg = msg.body || "";
  if (/\bdocx\b/i.test(captionMsg)) {
    formatoSolicitado = "docx";
  }

  const sender = await obtenerNombre(msg);
  const { datos, error, timeout } = await leerQRDesdeImagen(msg);

  if (error === "no_reconocido") {
    // Quitar "docx" del caption antes de parsear (evita que acabe como lugar de emisión)
    const captionTexto = (msg.body || "").replace(/\bdocx\b/gi, " ").replace(/\s+/g, " ").trim();

    // Intentar parsear RFC+idCIF del caption antes de rendirse
    const datosCaption = parsearMensaje(captionTexto);
    if (datosCaption && datosCaption.rfc && datosCaption.idCif) {
      console.log(`📎 QR no legible, pero caption tiene datos: RFC=${datosCaption.rfc} idCIF=${datosCaption.idCif}`);

      if (esDuplicado(datosCaption.rfc, datosCaption.idCif)) {
        await msg.reply(`⏳ *${datosCaption.rfc}* ya está en proceso.`);
        return;
      }

      if (!puedeDescontarCredito(chatId, "csf")) {
        await msg.reply(`❌ Sin créditos CSF.\nContacta a un admin para recargar.`);
        return;
      }

      if (contarEnGrupo(chatId) >= CONFIG.MAX_COLA) {
        await msg.reply(`⚠️ Cola llena (${CONFIG.MAX_COLA}). Espera a que terminen.`);
        return;
      }

      const posicionCap = cola.length + (procesando ? 1 : 0);
      if (posicionCap > 0) {
        await msg.reply(`⏳ En cola · posición #${posicionCap + 1} · ~${tiempoEspera(posicionCap + 1)}`);
      }

      incrementarGrupo(chatId);
      incrementarGrupoPorTipo(chatId, "csf");
      cola.push({
        chatId,
        tipo: "csf",
        fn: async () => {
          const t0Cap = Date.now();
          console.log(`\n📎 ${sender} → RFC:${datosCaption.rfc} idCIF:${datosCaption.idCif} (vía caption, QR no legible)${formatoSolicitado === "docx" ? " [DOCX]" : ""}`);
          if (posicionCap === 0) {
            await msg.reply(`⏳ *Procesando solicitud...*\nCliente: *${sender}*`);
          }
          await intentarGenerarYEnviar({ msg, rfc: datosCaption.rfc, idCif: datosCaption.idCif, lugar: datosCaption.lugar || "", sender, tiempoInicio: t0Cap, formato: formatoSolicitado });
        }
      });
      procesarCola();
      return;
    }

    // Si HUBO TIMEOUT (se gastaron los 12s intentando leer), significa que SÍ
    // había un QR pero estaba demasiado borroso. Avisar siempre en ese caso.
    if (timeout) {
      await msg.reply(
        `❌ *No pude leer el QR de la imagen.*\n` +
        `La imagen está borrosa o el QR no es legible.\n\n` +
        `📸 *Manda la foto más clara*, o\n` +
        `✍️ *Escribe los datos manualmente:* \`RFC idCIF\``
      );
      return;
    }

    // Si NO hubo timeout (no se detectó nada de QR en la imagen) y el caption
    // sugiere que era una constancia, avisar también. Si no, callar para no
    // spamear con avisos cuando alguien manda fotos no relacionadas.
    const caption = captionTexto.toLowerCase();
    const pareceConstancia = caption.includes("rfc") || caption.includes("constancia") || caption.includes("cif") || caption.includes("sat");
    if (pareceConstancia) {
      await msg.reply(`❌ No pude leer el QR.\nEscribe los datos: *RFC idCIF*`);
    }
    return;
  }

  if (error === "url_no_oficial") {
    await msg.reply(`⚠️ QR se leyó, pero no arrojó información en SAT.`);
    return;
  }

  if (!datos) return;

  const { rfc, idCif } = datos;

  // ── Leer emisión/lugar desde el caption de la imagen ──
  // Quitar la palabra "docx" del caption antes de usarlo como lugar
  const caption = (msg.body || "").trim().replace(/\bdocx\b/gi, "").replace(/\s+/g, " ").trim();
  let lugar = "";
  if (caption && caption.length > 2 && caption.length < 100) {
    // Si el caption no es un RFC ni un número, asumirlo como lugar de emisión
    const esRFC = esRFCvalido(caption);
    const esNumero = /^\d+$/.test(caption);
    if (!esRFC && !esNumero) {
      lugar = caption.toUpperCase();
      console.log(`📍 Emisión desde caption: ${lugar}`);
    }
  }

  console.log(`\n📷 QR escaneado de ${sender} → RFC:${rfc} idCIF:${idCif}${lugar ? ` Lugar:${lugar}` : ""}`);

  if (esDuplicado(rfc, idCif)) {
    await msg.reply(`⏳ *${rfc}* ya está en proceso.`);
    return;
  }

  // Verificar créditos (si está activo el sistema en este grupo)
  if (!puedeDescontarCredito(chatId, "csf")) {
    await msg.reply(`❌ Sin créditos CSF.\nContacta a un admin para recargar.`);
    return;
  }

  if (contarEnGrupo(chatId) >= CONFIG.MAX_COLA) {
    await msg.reply(`⚠️ Cola llena (${CONFIG.MAX_COLA}). Espera a que terminen.`);
    return;
  }

  const posicion = cola.length + (procesando ? 1 : 0);
  if (posicion > 0) {
    await msg.reply(`⏳ En cola · posición #${posicion + 1} · ~${tiempoEspera(posicion + 1)}`);
  }

  incrementarGrupo(chatId);
  incrementarGrupoPorTipo(chatId, "csf");
  cola.push({
    chatId,
    tipo: "csf",
    fn: async () => {
      const t0QR = Date.now();
      console.log(`\n📨 ${sender} → RFC:${rfc} idCIF:${idCif}${lugar ? ` Lugar:${lugar}` : ""} (vía QR)${formatoSolicitado === "docx" ? " [DOCX]" : ""}`);
      if (posicion === 0) {
        await msg.reply(`⏳ *Procesando solicitud...*\nCliente: *${sender}*`);
      }
      await intentarGenerarYEnviar({ msg, rfc, idCif, lugar, sender, tiempoInicio: t0QR, formato: formatoSolicitado });
    }
  });

  procesarCola();
}

