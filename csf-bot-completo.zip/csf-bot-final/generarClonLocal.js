// ── Generador local de constancia clon ──────────────────────────────────────
// Flujo: CURP → API valida-curp → datos reales → RFC generado → DOCX
// Uso:   generarConstanciaLocal({ curp, token, downloadDir })

const { execFile } = require("child_process");
const path = require("path");
const fs   = require("fs");
const http  = require("http");
const https = require("https");
// FIX Bug #55: cliente OnlyOffice unificado. Antes este archivo tenía 3
// funciones (convertirDocxAPdfOnlyOffice, registrarArchivoTemporal,
// descargarArchivo) que divergieron de la versión en generarCSFLocal.js.
// El parser era más estricto (exigía endConvert===true) y fallaba cuando
// OnlyOffice cacheaba la conversión y devolvía solo fileUrl. Ahora ambos
// archivos usan onlyofficeClient.js, que tolera ambos formatos y JSON+XML.
const { convertirDocxAPdf } = require("./onlyofficeClient");

// ── Tabla de municipios capital por entidad (para emision) ──────────────────
// Se usa cuando MunicipioRegistro viene null en la API
const CAPITAL_POR_ENTIDAD = {
  AS: "AGUASCALIENTES",   BC: "MEXICALI",          BS: "LA PAZ",
  CC: "CAMPECHE",         CL: "SALTILLO",           CM: "COLIMA",
  CS: "TUXTLA GUTIERREZ", CH: "CHIHUAHUA",          DF: "CIUDAD DE MEXICO",
  DG: "DURANGO",          GT: "GUANAJUATO",         GR: "CHILPANCINGO",
  HG: "PACHUCA",          JC: "GUADALAJARA",        MC: "TOLUCA",
  MN: "MORELIA",          MS: "CUERNAVACA",         NT: "TEPIC",
  NL: "MONTERREY",        OC: "OAXACA",             PL: "PUEBLA",
  QT: "QUERETARO",        QR: "CHETUMAL",           SP: "SAN LUIS POTOSI",
  SL: "CULIACAN",         SR: "HERMOSILLO",         TC: "VILLAHERMOSA",
  TS: "CIUDAD VICTORIA",  TL: "TLAXCALA",           VZ: "XALAPA",
  YN: "MERIDA",           ZS: "ZACATECAS",          NE: "GUADALAJARA",
};

const ENTIDAD_NOMBRE = {
  AS: "AGUASCALIENTES",      BC: "BAJA CALIFORNIA",       BS: "BAJA CALIFORNIA SUR",
  CC: "CAMPECHE",            CL: "COAHUILA DE ZARAGOZA",  CM: "COLIMA",
  CS: "CHIAPAS",             CH: "CHIHUAHUA",             DF: "CIUDAD DE MEXICO",
  DG: "DURANGO",             GT: "GUANAJUATO",            GR: "GUERRERO",
  HG: "HIDALGO",             JC: "JALISCO",               MC: "ESTADO DE MEXICO",
  MN: "MICHOACAN DE OCAMPO", MS: "MORELOS",               NT: "NAYARIT",
  NL: "NUEVO LEON",          OC: "OAXACA",                PL: "PUEBLA",
  QT: "QUERETARO",           QR: "QUINTANA ROO",          SP: "SAN LUIS POTOSI",
  SL: "SINALOA",             SR: "SONORA",                TC: "TABASCO",
  TS: "TAMAULIPAS",          TL: "TLAXCALA",              VZ: "VERACRUZ DE IGNACIO DE LA LLAVE",
  YN: "YUCATAN",             ZS: "ZACATECAS",             NE: "JALISCO",
};

// ── Mapa de texto libre de la API → código de entidad ────────────────────────
const ENTIDAD_TEXTO_A_CODIGO = {
  "AGUASCALIENTES": "AS", "BAJA CALIFORNIA": "BC", "BAJA CALIFORNIA SUR": "BS",
  "CAMPECHE": "CC", "COAHUILA": "CL", "COAHUILA DE ZARAGOZA": "CL", "COLIMA": "CM",
  "CHIAPAS": "CS", "CHIHUAHUA": "CH",
  "CIUDAD DE MEXICO": "DF", "DISTRITO FEDERAL": "DF", "CDMX": "DF",
  "DURANGO": "DG", "GUANAJUATO": "GT", "GUERRERO": "GR", "HIDALGO": "HG",
  "JALISCO": "JC",
  "MEXICO": "MC", "ESTADO DE MEXICO": "MC", "EDO DE MEXICO": "MC",
  "EDO. DE MEXICO": "MC", "ESTADO DE MEX": "MC",
  "MICHOACAN": "MN", "MICHOACAN DE OCAMPO": "MN",
  "MORELOS": "MS", "NAYARIT": "NT", "NUEVO LEON": "NL", "OAXACA": "OC",
  "PUEBLA": "PL", "QUERETARO": "QT", "QUINTANA ROO": "QR",
  "SAN LUIS POTOSI": "SP", "SINALOA": "SL", "SONORA": "SR", "TABASCO": "TC",
  "TAMAULIPAS": "TS", "TLAXCALA": "TL",
  "VERACRUZ": "VZ", "VERACRUZ DE IGNACIO DE LA LLAVE": "VZ",
  "YUCATAN": "YN", "ZACATECAS": "ZS",
  "NACIDO EN EL EXTRANJERO": "NE", "EXTRANJERO": "NE",
};

// ── Normalizar texto a mayúsculas sin tildes ─────────────────────────────────
// IMPORTANTE: preservamos Ñ y Ç porque son letras propias del español/portugués,
// no vocales con diacrítico. Sin esta protección, "PIÑA" se convertiría en "PINA"
// y "GARCIA-CALÇADA" en "GARCIA-CALCADA".
function normalizar(s) {
  return (s || "").toUpperCase()
    .replace(/Ñ/g, "\u0001").replace(/Ç/g, "\u0002")    // Protege letras especiales
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/\u0001/g, "Ñ").replace(/\u0002/g, "Ç")    // Restaura letras
    .trim();
}

// Mapeo número INEGI → clave RENAPO
const INEGI_A_CODIGO = {
  1:"AS",  2:"BC",  3:"BS",  4:"CC",  5:"CL",  6:"CM",  7:"CS",  8:"CH",  9:"DF",
  10:"DG", 11:"GT", 12:"GR", 13:"HG", 14:"JC", 15:"MC", 16:"MN", 17:"MS", 18:"NT",
  19:"NL", 20:"OC", 21:"PL", 22:"QT", 23:"QR", 24:"SP", 25:"SL", 26:"SR", 27:"TC",
  28:"TS", 29:"TL", 30:"VZ", 31:"YN", 32:"ZS",
};

// ── Resolver código de entidad desde clave o texto libre ─────────────────────
function resolverEntidad(clave, textoLibre, curp) {
  // 1. Si viene como número INEGI (1-32), convertir
  if (typeof clave === "number" || /^\d+$/.test(String(clave || "").trim())) {
    const num = parseInt(clave, 10);
    if (INEGI_A_CODIGO[num]) return INEGI_A_CODIGO[num];
  }

  // 2. Intentar por clave directa (ej: "CS")
  const claveUp = String(clave || "").toUpperCase().trim();
  if (ENTIDAD_NOMBRE[claveUp]) return claveUp;

  // 3. Intentar por texto libre normalizado
  const texto = normalizar(textoLibre || "");
  if (ENTIDAD_TEXTO_A_CODIGO[texto]) return ENTIDAD_TEXTO_A_CODIGO[texto];

  // 4. Búsqueda parcial
  for (const [key, cod] of Object.entries(ENTIDAD_TEXTO_A_CODIGO)) {
    if (texto && (texto.includes(key) || key.includes(texto))) return cod;
  }

  // 5. Fallback: extraer entidad de la propia CURP (posiciones 11-12)
  if (curp && curp.length === 18) {
    const claveCURP = curp.substring(11, 13).toUpperCase();
    if (ENTIDAD_NOMBRE[claveCURP]) return claveCURP;
  }

  return null; // sin fallback aquí — el caller decide
}

// ── Petición HTTPS simple con timeout ───────────────────────────────────────
function fetchJSON(url, timeoutMs = 15000) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, (res) => {
      // FIX: validar statusCode antes de parsear. Si el servidor responde 5xx,
      // antes intentábamos parsear HTML/texto como JSON y daba "JSON inválido"
      // que era confuso. Ahora damos un error claro con el código HTTP.
      if (res.statusCode < 200 || res.statusCode >= 300) {
        res.resume(); // descartar body
        return reject(new Error(`HTTP ${res.statusCode} de ${new URL(url).hostname}`));
      }
      let data = "";
      res.on("data", (chunk) => (data += chunk));
      res.on("end", () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { reject(new Error(`JSON inválido: ${data.slice(0, 200)}`)); }
      });
    });
    req.on("error", reject);
    req.setTimeout(timeoutMs, () => {
      req.destroy();
      reject(new Error(`API timeout (${timeoutMs}ms)`));
    });
  });
}

// ── Generador de RFC (algoritmo oficial SAT — IFAI 0610100135506) ─────────────
function generarRFC(nombre, ap1, ap2, fechaNac) {
  const INCONVENIENTES = new Set(["BACA","BAKA","BUEI","BUEY","CACA","CACO","CAGA","CAGO",
    "CAKA","CAKO","COGE","COGI","COJA","COJE","COJI","COJO","COLA","CULO","FALO",
    "FETO","GETA","GUEI","GUEY","JETA","JOTO","KACA","KACO","KAGA","KAGO","KAKA",
    "KAKO","KOGE","KOGI","KOJA","KOJE","KOJI","KOJO","KOLA","KULO","LILO","LOCA",
    "LOCO","LOKA","LOKO","MAME","MAMO","MEAR","MEAS","MEON","MIAR","MION","MOCO",
    "MOKO","MULA","MULO","NACA","NACO","PEDA","PEDO","PENE","PIPI","PITO","POPO",
    "PUTA","PUTO","QULO","RATA","ROBA","ROBE","ROBO","RUIN","SENO","TETA","VACA",
    "VAGA","VAGO","VAKA","VUEI","VUEY","WUEI","WUEY"]);

  const ARTICULOS    = ["DE","LA","LAS","MC","VON","DEL","LOS","Y","MAC","VAN","MI"];
  const GENERICOS    = ["JOSE","MARIA","MA","J"];

  // Tabla SAT para conversión a numérico (homoclave)
  const TABLA_HC = {
    " ":"00","0":"00","1":"01","2":"02","3":"03","4":"04","5":"05","6":"06","7":"07","8":"08","9":"09",
    "&":"10","A":"11","B":"12","C":"13","D":"14","E":"15","F":"16","G":"17","H":"18","I":"19","J":"21",
    "K":"22","L":"23","M":"24","N":"25","O":"26","P":"27","Q":"28","R":"29","S":"32","T":"33","U":"34",
    "V":"35","W":"36","X":"37","Y":"38","Z":"39","Ñ":"40",
  };
  const LETRAS_HC = "123456789ABCDEFGHIJKLMNPQRSTUVWXYZ";

  // Tabla dígito verificador
  const TABLA_DV = {
    "0":"00","1":"01","2":"02","3":"03","4":"04","5":"05","6":"06","7":"07","8":"08","9":"09",
    "A":"10","B":"11","C":"12","D":"13","E":"14","F":"15","G":"16","H":"17","I":"18","J":"19",
    "K":"20","L":"21","M":"22","N":"23","&":"24","O":"25","P":"26","Q":"27","R":"28","S":"29",
    "T":"30","U":"31","V":"32","W":"33","X":"34","Y":"35","Z":"36"," ":"37","Ñ":"38",
  };

  // Limpiar para las 4 letras+fecha (sin Ñ)
  const limpiar = (s) => (s || "").toUpperCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/Ñ/g, "X").replace(/[^A-Z\s]/g, "").trim();

  // Limpiar para homoclave (conservar Ñ y &)
  const limpiarHC = (s) => (s || "").toUpperCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^A-ZÑ&\s]/g, "").trim();

  const quitarArticulos = (s) => s.split(/\s+/).filter(w => !ARTICULOS.includes(w)).join(" ").trim();

  // Nombre sin genéricos (JOSE, MARIA, etc.)
  const sinGenericos = (s) => {
    const p = s.split(/\s+/);
    return (p.length > 1 && GENERICOS.includes(p[0])) ? p.slice(1).join(" ") : s;
  };

  const N  = limpiar(sinGenericos(limpiar(nombre)));
  const A1 = quitarArticulos(limpiar(ap1));
  const A2 = quitarArticulos(limpiar(ap2 || ""));

  // ── 4 letras ──
  let letras;
  if (A1 && A2) {
    const vocal = A1.slice(1).match(/[AEIOU]/)?.[0] || "X";
    letras = A1[0] + vocal + A2[0] + (N[0] || "X");
  } else if (A1 && !A2) {
    letras = A1.slice(0, 2).padEnd(2, "X") + N.slice(0, 2).padEnd(2, "X");
  } else if (!A1 && A2) {
    letras = A2.slice(0, 2).padEnd(2, "X") + N.slice(0, 2).padEnd(2, "X");
  } else {
    letras = N.slice(0, 4).padEnd(4, "X");
  }
  letras = letras.padEnd(4, "X").slice(0, 4);
  if (INCONVENIENTES.has(letras)) letras = letras.slice(0, 3) + "X";

  // ── Fecha ──
  const [dd, mm, yyyy] = fechaNac.split("/");
  const fecha = yyyy.slice(2) + mm.padStart(2,"0") + dd.padStart(2,"0");
  const rfc10 = letras + fecha;

  // ── Homoclave (2 chars) — algoritmo oficial SAT ──
  const NC1 = limpiarHC(ap1);
  const NC2 = limpiarHC(ap2 || "");
  const NC3 = limpiarHC(nombre);
  const nombreCompleto = [NC1, NC2, NC3].filter(s => s).join(" ");
  const cadena = " " + nombreCompleto;

  let numerico = "";
  for (const c of cadena) numerico += TABLA_HC[c] || "00";

  let suma = 0;
  for (let i = 0; i < numerico.length - 1; i++) {
    const par = parseInt(numerico.substr(i, 2), 10);
    const sig = parseInt(numerico[i + 1], 10);
    suma += par * sig;
  }
  const u3 = suma % 1000;
  const hc = LETRAS_HC[Math.floor(u3 / 34)] + LETRAS_HC[u3 % 34];

  // ── Dígito verificador ──
  const rfc12 = rfc10 + hc;
  let sumaDV = 0;
  for (let i = 0; i < rfc12.length; i++) {
    sumaDV += parseInt(TABLA_DV[rfc12[i]] || "00", 10) * (13 - i);
  }
  const r = sumaDV % 11;
  const dv = r === 0 ? "0" : (11 - r === 10 ? "A" : String(11 - r));

  return rfc12 + dv;
}

// ── Llamada al script Python ─────────────────────────────────────────────────
function llamarPython(datos) {
  return new Promise((resolve, reject) => {
    const script    = path.join(__dirname, "generar_clon.py");
    const plantilla = path.join(
      __dirname,
      datos.sinObligaciones
        ? "plantilla_clonsinobli_template.docx"
        : "plantilla_clon_template.docx"
    );
    const payload   = JSON.stringify({ ...datos, plantilla });

    execFile("python3", [script, payload], {
      // FIX Bug #34: timeout 20s era muy ajustado. SEPOMEX local resuelve en <10ms,
      // pero el resto del proceso (QR + barcode + XML + zip + render OnlyOffice)
      // puede tardar varios segundos. 45s da margen sin afectar al watchdog global de 120s.
      timeout: 45000,
      maxBuffer: 10 * 1024 * 1024, // 10 MB por si el stdout/stderr crecen
      env: {
        ...process.env,
        QR_BASE_URL:      process.env.QR_BASE_URL      || "https://siat-sat.site",
        QR_VALIDADOR_URL: process.env.QR_VALIDADOR_URL || "https://validador.siat-sat.site",
      }
    }, (err, stdout, stderr) => {
      // Loguear stderr de Python (incluye logs de SEPOMEX)
      if (stderr && stderr.trim()) {
        console.log(`   ${stderr.trim().split("\n").map(l => l.trim()).filter(Boolean).join("\n   ")}`);
      }
      if (err) {
        // FIX Bug #35: dar contexto útil del error en lugar de solo "Command failed".
        // Distinguir timeout (signal SIGTERM tras 45s) vs crash vs error de Python.
        let detalle = "";
        if (err.killed && err.signal === "SIGTERM") {
          detalle = `TIMEOUT después de 45s — posible cuelgue del subprocess Python`;
        } else if (err.code) {
          detalle = `exit_code=${err.code}`;
        } else if (err.signal) {
          detalle = `signal=${err.signal}`;
        }
        const stderrTxt = (stderr || "").trim();
        const mensaje = [detalle, stderrTxt, err.message]
          .filter(Boolean).join(" | ");
        reject(new Error(`generar_clon.py falló: ${mensaje}`));
        return;
      }
      const outPath = stdout.trim();
      if (!outPath) {
        reject(new Error("generar_clon.py no devolvió path"));
        return;
      }
      resolve(outPath);
    });
  });
}

// ── Token default ────────────────────────────────────────────────────────────
const TOKEN_DEFAULT  = process.env.CURP_API_TOKEN || "b075a154-c369-4799-8f93-51d9d98260e5";
const MUN_CACHE_FILE = path.join(__dirname, "municipios_clave_cache.json");

// ── Cache en memoria de respuestas valida-curp (TTL 90s) ─────────────────────
// Evita gastar 2 créditos cuando index.js consulta primero y luego pasa a
// generarConstanciaLocal. La respuesta se guarda al consultar y se elimina
// después de usarse o de 90 segundos (lo que ocurra primero).
//
// FIX Bug #7: antes había un setTimeout por cada entrada del cache. Si el bot
// crasheaba entre cachear y obtener, el timer quedaba colgado en RAM. Ahora
// usamos UN solo setInterval cada 2 minutos que limpia las entradas vencidas.
const _curpRespCache = new Map();

function cachearRespuestaCURP(curp, apiResp) {
  const key = curp.toUpperCase();
  _curpRespCache.set(key, { data: apiResp, expira: Date.now() + 90000 });
}

function obtenerRespuestaCURPCacheada(curp) {
  const key = curp.toUpperCase();
  const entry = _curpRespCache.get(key);
  if (!entry) return null;
  if (entry.expira <= Date.now()) {
    _curpRespCache.delete(key);
    return null;
  }
  // Eliminar tras usar (single-use) para no acumular memoria
  _curpRespCache.delete(key);
  return entry.data;
}

// Limpieza global del cache CURP cada 2 minutos. Único timer para todo el cache,
// no uno por entrada. Si el bot vive 24h, son 720 ejecuciones triviales.
setInterval(() => {
  const ahora = Date.now();
  for (const [k, entry] of _curpRespCache) {
    if (entry.expira <= ahora) _curpRespCache.delete(k);
  }
}, 2 * 60 * 1000).unref?.(); // unref para no bloquear apagadoLimpio

// ── Cache de municipios por estado (clave INEGI → nombre) ────────────────────
// Lectura del archivo municipios_clave_cache.json que ya tiene los 32 estados
// poblados (se llenó hace tiempo cuando COPOMEX funcionaba). Ya NO se hacen
// llamadas HTTP a COPOMEX — solo lectura local. Si un estado/clave no está
// en cache, la función retorna null y el caller usa el fallback de capital.
let _munCache = null;

function _cargarMunCache() {
  if (_munCache) return _munCache;
  try {
    if (fs.existsSync(MUN_CACHE_FILE)) {
      _munCache = JSON.parse(fs.readFileSync(MUN_CACHE_FILE, "utf8"));
    } else {
      _munCache = {};
    }
  } catch (e) {
    _munCache = {};
  }
  return _munCache;
}

// Resuelve clave INEGI de municipio a nombre oficial usando el cache local.
// Antes esto consultaba api.copomex.com; ahora SOLO lee del archivo local.
function resolverMunicipioDesdeCache(estadoNombre, claveMunicipio) {
  if (!estadoNombre || !claveMunicipio) return null;

  const cache = _cargarMunCache();
  const estadoKey = estadoNombre.toUpperCase().trim();

  if (!cache[estadoKey]) {
    return null;
  }

  const claveStr = String(claveMunicipio).padStart(3, "0");
  return cache[estadoKey][claveStr] || cache[estadoKey][String(parseInt(claveMunicipio, 10))] || null;
}

// ── Función principal ────────────────────────────────────────────────────────
async function generarConstanciaLocal({ curp, token, downloadDir, emisionForzada, soloDocx, sinObligaciones }) {
  token = (token && token !== "x" && token !== "TU_TOKEN") ? token : TOKEN_DEFAULT;
  if (!curp || !token || !downloadDir) {
    throw new Error("Se requieren: curp, token, downloadDir");
  }

  // 1. Consultar API valida-curp (o usar cache si index.js ya consultó)
  let apiResp = obtenerRespuestaCURPCacheada(curp);
  if (apiResp) {
    console.log(`💾 Usando respuesta valida-curp cacheada para ${curp.toUpperCase()} (ahorra 1 crédito)`);
  } else {
    const url = `https://api.valida-curp.com.mx/curp/obtener_datos/?token=${encodeURIComponent(token)}&curp=${encodeURIComponent(curp.toUpperCase())}`;
    console.log(`🔍 Consultando API para CURP: ${curp.toUpperCase()}`);
    apiResp = await fetchJSON(url);
  }

  // Manejo de errores específicos según la doc oficial
  if (apiResp.error) {
    const code = apiResp.error_code || apiResp.code_error;
    const msg  = apiResp.error_message || "Error desconocido";
    let mensaje;
    switch (code) {
      case 1:  mensaje = `Token bloqueado. Contacta al administrador.`; break;
      case 2:  mensaje = `Token inválido. Verifica configuración.`; break;
      case 3:  mensaje = `Proyecto suspendido en valida-curp.`; break;
      case 4:  mensaje = `Sin créditos en API valida-curp. Recarga el paquete.`; break;
      case 101:mensaje = `Estructura de CURP inválida: ${curp}`; break;
      case 200:mensaje = `RENAPO no responde. Intenta de nuevo en un momento.`; break;
      case 300:mensaje = `CURP no encontrada en RENAPO: ${curp}`; break;
      default: mensaje = `API valida-curp error ${code}: ${msg}`;
    }
    throw new Error(mensaje);
  }

  if (!apiResp.response || !apiResp.response.Solicitante) {
    throw new Error(`API valida-curp devolvió respuesta vacía para CURP: ${curp}`);
  }

  const sol = apiResp.response.Solicitante;
  const doc = apiResp.response.DocProbatorio || {};

  // 2. Extraer y normalizar datos
  const nombre = normalizar(sol.Nombres || "");
  const ap1    = normalizar(sol.ApellidoPaterno || "");
  const ap2    = normalizar(sol.ApellidoMaterno || "");

  if (!nombre && !ap1) {
    throw new Error(`API valida-curp no devolvió nombre para CURP: ${curp}`);
  }

  // Fecha: la API puede devolver "YYYY-MM-DD" o "DD/MM/YYYY" — manejar ambos
  if (!sol.FechaNacimiento) {
    throw new Error(`API valida-curp no devolvió fecha de nacimiento para CURP: ${curp}`);
  }
  let fechaNac;
  const fechaStr = sol.FechaNacimiento.trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(fechaStr)) {
    // Formato YYYY-MM-DD
    const [yyyy, mm, dd] = fechaStr.split("-");
    fechaNac = `${dd}/${mm}/${yyyy}`;
  } else if (/^\d{2}\/\d{2}\/\d{4}$/.test(fechaStr)) {
    // Formato DD/MM/YYYY (ya correcto)
    fechaNac = fechaStr;
  } else {
    // Intentar fallback: extraer fecha de la CURP (posiciones 4-9: AAMMDD)
    const aa = curp.substring(4, 6);
    const mm = curp.substring(6, 8);
    const dd = curp.substring(8, 10);
    const yyyy = parseInt(aa) <= (new Date().getFullYear() % 100) ? `20${aa}` : `19${aa}`;
    fechaNac = `${dd}/${mm}/${yyyy}`;
    console.warn(`⚠️  Formato de fecha inesperado: "${fechaStr}" — usando fecha de CURP: ${fechaNac}`);
  }

  // Entidad de NACIMIENTO (para el RFC y datos personales)
  const entidadCode   = resolverEntidad(sol.ClaveEntidadNacimiento, sol.EntidadNacimiento, curp) || "DF";
  const entidadNombre = ENTIDAD_NOMBRE[entidadCode];

  // Entidad de REGISTRO del acta (a la que pertenece el municipio)
  // Si no viene, usar la de nacimiento como respaldo
  const entidadRegistroCode = resolverEntidad(
    doc.ClaveEntidadEmisora || doc.NumEntidadRegistrante,
    doc.EntidadRegistrante,
    curp
  );
  const entidadDomicilioCode = entidadRegistroCode || entidadCode;
  const entidadDomicilioNombre = ENTIDAD_NOMBRE[entidadDomicilioCode];

  // MunicipioRegistro puede venir con nombre o vacío
  let municipioRaw = (doc.MunicipioRegistro && doc.MunicipioRegistro.toString().trim()) || "";
  // Quitar prefijo numérico tipo "026 BANDERILLA" → "BANDERILLA"
  municipioRaw = municipioRaw.replace(/^\d+\s+/, "").trim();

  // Si viene vacío o solo números, resolver via cache local de municipios
  if (!municipioRaw || /^\d+$/.test(municipioRaw)) {
    const claveMun = parseInt(doc.ClaveMunicipioRegistro || 0, 10);
    if (claveMun > 0) {
      const nombreResuelto = resolverMunicipioDesdeCache(entidadDomicilioNombre, claveMun);
      if (nombreResuelto) {
        municipioRaw = nombreResuelto;
        console.log(`📍 Municipio resuelto via cache local: clave ${claveMun} → ${nombreResuelto}`);
      }
    }
  }

  // Si aún vacío, usar capital del estado de REGISTRO (último fallback)
  if (!municipioRaw) {
    municipioRaw = CAPITAL_POR_ENTIDAD[entidadDomicilioCode] || CAPITAL_POR_ENTIDAD[entidadCode] || "CIUDAD DE MEXICO";
  }
  const municipio = normalizar(municipioRaw);

  // Lugar de emisión: usar la forzada si se pasó, si no la del estado de REGISTRO
  // (porque el municipio pertenece a ese estado, no al de nacimiento)
  const emision = emisionForzada
    ? emisionForzada.toUpperCase().trim()
    : `${municipio} , ${entidadDomicilioNombre}`;

  // Municipio para domicilio: siempre usar el de la API, nunca el de la emisión
  const municipioDomicilio = municipio;

  // 3. Generar RFC desde los datos reales
  const rfc = generarRFC(nombre, ap1, ap2, fechaNac);

  console.log(`✅ Datos obtenidos: ${nombre} ${ap1} ${ap2}`);
  console.log(`   Entidad nacimiento: ${entidadNombre} | Entidad domicilio: ${entidadDomicilioNombre}`);
  console.log(`   Municipio: ${municipio}`);
  console.log(`   RFC generado: ${rfc}`);
  console.log(`   Emisión: ${emision}`);

  // 4. Llamar al generador Python con todos los datos completos
  const datos = {
    rfc,
    curp:        curp.toUpperCase(),
    nombre,
    ap1,
    ap2,
    entidadCode: entidadDomicilioCode,  // Estado del DOMICILIO (donde está el municipio)
    emision,
    municipio:   municipioDomicilio,
    downloadDir,
    sinObligaciones: sinObligaciones === true,
  };

  const docxPath = await llamarPython(datos);
  console.log(`✅ DOCX generado: ${docxPath}`);

  // Si solo se pide DOCX, entregarlo sin convertir
  if (soloDocx) {
    console.log(`📄 Modo DOCX — sin conversión PDF`);
    return docxPath;
  }

  // Convertir DOCX → PDF con OnlyOffice (vía cliente unificado, FIX Bug #55)
  try {
    const pdfPath = await convertirDocxAPdf(docxPath);
    try { fs.unlinkSync(docxPath); } catch(e) {}
    console.log(`✅ PDF generado: ${pdfPath}`);
    return pdfPath;
  } catch(err) {
    console.warn(`⚠️  OnlyOffice falló, entregando DOCX: ${err.message}`);
    return docxPath;
  }
}

// ── Conversión DOCX → PDF: ahora delega a onlyofficeClient.js ────────────────
// (las funciones convertirDocxAPdfOnlyOffice, registrarArchivoTemporal y
//  descargarArchivo originales fueron movidas a onlyofficeClient.js como
//  parte de FIX Bug #55. Ver comentario en el require al inicio del archivo.)

// ── Prueba desde línea de comandos ───────────────────────────────────────────
// Uso:
//   node generarClonLocal.js <CURP> <downloadDir>
//   node generarClonLocal.js <CURP> <downloadDir> "TUXTLA GUTIERREZ , CHIAPAS"
if (require.main === module) {
  const args = process.argv.slice(2);
  let curp, token, downloadDir, emisionForzada;

  if (args.length === 2) {
    [curp, downloadDir] = args;
  } else if (args.length === 3) {
    // Detectar si el 3er arg es una emisión (contiene letras y coma/espacio)
    // o un token (UUID con guiones)
    const tercero = args[2];
    if (tercero.includes(",") || /^[A-ZÁÉÍÓÚÑ\s]+$/.test(tercero)) {
      [curp, downloadDir, emisionForzada] = args;
    } else {
      [curp, token, downloadDir] = args;
    }
  } else if (args.length >= 4) {
    [curp, downloadDir, ...rest] = args;
    emisionForzada = rest.join(" ");
  }

  if (!curp || !downloadDir) {
    console.error("Uso: node generarClonLocal.js <CURP> <downloadDir> [\"MUNICIPIO , ESTADO\"]");
    process.exit(1);
  }

  generarConstanciaLocal({ curp, token, downloadDir, emisionForzada })
    .then(p => console.log("Archivo:", p))
    .catch(e => { console.error("Error:", e.message); process.exit(1); });
}

module.exports = { generarConstanciaLocal, generarRFC, cachearRespuestaCURP };
